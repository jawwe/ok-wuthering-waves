import logging
import time

import numpy as np

from src.char.BaseChar import BaseChar, SwitchPriority

# ---------------- 模块级日志部件（三个文件各带一份，内容保持一致） ----------------
_RATIO_FIELDS = ('con', 'res_pct')
_FILTERED_SWITCH_LINES = (
    'BaseCombatTask:switch selection result',
    'BaseCombatTask:switch_next_char end',
)


def _fmt_value(key, v):
    if isinstance(v, float):
        return f'{v:.3f}' if key in _RATIO_FIELDS else f'{v:.2f}'
    return str(v)


class _InfoAsDebug:
    """Per-instance logger: framework info lines become debug; everything else passes through."""

    def __init__(self, inner):
        self._inner = inner

    def info(self, message):
        self._inner.debug(message)

    def __getattr__(self, name):
        return getattr(self._inner, name)


class _AxisSwitchFilter(logging.Filter):
    """Drops the task-level switch info lines while the running task's team has an axis char."""

    okww_axis_switch_filter = True

    def __init__(self, executor):
        super().__init__()
        self._executor = executor

    def filter(self, record):
        try:
            if record.levelno != logging.INFO or not record.getMessage().startswith(_FILTERED_SWITCH_LINES):
                return True
            chars = getattr(self._executor.current_task, 'chars', None) or []
            return not any(getattr(char, '_axis_char', False) for char in chars)
        except Exception:
            return True


def _install_axis_switch_filter(task):
    try:
        ok_logger = logging.getLogger('ok')
        if not any(getattr(f, 'okww_axis_switch_filter', False) for f in ok_logger.filters):
            ok_logger.addFilter(_AxisSwitchFilter(task.executor))
    except Exception:
        pass


class Galbrena(BaseChar):
    """弗坎嘉 25 秒进阶轴（BV1nAC6BRETp@77-144s）：嘉贝莉娜，循环轴从 Galbrena.s1 开始。

    启动轴 Cantarella.f1 -> Phrolova.f1 -> Cantarella.f2 -> Phrolova.f2 -> 循环轴
    循环轴 Galbrena.s1 -> Cantarella.s1 -> Galbrena.s2 -> Cantarella.s2 -> Galbrena.s3 -> Cantarella.s3
           -> Galbrena.s4 -> Cantarella.s4 -> Phrolova.s1 -> Galbrena.s1
    """

    _axis_char = True

    # s1 ZZ：变奏入场后一次长按连出 2 段重击（攻略 BV1oox6zdE8w@98.5–102s，用户 2026-10-09 指出）。
    # 按满 S1_SWITCH_AT 就带着按住的左键切坎，坎进场接着重击（用户 2026-10-14，暂定值）。
    # 视频 91.4 入场 -> 92.9 切坎共 1.5s；v3 实测 test_2352 按键到坎技能栏出现约 0.17s（20.98 -> 21.15）
    S1_SWITCH_AT = 1.3
    _HOLD_IN = ()  # 带着按住的左键切进来时接着按的节点
    # s2 AAA：A4 前摇就切坎（字幕@99-102）。A 段待专题：普攻段数，暂按视频时长 98.7 -> 100.4 共 1.7s，
    # 减去 exit 到切人约 0.13s（30 秒轴 v6 实测 test_1513）
    S2_AAA = 1.5
    # s3 入场 A、Q 之后等回路满按 E2；视频 101.8 入场 -> R 102.5，回路在入场前已满。
    # 等待上限沿用 30 秒轴 E2_WAIT（那里从入场起算 4.0s）；30 秒轴入场即按会被吞，这里有 A、Q 垫着，吞了靠第 2 次补按
    E2_WAIT = 4.0
    # 回路满须持续这么久才算：boss 白闪只有单帧（v2 实测 test_0854 run1 55.45 白占比 0.108 > 0.08，条实际约 3/4，按成普通 E）
    E2_SETTLE = 0.1
    E2_CONFIRM = 2.0  # 按 E2 到爆发图标出现：实测 run3' 超过 1.07s（v1 等 1.0s 误报失败）
    E2_TO_R = 0.2  # 爆发图标出现到 R：24.2->24.4、64.9->65.05；简介④ E2R 连按太快会吞 E2
    # 爆发 4A闪3A闪A 的组时长：作者两次滑步在 HUD 恢复后 +4.0、+7.3（BV1rPChBAEda 35.0、38.3；30 秒轴 v9-v15 实测沿用）。
    # 本轴把爆发拆成 s3【AA】和 s4【AA】闪【AAA】两次上场：组 1 从 HUD 恢复起算 4.0s，中间切坎 A【E】的时间也算在里面
    BURST_GROUPS = (4.0, 3.3)
    # s3 R 后【AA】：视频 HUD 恢复 105.9 -> 切坎 107.0 共 1.1s，强化 A3 前摇就切（卡 Galbrena_C0 脱手条）
    S3_ENH = 1.0
    # s4 没有爆发（E2 或 R 没放出）时，普攻等协奏满的上限：视频嘉 s4 共 4.9s
    S4_NO_BURST = 5.0
    # s4 组 2 滑步后至少打这么久才按协奏收手：打到【AAA】最后的强化 A5 踢腿打出，这时切人能合轴，踢腿伤害在切人后才出现
    # （字幕@110-111 嘉 2 套普攻打完再延奏；用户 2026-10-21 定为第 1 圈的切人点：test_1227 录屏 48.40 起踢、48.70 判满、
    # 踢腿 33714 在 48.75 出现）。2.0.13 组 1、组 2 协奏满就切，嘉 s3 离场协奏逐圈升高（test_1227 0.53→0.90），
    # s4 从 4.28s 缩到 0.69s；第 1 圈滑步到判满 2.67/2.74/2.77s（test_1227、test_0043 两场），取略早于最短值
    S4_G2_MIN = 2.6
    # 图标连续消失这么久才算爆发结束：v5 实测 test_1413 v202.3 单帧漏检（图标实际亮到切人 203.58），
    # 提前收手、协奏 0.81 无变奏离场，连锁约 46s
    BURST_END_SETTLE = 0.3
    # 2.0.13 嘉 s4 判满：协奏环整圈闭合就算满（用户 2026-10-20）。2.0.12 实测 test_1920 第 2 圈环在 09.688 闭合，
    # 队员头像白圈同时出现（录屏 84.60 = 日志 09.70）；框架 count_rings 要等末段发亮的颜色回到火色域才判满，
    # 四圈都晚 1.29-1.38s。闭合判据：环带 36 个 10° 扇区的平均 R-B 都不低于 CON_CLOSED_RB，框架读数不低于
    # CON_CLOSED_MIN（挡住 HUD 没显示的帧），连续 CON_CLOSED_FRAMES 次。200 张截图回放：未满时灰轨扇区 R-B 最高 42，
    # 闭合后最低 47、多数约 90，组 1 最高 -14
    CON_CLOSED_RB = 65
    CON_CLOSED_MIN = 0.6
    CON_CLOSED_FRAMES = 2
    _ring_bins = None
    _s4_on = False
    _closed_n = 0
    _last_rb = None

    # A property, not an __init__ assignment: CharFactory copies the built-in instance's __dict__
    # over this one on team load, and a data descriptor wins over the instance __dict__.
    @property
    def logger(self):
        return self._quiet_logger

    @logger.setter
    def logger(self, value):
        self._raw_logger = value
        self._quiet_logger = _InfoAsDebug(value)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _install_axis_switch_filter(self.task)
        self._force_switch_me = False
        self._entry_mode = None
        self._node = None
        self.started = False
        self._startup_done = False
        self._held_switch = False
        self._held_in = False
        self._entry_held = False
        self._burst_t0 = None

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None
        self._held_switch = False
        self._held_in = False
        self._entry_held = False
        self._burst_t0 = None

    def f_break(self, check_f_on_switch=False, force=False):
        # s3、s4 爆发中离场切坎时框架不按 F：击破时停 1.3–1.5s 吃掉按实时计的爆发组时长（30 秒轴 v10 test_2142、
        # v11 test_2257），s4 还会打断延奏前的合轴（v12 实测 test_0043）。
        # s1 离场也不按：按住切坎时按 F 会连带点一下左键把按住松开（用户 2026-10-14）。
        # s2 离场也不按：处决挪到坎 s4 的 E 之后、切人之前，由坎按 F（用户 2026-10-14）
        if check_f_on_switch and self._node in ('s1', 's2', 's3', 's4'):
            return False
        return super().f_break(check_f_on_switch, force)

    # ---------------- 强切协议（队里每个类都带同一份） ----------------
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        # Workshop classes are loaded standalone, so isinstance() against src.char.* never matches.
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode):
        held, self._held_switch = self._held_switch, False
        if target is None:
            if held:
                self.task.mouse_up()
            self._raw_logger.warning(f'[{(self._node or "-").upper()}] fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        if held and self._switch_holding(target):
            return True
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            return self.switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    def _switch_holding(self, target):
        """Switch by number key with the left button still held (set _held_switch before the switch), so the
        target enters mid-heavy: the framework switch and its F-break both click, which releases the button.
        Bookkeeping mirrors BaseCombatTask.switch_next_char for a switch without intro. On failure release the
        button and return False; the caller then uses the framework switch."""
        tag = self._node or '-'
        start = time.time()
        switched = False
        try:
            if self.is_con_full():
                # 协奏满切人会带变奏，交给框架切人记 has_intro
                self._raw_logger.warning(f'[{tag.upper()}] fallback: framework_switch reason=con_full')
                return False
            last_send = 0
            # 按键到技能栏换人约 0.17s（v3 实测 test_2352），上限取 1.0s
            while time.time() - start < 1.0:
                self.check_combat()
                if time.time() - last_send > 0.1:
                    self.task.send_key(target.index + 1)
                    last_send = time.time()
                self.task.next_frame()
                if self.task.in_team()[1] == target.index:
                    switched = True
                    break
        finally:
            if not switched:
                self.task.mouse_up()
        if not switched:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: framework_switch reason=held_switch_timeout')
            return False
        self.task.in_liberation = False
        self.switch_out(con_full=False)
        target.has_intro = False
        target.has_sub_dps_intro = False
        target.is_current_char = True
        target.last_switch_in_time = time.time()
        target._held_in = True
        self._trace(tag, 'switch', ok=True, held=True, next=target.__class__.__name__, switch_s=time.time() - start)
        return True

    # 战斗结束到重进战斗不超过这么久，就当作误判脱战、接着走记下的节点：
    # 误判 0.02s 就重进（v6 实测 test_2342），真实换场最短 8.8s（v1-v5 日志）
    _RESUME_S = 1.0

    def on_combat_end(self, chars):
        # 切人那一帧编号角标全被挡住时，框架判脱战、清空节点状态，重进战斗又从启动轴开始
        # （v6 实测 test_2342 v44.78 坎 s4 切弗 s1，弗被打断去走坎 f1）。记下已强切、还没进场的节点
        pending = [c for c in self.task.chars if c is not None and getattr(c, '_entry_mode', None)]
        self.task._axis_resume = (pending[0].__class__.__name__, pending[0]._entry_mode, time.time()) if pending else None
        # 按住左键等着切人、或带着按住切进来时战斗结束，左键不能留在按下状态
        if self._held_switch or self._held_in or self._entry_held:
            self.task.mouse_up()
        self._held_switch = False
        self._held_in = False
        self._entry_held = False
        super().on_combat_end(chars)

    # ---------------- 分发器 ----------------
    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def _take_resume(self):
        """Pop the node on_combat_end recorded; use it only when this combat started within _RESUME_S."""
        resume, self.task._axis_resume = getattr(self.task, '_axis_resume', None), None
        if resume is None or time.time() - resume[2] > self._RESUME_S:
            return None
        return resume[:2]

    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        held, self._held_in = self._held_in, False
        if held and mode not in self._HOLD_IN:
            # 带着按住的左键切进来，但这个节点不接着按：先松开
            self.task.mouse_up()
            held = False
        self._entry_held = held
        resume = self._take_resume() if mode is None else None
        if resume and resume[0] != self.__class__.__name__:
            # 误判脱战时切人没成，记下的节点不归在场角色：强切过去
            self._trace(None, 'interrupt', reason='resume', next=f'{resume[0]}.{resume[1]}')
            return self._force_switch_to(self._find_teammate(resume[0]), resume[1])
        if resume:
            mode, entry = resume[1], 'resume'
        elif mode is None:
            if not self.started and not self._startup_done:
                # 启动轴从坎 E 开始，别人先在场就直接强切坎特蕾拉（视频 77.0 嘉在场，77.9 切坎）
                if self.__class__.__name__ != 'Cantarella':
                    self._trace(None, 'interrupt', reason='not_axis_head', next='Cantarella.f1')
                    return self._force_switch_to(self._find_teammate('Cantarella'), 'f1')
                mode = 'f1'
            elif self._startup_done:
                mode = 's1'
            else:
                self._trace(None, 'interrupt', reason='startup_in_progress', next='framework')
                return self.switch_next_char()
            entry = 'intro' if self.has_intro else 'natural'
        else:
            entry = 'forced'
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, f'perform_{mode}', None)
        if func is None:
            self._trace(mode, 'interrupt', reason='unknown_mode', next='framework')
            return self.switch_next_char()
        self._node = mode
        self._trace(mode, 'enter', mode=entry)
        return func()

    # ---------------- 日志 ----------------
    def _trace(self, tag, event, ok=None, reason=None, **data):
        """Write one template line: [TAG] event[: ok|fail] [reason=code] [key=value ...]."""
        try:
            line = f'[{tag.upper()}] {event}' if tag else event
            if ok is not None:
                line += ': ok' if ok else ': fail'
            if reason:
                line += f' reason={reason}'
            for key, value in data.items():
                line += f' {key}={_fmt_value(key, value)}'
            self._raw_logger.info(line)
        except Exception:
            pass

    # ---------------- 动作 helper（三个文件各带一份，内容保持一致） ----------------
    def _ready_or_skip(self, tag, skill, ready, time_out, settle_time=-1):
        """Normal-attack until ready() holds (for settle_time seconds when given); on timeout log a fallback
        warning and return False."""
        if self.task.wait_until(ready, pre_action=self.check_combat if time_out > 1 else None,
                                post_action=self.click_with_interval, time_out=time_out, settle_time=settle_time):
            return True
        self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_{skill} reason=not_ready')
        return False

    def _cast_e(self, tag, ready_time_out=1.0, time_out=1.0, skill=None, settle_time=-1):
        """E that shows a CD after the cast: press until the CD appears (1-6).
        skill names which E it is when one key casts several (fallback name and log field)."""
        if not self._ready_or_skip(tag, skill or 'e', self.resonance_available, ready_time_out, settle_time):
            return False
        ok = bool(self.task.wait_until(lambda: not self.resonance_available(),
                                       pre_action=self.check_combat if time_out > 1 else None,
                                       post_action=self.send_resonance_key, time_out=time_out))
        if ok:
            self.record_resonance_use()
        data = {'skill': skill} if skill else {}
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'icon_still_lit', **data)
        return ok

    def _cast_echo(self, tag, ready_time_out=1.0, time_out=1.0):
        if not self._ready_or_skip(tag, 'echo', self.echo_available, ready_time_out):
            return False
        ok = self.click_echo(time_out=time_out)
        self._trace(tag, 'cast echo', ok=ok, reason=None if ok else 'icon_still_lit')
        return ok

    def _cast_r(self, tag, ready_time_out=1.0, click_f=True):
        if not self._ready_or_skip(tag, 'r', self.liberation_available, ready_time_out):
            return False
        ok = self.click_liberation(click_f=click_f)
        self._trace(tag, 'cast R', ok=ok, reason=None if ok else 'no_animation')
        return ok

    def _dodge(self):
        self.task.send_key(self.task.key_config.get('Dodge Key'))

    def _dodge_forward(self):
        # 爆发中的滑步要朝敌人（用户回答 2026-10-08）：按住前进再闪避
        self.task.send_key_down('w')
        try:
            self.task.next_frame()
            self._dodge()
        finally:
            # next_frame 在任务暂停或停止时会抛异常，前进键不能留在按下状态
            self.task.send_key_up('w')

    def _outro(self, tag, time_out):
        """↓: leave at full concerto; otherwise attack until it fills, and leave anyway on timeout."""
        if self.task.wait_until(self.is_con_full, pre_action=self.check_combat if time_out > 1 else None,
                                post_action=self.click_with_interval, time_out=time_out):
            self._trace(tag, 'decide: outro', con_full=True, rb=self._last_rb)
            return True
        self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_outro reason=timeout con_full=False')
        return False

    # ---------------- 节点：f = 启动轴，s = 循环轴（薄包装，最后一句保持字面写法） ----------------
    def perform_s1(self):
        self._action_s1('s1', 'Cantarella.s1')
        self._force_switch_to(self._find_teammate('Cantarella'), 's1')

    def perform_s2(self):
        self._action_s2('s2', 'Cantarella.s2')
        self._force_switch_to(self._find_teammate('Cantarella'), 's2')

    def perform_s3(self):
        self._action_s3('s3', 'Cantarella.s3')
        self._force_switch_to(self._find_teammate('Cantarella'), 's3')

    def perform_s4(self):
        self._action_s4('s4', 'Cantarella.s4')
        self._force_switch_to(self._find_teammate('Cantarella'), 's4')

    # ---------------- 动作体（tag = 日志节点，nxt = exit 行去向） ----------------
    # 循环轴“嘉 ZZ”，视频 91.4-92.9（弗 R↓ 带变奏切入；第 2 遍 128.0-129.4）
    def _action_s1(self, tag, nxt):
        # 切入即按住重击（简介⑧：预输入重击，切入后从 Z1 开始），按满 S1_SWITCH_AT 不松手，由 _force_switch_to 按住切坎
        self.check_combat()
        self.task.mouse_down()
        handed = False
        try:
            self.sleep(self.S1_SWITCH_AT)
            handed = True
        finally:
            # sleep 中战斗结束或任务停止会抛异常，这时左键还在自己手里，必须松开
            if not handed:
                self.task.mouse_up()
        self._held_switch = True
        self._trace(tag, 'cast heavy', hold_s=self.S1_SWITCH_AT, held_switch=True)
        self._trace(tag, 'exit', reason='done', next=nxt)

    # 循环轴“嘉 AAA”，视频 98.7-100.4（坎 Q 后强切、无变奏）
    def _action_s2(self, tag, nxt):
        self.continues_normal_attack(self.S2_AAA)
        self._trace(tag, 'exit', reason='done', next=nxt)

    # 循环轴“嘉 AQ【E】R【AA】”，视频 101.8-107.0（坎普通切入）：R 演出 102.6-105.9，HUD 恢复后打 1.1s 就切坎
    def _action_s3(self, tag, nxt):
        self._burst_t0 = None
        self.normal_attack()
        self._cast_echo(tag)
        if not self._cast_e2(tag):
            # 字幕@103-108：嘉的流程被打断就直接切坎先打 AE，防止坎掉出蜃境
            self._trace(tag, 'exit', reason='no_e2', next=nxt)
            return
        # 爆发分组按真实时间计时，R 演出里不按 F：click_liberation 默认每 0.1s 按 F，R 一结束就触发击破，
        # 全局时停 1.3–1.5s 吃掉爆发时间（30 秒轴 v10 test_2142 c3 145.6–147.1、v11 首版 test_2257 c3 138.6–139.9）
        if not self._cast_r(tag, click_f=False):
            self._trace(tag, 'exit', reason='no_r', next=nxt)
            return
        # 不在 click_liberation 返回的那一帧上判：30 秒轴 v7 实测 test_1621 v40.233 HUD 还在淡入（队伍编号已过 0.8、
        # 爆发图标 0.62），单帧判成没进爆发
        if not self.task.wait_until(self._burst_shown, post_action=self.click_with_interval,
                                    time_out=self.BURST_END_SETTLE):
            self._trace(tag, 'attack', group=0)
            self._trace(tag, 'exit', reason='no_burst', next=nxt)
            return
        self._burst_t0 = time.time()
        if self._burst_attack(tag, 1, self.S3_ENH):
            self._burst_t0 = None
        self._trace(tag, 'exit', reason='done', next=nxt)

    # 循环轴“嘉 【AA】闪【AAA】↓”，视频 108.0-112.9（坎粉圈 E 后强切）：接着 s3 的爆发打组 1 到 HUD 恢复后 +4.0s，
    # 朝敌人滑步，组 2 打满 S4_G2_MIN 后协奏满就延奏，最多 3.3s（字幕@110-111：嘉 2 套普攻打完刚好满协奏，直接延奏坎）。
    # v4 组 2 固定打满 3.3s，test_1253 R 演出结束到切坎 8.1s，参考 7.0s；用户看到最后一下踢腿打完整才切（用户 2026-10-14）
    def _action_s4(self, tag, nxt):
        t0, self._burst_t0 = self._burst_t0, None
        self._s4_on, self._closed_n = True, 0
        try:
            if t0 is None:
                # s3 没进爆发或爆发已结束：普攻等协奏满，到时照切
                self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_burst reason=no_burst')
                self._outro(tag, self.S4_NO_BURST)
            else:
                # 组 1 不按协奏收手，只查爆发结束（2.0.13 组 1 协奏满就切，test_1227 第 4 圈入场 0.67s 就走）
                if not self._attack_until_con(tag, 1,
                                              max(t0 + self.BURST_GROUPS[0] - time.time(), self.BURST_END_SETTLE),
                                              burst_end=True, con_after=None):
                    self._dodge_forward()
                    self._attack_until_con(tag, 2, self.BURST_GROUPS[1], con_after=self.S4_G2_MIN)
                self._outro(tag, 1.0)
        finally:
            self._s4_on = False
        self._trace(tag, 'exit', reason='done', next=nxt)

    def is_con_full(self):
        # s4 的 _outro 也走这里：改用 _s4_con_full（环闭合就算满）
        if not self._s4_on:
            return super().is_con_full()
        return self._s4_con_full(self.get_current_con())

    def _s4_con_full(self, con):
        """嘉 s4 判满：框架判满，或协奏环闭合连续 CON_CLOSED_FRAMES 次。用环闭合判满时把 current_con 记成 1，
        框架切人据此记 has_intro，switch_out 再清零。"""
        self._last_rb = self._con_ring_rb()
        closed = con >= self.CON_CLOSED_MIN and self._last_rb >= self.CON_CLOSED_RB
        self._closed_n = self._closed_n + 1 if closed else 0
        if con != 1 and self._closed_n < self.CON_CLOSED_FRAMES:
            return False
        self.current_con = 1
        return True

    def _con_ring_rb(self):
        """协奏框环带 36 个 10° 扇区里平均 R-B 的最小值：灰色未满轨道是负数，填满的火色约 90（test_1920 截图）。"""
        img = self.task.get_con_box().crop_frame(self.task.frame)
        h, w = img.shape[:2]
        if self._ring_bins is None or self._ring_bins[0] != (h, w):
            yy, xx = np.mgrid[0:h, 0:w]
            r = np.hypot(xx - w // 2, yy - h // 2)
            sector = ((np.degrees(np.arctan2(yy - h // 2, xx - w // 2)) + 360) % 360 // 10).astype(int)
            band = (r >= h * 0.357) & (r <= h * 0.417)
            self._ring_bins = ((h, w), [band & (sector == b) for b in range(36)])
        rb = img[:, :, 2].astype(int) - img[:, :, 0].astype(int)
        return float(min(rb[m].mean() for m in self._ring_bins[1]))

    def _burst_shown(self):
        # 同上游 Galbrena.check_res：左格爆发图标，用项目自带的 has_target / no_target 模板
        if not self.task.in_team_and_world():
            return False
        return self.task.find_best_match_in_box(self.task.get_box_by_name('box_target_enemy_long'),
                                                ['has_target', 'no_target'], threshold=0.6)

    def _cast_e2(self, tag):
        """【E】: E2 never shows a CD, so click_resonance would keep pressing until its timeout.
        Wait for the forte bar (upstream Galbrena's E2 condition), press once, confirm by the burst icon (5-3)."""
        if not self._ready_or_skip(tag, 'e2', self.is_forte_full, self.E2_WAIT, settle_time=self.E2_SETTLE):
            return False
        for attempt in (1, 2):
            self.send_resonance_key()
            ok = bool(self.task.wait_until(self._burst_shown, time_out=self.E2_CONFIRM))
            self._trace(tag, 'cast E' if attempt == 1 else 'retry E', ok=ok, reason=None if ok else 'timeout',
                        attempt=attempt)
            if ok:
                self.record_resonance_use()
                self.sleep(self.E2_TO_R)
                return True
            # 回路已不满：E2 已放出、只是没确认到爆发图标，不再补按
            if attempt == 2 or not self.is_forte_full():
                return False

    def _burst_attack(self, tag, group, time_out):
        """爆发里连点普攻 time_out 秒；左格爆发图标连续 BURST_END_SETTLE 消失就提前收手。返回爆发是否已结束。"""
        # 组内每帧查图标，爆发一结束就收手（30 秒轴 v1 只在段间查，实测最多晚 1.6s）；结束只认连续消失
        ended = bool(self.task.wait_until(lambda: not self._burst_shown(),
                                          pre_action=self.check_combat if time_out > 1 else None,
                                          post_action=self.click_with_interval, time_out=time_out,
                                          settle_time=self.BURST_END_SETTLE))
        self._trace(tag, 'attack', group=group, ended=ended)
        return ended

    def _attack_until_con(self, tag, group, time_out, burst_end=False, con_after=0.0):
        """爆发里连点普攻，打满 con_after 秒后协奏一满（_s4_con_full）就收手，最多 time_out 秒；con_after 为 None 时
        不按协奏收手。burst_end 时左格爆发图标连续 BURST_END_SETTLE 消失也收手（同 _burst_attack）。返回是否提前收手。
        日志记最后的框架读数 con 和环 R-B 最小值 rb。"""
        start = time.time()
        last, full, gone = [0.0], [False], [None]

        def done():
            now = time.time()
            last[0] = self.get_current_con()
            # 打满 con_after 之前也每帧判，闭合计数接着累计，时间一到就能收手
            closed = self._s4_con_full(last[0])
            full[0] = closed and con_after is not None and now - start >= con_after
            if full[0] or not burst_end:
                return full[0]
            if self._burst_shown():
                gone[0] = None
                return False
            gone[0] = gone[0] or now
            return now - gone[0] >= self.BURST_END_SETTLE

        stopped = bool(self.task.wait_until(done, pre_action=self.check_combat if time_out > 1 else None,
                                            post_action=self.click_with_interval, time_out=time_out))
        self._trace(tag, 'attack', group=group, con_full=full[0], ended=stopped and not full[0],
                    con=float(last[0]), rb=self._last_rb, burst=self._burst_shown())
        return stopped
