import logging
import time

import numpy as np

from src.char.BaseChar import BaseChar, SwitchPriority, forte_white_color

# ---------------- 模块级日志部件（三个文件各带一份，内容保持一致） ----------------
_RATIO_FIELDS = ('con', 'res_pct')
_FILTERED_SWITCH_LINES = (
    'BaseCombatTask:switch selection result',
    'BaseCombatTask:switch_next_char end',
)


def _fmt_value(key, v):
    if isinstance(v, float):
        return f'{v:.3f}' if key in _RATIO_FIELDS else f'{v:.2f}'
    return str(v)


class _InfoAsDebug:
    """Per-instance logger: framework info lines become debug; everything else passes through."""

    def __init__(self, inner):
        self._inner = inner

    def info(self, message):
        self._inner.debug(message)

    def __getattr__(self, name):
        return getattr(self._inner, name)


class _AxisSwitchFilter(logging.Filter):
    """Drops the task-level switch info lines while the running task's team has an axis char."""

    okww_axis_switch_filter = True

    def __init__(self, executor):
        super().__init__()
        self._executor = executor

    def filter(self, record):
        try:
            if record.levelno != logging.INFO or not record.getMessage().startswith(_FILTERED_SWITCH_LINES):
                return True
            chars = getattr(self._executor.current_task, 'chars', None) or []
            return not any(getattr(char, '_axis_char', False) for char in chars)
        except Exception:
            return True


def _install_axis_switch_filter(task):
    try:
        ok_logger = logging.getLogger('ok')
        if not any(getattr(f, 'okww_axis_switch_filter', False) for f in ok_logger.filters):
            ok_logger.addFilter(_AxisSwitchFilter(task.executor))
    except Exception:
        pass


class Cantarella(BaseChar):
    """弗坎嘉 25 秒进阶轴（BV1nAC6BRETp@77-144s）：坎特蕾拉开启动轴。

    启动轴 Cantarella.f1 -> Phrolova.f1 -> Cantarella.f2 -> Phrolova.f2 -> 循环轴
    循环轴 Galbrena.s1 -> Cantarella.s1 -> Galbrena.s2 -> Cantarella.s2 -> Galbrena.s3 -> Cantarella.s3
           -> Galbrena.s4 -> Cantarella.s4 -> Phrolova.s1 -> Galbrena.s1
    """

    _axis_char = True

    # A 段待专题：普攻段数，暂按视频时长
    # f2 AAA：视频 85.1 坎技能栏出现 -> 86.7 E 冷却 6.0，约 86.95 切弗（弗后台打强化重击，切坎偷 3AE，字幕@84；
    # 0.1s 逐帧 media/frames/v3check/kan_f2_084.9-087.2.png）。v2 用 1.0s，用户看到坎没打出普攻（test_2304）
    F2_AAA = 1.5
    # s2 AA：视频 100.4-101.8 共 1.4s，打到切人冷却好就切回嘉（字幕@99-102）。普攻到嘉切人冷却结束为止，这里只是上限：
    # 框架按嘉离场后 1s 算冷却（BaseCombatTask._target_has_switch_cd），v5 固定打 1.0s，test_1742 嘉离场 -> 切回 1.45s
    S2_MAX = 2.0
    # 以下沿用 30 秒轴 v15（同一角色同一套湿身-伞形 E-粉圈 E，实测值）
    # s1 重击按住到进湿身就松手，Z_HOLD 只是上限：v11 实测 test_2357 固定按 2.1s，c2、c3 按住 1.0 / 0.87s 就进了湿身，
    # 多按的 1.1–1.2s 让结晶提前满，第一下 E 放成终结技能，伞形 E 之后白等 2s 粉圈（c1 有变奏 1.73s 才进湿身）
    Z_HOLD = 2.1
    # s1 由嘉带着按住的左键切进来，接着按住到进湿身（用户 2026-10-14）；Z_HOLD 仍从坎进场起算
    _HOLD_IN = ('s1',)
    # 进湿身的判据：鼠标图标外框（带小三角）消失，和进湿身同一帧（test_2357 c1 53.8 -> 53.9、c3 149.1 -> 149.2），
    # 即上游 Cantarella 的 heavy_click_forte(check_fun=self.is_mouse_forte_full)；连续消失这么久才松手，防单帧漏检
    WET_SETTLE = 0.1
    # Z 收招后连按伞形 E 到进冷却：v2 实测 test_0854 run2 0.78s 才按出；run3' 被 boss 打出硬直，1.0s 内没按出
    UMBRELLA_E = 2.0
    # 进湿身后 E 格判到可用的上限（原先单独等 resonance_available 的 1.0s）
    UMBRELLA_READY = 1.0
    # s3 A【E】：普攻到 E 格出现粉圈漩涡就按（用户 2026-10-21）。轴不乱时粉圈在进场后 0.0–0.21s 出现
    # （2.0.13 test_1227、2.0.14 test_2147 录屏）；轴乱了（终结技能没好就进场）要普攻等它出来。
    # 认出就按、不等稳定：粉圈可能很快变回普通 E（v2 test_2304 c1 进场已是粉圈，代码等稳定 0.5s 才按，0.3s 时已变回）。
    # 框架 resonance_available 只看 E 格有没有冷却数字，分不出粉圈和云朵：2.0.14 只等它 0.3s，test_2147 21:52:33
    # 粉圈进场 0.21s 才出现、0.31s 超时漏放，终结技能留到下一圈坎 s1 先放，伞形 E 晚约 1.4s，连续 3 圈。
    # 等粉圈的上限：进场时湿身最多还剩约 1.95s（test_2147 二段 1 重击后 13.00s 进场、14.95s 湿身结束），再加 NORMAL_E_SETTLE
    S3_MAX = 2.5
    # 粉圈连续认出这么久才按，防单帧误判。粉圈出现后先清楚显示至少 0.12s 才转粉色光晕（test_2147 第 19196-19203 帧）
    VORTEX_SETTLE = 0.05
    # 认出云朵（普通 E，见 CLOUD_INNER_MIN）连续这么久就不再等：湿身已结束，粉圈不会再来。
    # 比粉圈中心爆亮的约 0.12s（test_2323 第 7412-7418 帧）和切人时的空白 0.03s 长。
    # 不按普通 E：按了会占掉坎 s4 的 E（test_2147 21:49:28 坎 s4 skip_e）
    NORMAL_E_SETTLE = 0.3
    # 云朵判据：E 格没有冷却数字，且中心一圈白色占比不低于这个值。录屏上云朵约 0.50，粉圈 ≤0.07，冷却数字 0.18-0.23，
    # 粉圈中心爆亮 0.09-0.43。2.0.15 把认不出的粉圈都当云朵：test_2323 第 3 圈粉圈在屏上 1.05s，
    # 实时画面一直没认出，1.01s 就 normal_e 放弃。云朵中心是整块白色，录屏比实时画面糊，对它影响小
    CLOUD_INNER_MIN = 0.30
    # 粉圈图标判据：E 图标圆内，中心一圈（0.08R–0.30R）几乎没有白色，旋臂一圈（0.32R–0.58R）白色多。
    # 云朵、伞形、嘉的扇形中心白；冷却数字旋臂一圈白少。阈值按 test_2147、test_1227 录屏 2569 帧定：
    # 粉圈中心白 ≤0.071、旋臂白 ≥0.287；其他帧旋臂白 ≥0.28 时中心白 ≥0.117，中心白 ≤0.08 时旋臂白 ≤0.271（光晕盖住的粉圈）。
    # 圆心、半径按框架 box_resonance 换算：1920x1080 下框 (1592.5, 938.5) 67.5x56.5，圆心 (1623.3, 966.6)，R 51.0
    VORTEX_CX, VORTEX_CY, VORTEX_R = 0.456, 0.4975, 0.903
    VORTEX_INNER_MAX = 0.08
    VORTEX_ARM_MIN = 0.28
    # 粉圈 E 只按一下，按完停这么久再切嘉。放出终结技能后图标变回无冷却数字的普通 E，连按会多放一个普通 E：
    # v1 实测 test_2216 c1 视频 36.95 按出终结，37.1-37.5 普通 E 图标，37.6 进冷却 6.0，多出的协奏让坎在 s3 就满。
    # 终结放出没有可靠的画面判据：上游 is_forte_full 框、E 图标粉色占比、E 图标灰度差在 test_2216 上都和背景闪光重叠，
    # 所以只发不确认。按完这么久后日志记一下粉圈还在不在（left），只用来排查，不重按
    VORTEX_AFTER = 0.3
    # s4 普通 E 按到进冷却的上限：v1 实测 test_2216 冷却数字在进场后 1.05-1.2s 才出现（视频 45.2 / 89.4 / 138.4），
    # 1.0s 先超时，E 已放出却记成 fail
    S4_E = 1.5

    # A property, not an __init__ assignment: CharFactory copies the built-in instance's __dict__
    # over this one on team load, and a data descriptor wins over the instance __dict__.
    @property
    def logger(self):
        return self._quiet_logger

    @logger.setter
    def logger(self, value):
        self._raw_logger = value
        self._quiet_logger = _InfoAsDebug(value)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _install_axis_switch_filter(self.task)
        self._force_switch_me = False
        self._entry_mode = None
        self._node = None
        self.started = False
        self._startup_done = False
        self._held_switch = False
        self._held_in = False
        self._entry_held = False
        self._umbrella_ok = False

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None
        self._held_switch = False
        self._held_in = False
        self._entry_held = False
        self._umbrella_ok = False

    def f_break(self, check_f_on_switch=False, force=False):
        # 框架切人时坎不按 F，击破只在 s4 由坎显式按（见 _action_s4）。ok-ww 3.7.6 给内置坎设了 check_f_on_switch=True，
        # CharFactory 把它复制到这里，坎 f1/f2/s2/s3 离场时框架会替坎按 F，击破时停吃掉嘉按实时计的爆发时长；
        # 3.7.4 坎是治疗位，默认就不按
        if check_f_on_switch:
            return False
        return super().f_break(check_f_on_switch, force)

    # ---------------- 强切协议（队里每个类都带同一份） ----------------
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def healer_full_con_switch_locked(self):
        # 轴强切坎时不受满协奏离场 16s 锁定：_choose_switch_target 先查锁再查优先级，MUST 绕不过。
        # v5 实测 test_1413 v90.7 坎 s1 满协奏离场，嘉 s2 强切坎 can't find next char，嘉连跑两遍 s1 到 v113.8，
        # 坎 s2、弗 s1 全丢，boss 1 击破圈 102–115 无人切人打。框架自行切人时锁定照旧
        return not self._force_switch_me and super().healer_full_con_switch_locked()

    def _find_teammate(self, class_name):
        # Workshop classes are loaded standalone, so isinstance() against src.char.* never matches.
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode):
        held, self._held_switch = self._held_switch, False
        if target is None:
            if held:
                self.task.mouse_up()
            self._raw_logger.warning(f'[{(self._node or "-").upper()}] fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        if held and self._switch_holding(target):
            return True
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            return self.switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    def _switch_holding(self, target):
        """Switch by number key with the left button still held (set _held_switch before the switch), so the
        target enters mid-heavy: the framework switch and its F-break both click, which releases the button.
        Bookkeeping mirrors BaseCombatTask.switch_next_char for a switch without intro. On failure release the
        button and return False; the caller then uses the framework switch."""
        tag = self._node or '-'
        start = time.time()
        switched = False
        try:
            if self.is_con_full():
                # 协奏满切人会带变奏，交给框架切人记 has_intro
                self._raw_logger.warning(f'[{tag.upper()}] fallback: framework_switch reason=con_full')
                return False
            last_send = 0
            # 按键到技能栏换人约 0.17s（v3 实测 test_2352），上限取 1.0s
            while time.time() - start < 1.0:
                self.check_combat()
                if time.time() - last_send > 0.1:
                    self.task.send_key(target.index + 1)
                    last_send = time.time()
                self.task.next_frame()
                if self.task.in_team()[1] == target.index:
                    switched = True
                    break
        finally:
            if not switched:
                self.task.mouse_up()
        if not switched:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: framework_switch reason=held_switch_timeout')
            return False
        self.task.in_liberation = False
        self.switch_out(con_full=False)
        target.has_intro = False
        target.has_sub_dps_intro = False
        target.is_current_char = True
        target.last_switch_in_time = time.time()
        target._held_in = True
        self._trace(tag, 'switch', ok=True, held=True, next=target.__class__.__name__, switch_s=time.time() - start)
        return True

    # 战斗结束到重进战斗不超过这么久，就当作误判脱战、接着走记下的节点：
    # 误判 0.02s 就重进（v6 实测 test_2342），真实换场最短 8.8s（v1-v5 日志）
    _RESUME_S = 1.0

    def on_combat_end(self, chars):
        # 切人那一帧编号角标全被挡住时，框架判脱战、清空节点状态，重进战斗又从启动轴开始
        # （v6 实测 test_2342 v44.78 坎 s4 切弗 s1，弗被打断去走坎 f1）。记下已强切、还没进场的节点
        pending = [c for c in self.task.chars if c is not None and getattr(c, '_entry_mode', None)]
        self.task._axis_resume = (pending[0].__class__.__name__, pending[0]._entry_mode, time.time()) if pending else None
        # 按住左键等着切人、或带着按住切进来时战斗结束，左键不能留在按下状态
        if self._held_switch or self._held_in or self._entry_held:
            self.task.mouse_up()
        self._held_switch = False
        self._held_in = False
        self._entry_held = False
        super().on_combat_end(chars)

    # ---------------- 分发器 ----------------
    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def _take_resume(self):
        """Pop the node on_combat_end recorded; use it only when this combat started within _RESUME_S."""
        resume, self.task._axis_resume = getattr(self.task, '_axis_resume', None), None
        if resume is None or time.time() - resume[2] > self._RESUME_S:
            return None
        return resume[:2]

    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        held, self._held_in = self._held_in, False
        if held and mode not in self._HOLD_IN:
            # 带着按住的左键切进来，但这个节点不接着按：先松开
            self.task.mouse_up()
            held = False
        self._entry_held = held
        resume = self._take_resume() if mode is None else None
        if resume and resume[0] != self.__class__.__name__:
            # 误判脱战时切人没成，记下的节点不归在场角色：强切过去
            self._trace(None, 'interrupt', reason='resume', next=f'{resume[0]}.{resume[1]}')
            return self._force_switch_to(self._find_teammate(resume[0]), resume[1])
        if resume:
            mode, entry = resume[1], 'resume'
        elif mode is None:
            if not self.started and not self._startup_done:
                # 启动轴从坎 E 开始，别人先在场就直接强切坎特蕾拉（视频 77.0 嘉在场，77.9 切坎）
                if self.__class__.__name__ != 'Cantarella':
                    self._trace(None, 'interrupt', reason='not_axis_head', next='Cantarella.f1')
                    return self._force_switch_to(self._find_teammate('Cantarella'), 'f1')
                mode = 'f1'
            elif self._startup_done:
                mode = 's1'
            else:
                self._trace(None, 'interrupt', reason='startup_in_progress', next='framework')
                return self.switch_next_char()
            entry = 'intro' if self.has_intro else 'natural'
        else:
            entry = 'forced'
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, f'perform_{mode}', None)
        if func is None:
            self._trace(mode, 'interrupt', reason='unknown_mode', next='framework')
            return self.switch_next_char()
        self._node = mode
        self._trace(mode, 'enter', mode=entry)
        return func()

    # ---------------- 日志 ----------------
    def _trace(self, tag, event, ok=None, reason=None, **data):
        """Write one template line: [TAG] event[: ok|fail] [reason=code] [key=value ...]."""
        try:
            line = f'[{tag.upper()}] {event}' if tag else event
            if ok is not None:
                line += ': ok' if ok else ': fail'
            if reason:
                line += f' reason={reason}'
            for key, value in data.items():
                line += f' {key}={_fmt_value(key, value)}'
            self._raw_logger.info(line)
        except Exception:
            pass

    # ---------------- 动作 helper（三个文件各带一份，内容保持一致） ----------------
    def _ready_or_skip(self, tag, skill, ready, time_out, settle_time=-1):
        """Normal-attack until ready() holds (for settle_time seconds when given); on timeout log a fallback
        warning and return False."""
        if self.task.wait_until(ready, pre_action=self.check_combat if time_out > 1 else None,
                                post_action=self.click_with_interval, time_out=time_out, settle_time=settle_time):
            return True
        self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_{skill} reason=not_ready')
        return False

    def _cast_e(self, tag, ready_time_out=1.0, time_out=1.0, skill=None, settle_time=-1):
        """E that shows a CD after the cast: press until the CD appears (1-6).
        skill names which E it is when one key casts several (fallback name and log field)."""
        if not self._ready_or_skip(tag, skill or 'e', self.resonance_available, ready_time_out, settle_time):
            return False
        ok = bool(self.task.wait_until(lambda: not self.resonance_available(),
                                       pre_action=self.check_combat if time_out > 1 else None,
                                       post_action=self.send_resonance_key, time_out=time_out))
        if ok:
            self.record_resonance_use()
        data = {'skill': skill} if skill else {}
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'icon_still_lit', **data)
        return ok

    def _cast_echo(self, tag, ready_time_out=1.0, time_out=1.0):
        if not self._ready_or_skip(tag, 'echo', self.echo_available, ready_time_out):
            return False
        ok = self.click_echo(time_out=time_out)
        self._trace(tag, 'cast echo', ok=ok, reason=None if ok else 'icon_still_lit')
        return ok

    def _cast_r(self, tag, ready_time_out=1.0, click_f=True):
        if not self._ready_or_skip(tag, 'r', self.liberation_available, ready_time_out):
            return False
        ok = self.click_liberation(click_f=click_f)
        self._trace(tag, 'cast R', ok=ok, reason=None if ok else 'no_animation')
        return ok

    def _dodge(self):
        self.task.send_key(self.task.key_config.get('Dodge Key'))

    def _outro(self, tag, time_out):
        """↓: leave at full concerto; otherwise attack until it fills, and leave anyway on timeout."""
        if self.task.wait_until(self.is_con_full, pre_action=self.check_combat if time_out > 1 else None,
                                post_action=self.click_with_interval, time_out=time_out):
            self._trace(tag, 'decide: outro', con_full=True)
            return True
        self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_outro reason=timeout con_full=False')
        return False

    # ---------------- 节点：f = 启动轴，s = 循环轴（薄包装，最后一句保持字面写法） ----------------
    def perform_f1(self):
        self._action_f1('f1', 'Phrolova.f1')
        self._force_switch_to(self._find_teammate('Phrolova'), 'f1')

    def perform_f2(self):
        self._action_f2('f2', 'Phrolova.f2')
        self._force_switch_to(self._find_teammate('Phrolova'), 'f2')

    def perform_s1(self):
        self._action_s1('s1', 'Galbrena.s2')
        self._force_switch_to(self._find_teammate('Galbrena'), 's2')

    def perform_s2(self):
        self._action_s2('s2', 'Galbrena.s3')
        self._force_switch_to(self._find_teammate('Galbrena'), 's3')

    def perform_s3(self):
        self._action_s3('s3', 'Galbrena.s4')
        self._force_switch_to(self._find_teammate('Galbrena'), 's4')

    def perform_s4(self):
        self._action_s4('s4', 'Phrolova.s1')
        self._force_switch_to(self._find_teammate('Phrolova'), 's1')

    # ---------------- 动作体（tag = 日志节点，nxt = exit 行去向） ----------------
    # 启动轴“坎 E”，视频 77.9-78.6：入场即放普通 E 攒协奏
    def _action_f1(self, tag, nxt):
        self._cast_e(tag)
        self._trace(tag, 'exit', reason='done', next=nxt)

    # 启动轴“坎 AAAE”，视频 85.3-86.9（弗打出强化重击后强切）
    def _action_f2(self, tag, nxt):
        self.continues_normal_attack(self.F2_AAA)
        # E 按下就切弗，不等冷却数字（用户 2026-10-14）。v5 按到冷却出现才切：test_1742 坎 f2 进场 -> E 确认 2.24s，
        # 视频 85.1 进场 -> 86.7 冷却 6.0 只用 1.6s
        if self._ready_or_skip(tag, 'e', self.resonance_available, 1.0):
            self._send_e(tag)
        self._trace(tag, 'exit', reason='done', next=nxt)

    # 循环轴“坎 ZERQ”，视频 92.9-98.7（嘉 ZZ 后强切；第 2 遍 129.4-135.1）：R 94.7，演出到 98.1，随后 Q 切嘉
    def _action_s1(self, tag, nxt):
        # 击破：坎 s1 不按 F。开局按 F 时框架会点一下左键，把嘉带进来的按住松开。
        # v4 离场前按 F，击破给坎加协奏：test_1253 坎 s1 离场协奏升到 0.80-1，之后切人变奏全乱。
        # 击破留到坎 s4 的 E 之后、切人之前由坎自己按（用户 2026-10-14）。
        # 先清掉框架的 can_break：它认到一次就一直留着，只有按过 F 才清。v13 test_0110 t2/t3 第一个 boss 的击破环在嘉 s1 期间满了、
        # 没被击破就先死了，下一次切人对着空环的新 boss 空按 F 约 0.7s（break_check/ring_t2.png、ring_t3.png）。
        # 清掉后，坎 s4 的 f_break 只认这之后的图标
        self.task.can_break = False
        # Z：嘉带着按住的左键切进来就接着按，进湿身后按住不松接着按伞形 E（字幕@88-89“切坎 Z 完再松”）
        held = self._entry_held
        self._entry_held = False
        try:
            self._heavy_until_wet(tag, held)
            # E：湿身状态下是伞形 E（语义卡称强化技能）；R 打断它的后摇（字幕@94-95）
            self._umbrella_ok = self._cast_umbrella(tag)
        finally:
            # wait_until 在任务暂停或停止时会抛异常，左键不能留在按下状态
            self.task.mouse_up()
        # R 演出里不按 F：click_liberation 默认每 0.1s 按 F，击破环满时会在坎 s1 击破，和上面“s1 不按 F”冲突
        self._cast_r(tag, click_f=False)
        # Q 按下就切嘉，不等冷却（用户 2026-10-14）
        self._cast_echo(tag, time_out=0)
        self._trace(tag, 'exit', reason='done', next=nxt)

    # 循环轴“坎 AA”，视频 100.4-101.8（嘉 A4 前摇强切）：湿身普攻攒结晶，切人冷却好就切回嘉（字幕@99-102）
    def _action_s2(self, tag, nxt):
        start = time.time()
        gal = self._find_teammate('Galbrena')
        # 普攻到嘉能切为止，判据和框架选人相同（用户 2026-10-14“147s”）。v5 固定打 1.0s：test_1742 v146.71 嘉离场，
        # v148.16 才切回
        ready = gal is None or bool(self.task.wait_until(lambda: not self.task._target_has_switch_cd(gal),
                                                         post_action=self.click_with_interval,
                                                         time_out=self.S2_MAX))
        if not ready:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_in_cd reason=timeout')
        self._trace(tag, 'decide: switch', attack_s=time.time() - start)
        self._trace(tag, 'exit', reason='done', next=nxt)

    # 循环轴“坎 A【E】”，视频 107.0-108.0（嘉强化 A3 前摇强切）
    def _action_s3(self, tag, nxt):
        if self._umbrella_ok:
            # 普攻到粉圈出现，按一下 E，再切嘉
            self._cast_vortex(tag)
        else:
            # 没有伞形 E 就出不了粉圈 E（30 秒轴 v1 实测 run1 第二下 E 放成普通 E，run3' 第二下才放出伞形 E）
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_vortex reason=no_umbrella')
        self._umbrella_ok = False
        self._trace(tag, 'exit', reason='done', next=nxt)

    def _cast_vortex(self, tag):
        """A【E】: normal-attack until the vortex icon shows, then press E once with no confirm. Stop waiting when
        the icon settles on a cloud (normal E), or after S3_MAX; an icon that is neither keeps the wait going
        (see VORTEX_SETTLE, NORMAL_E_SETTLE, CLOUD_INNER_MIN, VORTEX_AFTER). Logs each icon change."""
        start = time.time()
        seen = {'icon': None, 'since': start}

        def settled():
            now = time.time()
            inner, arm = self._vortex_rings()
            if self._is_vortex(inner, arm):
                icon = 'vortex'
            elif inner >= self.CLOUD_INNER_MIN and self.resonance_available():
                icon = 'normal'
            else:
                icon = None
            wet = self._wet_ratio()
            if icon != seen['icon']:
                seen['icon'], seen['since'] = icon, now
                self._trace(tag, 'icon', icon=icon or 'none', t=now - start, inner=f'{inner:.3f}', arm=f'{arm:.3f}',
                            wet=f'{wet:.3f}')
            need = self.VORTEX_SETTLE if icon == 'vortex' else self.NORMAL_E_SETTLE
            return icon is not None and now - seen['since'] >= need

        done = self.task.wait_until(settled, pre_action=self.check_combat, post_action=self.click_with_interval,
                                    time_out=self.S3_MAX, settle_time=0)
        wait_s = time.time() - start
        if not done or seen['icon'] != 'vortex':
            reason = 'normal_e' if done else 'not_ready'
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_vortex reason={reason} wait_s={wait_s:.2f}')
            return False
        self._send_e(tag, 'vortex', self.VORTEX_AFTER)
        self.task.next_frame()
        self._trace(tag, 'decide: vortex', wait_s=wait_s, left=self.is_vortex_icon())
        return True

    def is_vortex_icon(self):
        """E 格是粉圈漩涡（判据见 VORTEX_INNER_MAX、VORTEX_ARM_MIN）。"""
        return self._is_vortex(*self._vortex_rings())

    def _is_vortex(self, inner, arm):
        return inner <= self.VORTEX_INNER_MAX and arm >= self.VORTEX_ARM_MIN

    def _vortex_circle(self):
        box = self.task.get_box_by_name('box_resonance')
        return box.x + box.width * self.VORTEX_CX, box.y + box.height * self.VORTEX_CY, box.height * self.VORTEX_R

    def _vortex_rings(self):
        """E 图标中心一圈（0.08R-0.30R）和旋臂一圈（0.32R-0.58R）的白色占比。"""
        cx, cy, r = self._vortex_circle()
        x0, y0 = max(int(cx - 0.6 * r), 0), max(int(cy - 0.6 * r), 0)
        crop = self.task.frame[y0:int(cy + 0.6 * r) + 1, x0:int(cx + 0.6 * r) + 1, :3].astype(np.int16)
        yy, xx = np.mgrid[:crop.shape[0], :crop.shape[1]]
        d = np.hypot(xx + x0 + 0.5 - cx, yy + y0 + 0.5 - cy) / r
        top, low = crop.max(axis=2), crop.min(axis=2)
        white = (top >= 200) & (top - low <= 50)
        return float(white[(d > 0.08) & (d <= 0.30)].mean()), float(white[(d > 0.32) & (d <= 0.58)].mean())

    def _wet_ratio(self):
        # 只记读数：上游 Cantarella.is_forte_full 的区域和颜色（上游阈值 0.06）。test_2323 录屏上坎 s3 整段 ≤0.052，
        # 第 4 圈云朵段反而有 12/48 帧过线，不当判据用
        box = self.task.box_of_screen_scaled(5120, 2880, 3034, 2640, 3090, 2700, name='forte_full', hcenter=True)
        return float(self.task.calculate_color_percentage(forte_white_color, box))

    def _send_e(self, tag, skill=None, after=0.0):
        """Press E once and do not confirm the CD; wait `after` seconds before returning."""
        self.send_resonance_key()
        self.record_resonance_use()
        if after > 0:
            self.sleep(after)
        data = {'skill': skill} if skill else {}
        self._trace(tag, 'send E', confirm='none', **data)

    def _heavy_until_wet(self, tag, held=False):
        """Z: hold until the mouse-icon outline shows and then stays gone for WET_SETTLE (entered wet), at most Z_HOLD.
        The outline may still be dark right after switching in, so wait for it to show first.
        held: the button is already down (switched in by _switch_holding), so keep holding instead of pressing.
        Leaves the button down; the caller releases it."""
        start = time.time()
        self.check_combat()
        if not held:
            self.task.mouse_down()
        wet = bool(self.task.wait_until(self.is_mouse_forte_full, time_out=self.Z_HOLD)) and bool(
            self.task.wait_until(lambda: not self.is_mouse_forte_full(),
                                 time_out=max(self.Z_HOLD - (time.time() - start), 0.01),
                                 settle_time=self.WET_SETTLE))
        self._trace(tag, 'cast heavy', ok=wet, reason=None if wet else 'timeout', held=held,
                    hold_s=time.time() - start)

    def _cast_umbrella(self, tag):
        """Umbrella E on entering wet with the left button still held (the caller releases it): press at once and
        again every 0.1s, and count it cast once the icon has read ready and then shows the CD (at most
        UMBRELLA_READY + UMBRELLA_E), with no combat check in the loop. Logs how long until the icon read ready, how
        many presses and how long from ready until the CD showed."""
        start = time.time()
        # 进湿身不松左键直接按 E，同上游 Cantarella 湿身循环：按住左键时 click_resonance(send_click=False)。
        # v5 先松手再按，循环里带 check_combat：test_1742 伞形图标亮 -> 冷却 12.0 出现 0.95-1.86s，
        # 约每 0.2s 按一次、按了 4-6 次（media/harness-v5/test_1742/frames/kan/result.txt Q2）
        # 2.0.13 不再先等 resonance_available 才按：进湿身时 E 格上一次的冷却数字还要 0.11-0.16s 才判到消失
        # （2.0.12 test_1920 四圈 ready_s），录屏上伞形图标出现后 0.24-0.32s 才按第 1 次（2.0.12 notes 根因 3）。
        # 进湿身前按 E 会放成普通 E，所以仍等 _heavy_until_wet 的 WET_SETTLE 确认湿身
        sends, last_send, ready_s = 0, 0, None

        def send():
            nonlocal sends, last_send
            if time.time() - last_send >= 0.1:
                sends += 1
                last_send = time.time()
                self.send_resonance_key()

        def cast():
            # 先判到过可用、再出冷却才算放出：刚进湿身时旧的冷却数字也是“不可用”
            nonlocal ready_s
            if self.resonance_available():
                ready_s = ready_s if ready_s is not None else time.time() - start
                return False
            # UMBRELLA_READY 内一直没判到可用：照旧跳过伞形 E
            return ready_s is not None or time.time() - start > self.UMBRELLA_READY

        send()
        ok = bool(self.task.wait_until(cast, post_action=send, time_out=self.UMBRELLA_READY + self.UMBRELLA_E))
        if ready_s is None:
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_umbrella reason=not_ready sends={sends}')
            return False
        if ok:
            self.record_resonance_use()
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'icon_still_lit', skill='umbrella',
                    ready_s=ready_s, cd_s=time.time() - start - ready_s, sends=sends)
        return ok

    # 循环轴“坎 E↓”，视频 112.9-114.0（嘉 ↓ 带变奏切入）：普通 E 后延奏弗
    def _action_s4(self, tag, nxt):
        self._cast_e(tag, time_out=self.S4_E)
        # 击破放在 E 之后、延奏切弗之前，有击破图标才按（用户 2026-10-14）。2.0.5 放在坎 s2 结尾，
        # test_2342 L129 按了 F 的那圈，坎切嘉 s3 时协奏已满、带变奏入场（L131 current_con 1）
        self._trace(tag, 'decide: break', break_f=bool(self.task.f_break()))
        self._outro(tag, 1.0)
        self._trace(tag, 'exit', reason='done', next=nxt)
