import ctypes
import os
import threading
import time

import cv2
import numpy as np

from src.char.BaseChar import SwitchPriority
from src.char.Cartethyia import Cartethyia as NativeCartethyia


# ==================== 物理 F 键监视 ====================
F_VK = 0x46
F_POLL_INTERVAL = 0.05
F_LOG_DEBOUNCE = 1.0
F_TASK_NAME = 'FStartCombatTask'

# 距上次启动轴超过这么久才算"新战斗的 F"，否则认为是战斗中的处决
F_NEW_SESSION_GAP = 60.0


def f_settings(task):
    executor = getattr(task, 'executor', None)
    for group in ('trigger_tasks', 'onetime_tasks'):
        for other in getattr(executor, group, None) or ():
            if type(other).__name__ == F_TASK_NAME:
                try:
                    return bool(other.enabled), float(getattr(other, 'f_start_delay', 0) or 0)
                except Exception:
                    return True, 0.0
    return True, 0.0


def start_f_watch(task, logger=None):
    """物理 F 监视：只在"距上次启动轴超过 F_NEW_SESSION_GAP 秒"时记录。
    战斗中的处决 F 落在窗口内，自动忽略。完全不调任何视觉 API。"""
    if getattr(task, '_f_watch_started', False):
        return
    task._f_watch_started = True
    if not hasattr(task, '_f_last_press'):
        task._f_last_press = -1
    if not hasattr(task, '_f_pressed_at'):
        task._f_pressed_at = -1
    if not hasattr(task, '_opener_last_time'):
        task._opener_last_time = -1

    def watch():
        try:
            user32 = ctypes.windll.user32
            user32.GetAsyncKeyState.restype = ctypes.c_short
        except Exception as e:
            task._f_watch_started = False
            if logger:
                logger.error(f'f watch: GetAsyncKeyState unavailable ({e})')
            return
        last_log = 0
        was_down = False
        while True:
            try:
                down = bool(user32.GetAsyncKeyState(F_VK) & 0x8000)
                if down and not was_down and f_settings(task)[0]:
                    now = time.time()
                    last_opener = getattr(task, '_opener_last_time', -1)
                    is_new_session = (last_opener < 0
                                      or now - last_opener > F_NEW_SESSION_GAP)
                    if is_new_session:
                        task._f_last_press = now
                        task._f_pressed_at = now
                        if logger and now - last_log >= F_LOG_DEBOUNCE:
                            last_log = now
                            logger.info('physical F pressed (new session), opener re-armed')
                    else:
                        if logger and now - last_log >= F_LOG_DEBOUNCE:
                            last_log = now
                            logger.info('physical F pressed (in session, ignored as execution)')
                was_down = down
                time.sleep(F_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='ok_ww_f_watch', daemon=True).start()


# ==================== 自定义异常 ====================
class CycleAbort(Exception):
    """关键步骤无法补偿，放弃这一圈，下一帧框架重调 do_perform。"""
    pass


# ==================== 宏表 ====================
OPENER_MACRO = (
    ('E', 100, 200), ('夏', 93, 220), ('L', 78, 220), ('L', 78, 50),
    ('E', 80, 0), ('SP', 50, 100), ('L', 63, 150), ('千', 50, 150),
    ('E', 20, 170), ('Q', 50, 170), ('R', 50, 3680),
    ('L', 50, 250), ('夏', 93, 25),
    ('L', 78, 550), ('L', 78, 50), ('SP', 150, 100), ('L', 78, 50),
    ('千', 100, 150), ('L', 150, 420), ('L', 50, 150), ('夏', 93, 25),
    ('L', 150, 550), ('L', 78, 50), ('RB', 50, 0), ('L', 1100, 0),
    ('R', 0, 3725), ('千', 100, 850), ('E', 50, 50), ('卡', 100, 600),
    ('L', 150, 200), ('千', 0, 110), ('L', 10, 1050), ('L', 15, 0),
    ('卡', 5, 10), ('L', 100, 900), ('千', 100, 200), ('L', 50, 250),
    ('卡', 50, None),
)

SWORD_MACRO = (
    ('E', 15, 900), ('E', 50, 0), ('夏', 100, 200), ('L', 75, 200),
    ('L', 78, 100), ('E', 50, 0), ('千', 100, 150), ('E', 50, 350),
    ('L', 78, 50), ('卡', 50, 0), ('L', 100, 850), ('L', 50, 50),
    ('千', 100, 150), ('L', 150, 420), ('L', 50, 150), ('卡', 16, 50),
    ('L', 78, 650), ('R', 50, None),
)

LOOP_MACRO = (
    ('E', 50, 100), ('E', 50, 100), ('E', 50, 100),
    ('夏', 50, 900), ('L', 50, 450), ('L', 50, 150),
    ('千', 50, 100), ('E', 20, 170), ('Q', 50, 170), ('R', 50, 3680),
    ('夏', 50, 50), ('E', 50, 50), ('Q', 50, 0), ('R', 50, 3750),
    ('千', 50, 850), ('E', 50, 50), ('卡', 100, 400),
    ('L', 150, 250), ('L', 125, 0), ('千', 50, 0), ('L', 50, 1010),
    ('L', 15, 0), ('卡', 25, 25), ('L', 50, 950), ('千', 100, 200),
    ('L', 50, 250), ('卡', 50, None),
)

OP_SEG1_A = OPENER_MACRO[:11]
OP_SEG1_B = OPENER_MACRO[11:13]
OP_SEG1_C = OPENER_MACRO[13:27]
OP_CHISA_E = OPENER_MACRO[27]
OP_SEG2 = OPENER_MACRO[28:37]
OP_LAST = OPENER_MACRO[37:]

LOOP_SEG1 = LOOP_MACRO[:6]
LOOP_SEG2_A = LOOP_MACRO[6:11]
LOOP_SEG2_B = LOOP_MACRO[11:15]
LOOP_CHISA_E = LOOP_MACRO[15]
LOOP_SEG3 = LOOP_MACRO[16:26]
LOOP_LAST = LOOP_MACRO[26:]

SWORD_A = SWORD_MACRO[:5]
SWORD_B = SWORD_MACRO[5:]

OP_CHISA_NORMAL_E = 8
SWORD_CHISA_NORMAL_E = 7
OP_SEG1_A_CHISA_R = 10
OP_SEG1_C_CIAC_R = 12
LOOP_SEG2_A_CHISA_R = 3
LOOP_SEG2_B_CIAC_R = 2
OP_SEG2_RECHECK = 3
LOOP_SEG3_RECHECK = 4
LOOP_SEG1_CART_E = 0

SWITCH_TOKENS = {'卡': 'Cartethyia', '夏': 'Ciaccona', '千': 'Chisa'}
CN_NAMES = {'Cartethyia': '卡提', 'Ciaccona': '夏空', 'Chisa': '千咲'}

assert OPENER_MACRO[7][0] == '千' and OPENER_MACRO[8][0] == 'E'
assert OPENER_MACRO[9][0] == 'Q' and OPENER_MACRO[10] == ('R', 50, 3680)
assert LOOP_MACRO[0][0] == 'E' and LOOP_MACRO[1][0] == 'E' and LOOP_MACRO[2][0] == 'E'
assert LOOP_MACRO[6][0] == '千' and LOOP_MACRO[7][0] == 'E'
assert LOOP_MACRO[8][0] == 'Q' and LOOP_MACRO[9] == ('R', 50, 3680)
assert OP_SEG1_A[OP_SEG1_A_CHISA_R] == ('R', 50, 3680)
assert OP_SEG1_C[OP_SEG1_C_CIAC_R] == ('R', 0, 3725)
assert LOOP_SEG2_A[LOOP_SEG2_A_CHISA_R] == ('R', 50, 3680)
assert LOOP_SEG2_B[LOOP_SEG2_B_CIAC_R] == ('R', 50, 3750)
assert LOOP_SEG3[LOOP_SEG3_RECHECK - 1][0] == '千'


class Cartethyia(NativeCartethyia):
    """卡夏千队里的卡提希娅，兼整条轴的持宏者。非本队时走原版。"""

    # ==================== 引擎参数 ====================
    A_INTERVAL = 0.12
    MIN_KEY_HOLD = 0.010
    LATE_WARN = 0.030

    SWITCH_TIME_OUT = 2.5
    FIELD_SETTLE_TIME_OUT = 1.5
    UNTRUSTED_CONFIRM = 3

    OPENER_MIN_GAP = 60.0

    CART_TRANSFORM_ANIM = 3.40
    FLEUR_LIB_ANIM = 5.00
    ANIM_GONE_GRACE = 0.70

    O_INTRO_TO_JUMP = 1.30
    L_INTRO_TO_JUMP = 1.30
    JUMP_HOLD = 0.08
    JUMP_TO_AIR_A = 0.20
    AIR_A_HOLD = 0.06
    AIR_A_RETRY = 0.14
    O_JUMP_TO_LANDED = 0.75
    L_JUMP_TO_LANDED = 0.75
    EQR_WAIT_CAP = 7.0
    EQR_AFTER = 0.05
    EQR_E_HOLD = 0.05
    EQR_E_TAPS = 2
    EQR_E_TAP_GAP = 0.03
    EQR_Q_HOLD = 0.05
    EQR_R_HOLD = 0.05

    O_R1_TO_SWORD = 3.55
    L_R1_TO_SWORD = 3.55
    SWORD_E_PREPRESS = (0.20, 0.10)
    SWORD_E_PREPRESS_HOLD = 0.015

    O_SMALL_A_FROM = 0.10
    L_SMALL_A_FROM = 0.10
    O_SMALL_HOLD_AT = 2.40
    L_SMALL_HOLD_AT = 2.40
    O_SMALL_HOLD_UP = 3.45
    L_SMALL_HOLD_UP = 3.45
    O_SMALL_JUMP_AT = 3.62
    L_SMALL_JUMP_AT = 3.62
    O_SMALL_R_AT = 4.30
    L_SMALL_R_AT = 4.30
    SMALL_FALL_SETTLE = 0.70

    L_CIAC_L1_HOLD = 0.06
    L_CIAC_L1_GAP = 0.10
    L_CIAC_L2_HOLD = 0.06
    L_CIAC_FALL_TO_LAND = 0.55
    L_CIAC_LAND_A_HOLD = 0.078
    L_CIAC_LAND_A_GAP = 0.05
    L_CIAC_RB_HOLD = 0.05
    L_CIAC_HEAVY_HOLD = 1.10

    USE_F_BREAK = True
    BREAK_WINDOW = 0.35
    BREAK_EVERY = 0.10

    FLEUR_A_FIRST = 4.00
    R2_PRESS_WATCH = 0.40
    LOOP_AFTER_R2 = 0.30

    R_HUD_WATCH = 0.35
    R_HUD_POLL = 0.02

    COMP_WAIT_BEFORE_JUMP = 0.20

    COMP_TRANSFORM_CAP = 8.0
    COMP_TRANSFORM_A_GAP = 0.15
    COMP_TRANSFORM_R_HUD_WATCH = 0.35

    COMP_CHISA_R_CAP = 4.0
    COMP_CHISA_R_A_GAP = 0.15

    COMP_CIAC_R_CAP = 5.0
    COMP_CIAC_R_A_GAP = 0.15

    COMP_FLEUR_A_FIRST = 3
    COMP_FLEUR_A_SECOND = 5
    COMP_FLEUR_A_GAP = 0.15
    COMP_FLEUR_ROUNDS = 3
    COMP_FLEUR_R_HUD_WATCH = 0.40

    L_CART_RETAP_TIMES = 4
    L_CART_RETAP_PRESS = 0.02
    L_CART_RETAP_GAP = 0.03
    L_CART_RETAP_AFTER = 0.10

    L_OPENER_CART_TAP_TIMES = 3
    L_OPENER_CART_TAP_PRESS = 0.03
    L_OPENER_CART_TAP_GAP = 0.05
    L_OPENER_CART_TAP_AFTER = 0.20

    # ==================== 生命周期 ====================
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.opener_armed = True
        self.last_opener = -1
        self.macro_t0 = 0.0
        self.macro_marks = []
        self.cur = None
        self.held = set()
        self.snapshots = 0
        self._ignored_combat_lost = 0
        self._api_probed = False
        self._chisa_r_failed = False
        self._comp_count = 0

    def reset_state(self):
        super().reset_state()
        self.opener_armed = True
        self.cur = None
        self.snapshots = 0
        self._ignored_combat_lost = 0
        self._api_probed = False
        self._chisa_r_failed = False
        self._comp_count = 0
        start_f_watch(self.task, self.logger)

    # ==================== 队伍判定 ====================
    @property
    def is_in_kxq_cycle(self) -> bool:
        team_members = 0
        for char in self.task.chars:
            if char is not None and char.name in {'Ciaccona', 'Chisa'}:
                team_members += 1
        return team_members == 2

    def teammate(self, name):
        for char in self.task.chars:
            if char is not None and char.name == name:
                return char
        return None

    def opener_pending(self):
        return self.opener_blocked_by() is None

    def opener_blocked_by(self):
        if not self.is_in_kxq_cycle:
            return 'team is not cartethyia/chisa/ciaccona'

        # F 检查放最前：发现有效 F（新 session）就重置启动轴状态，允许重跑
        f_press = getattr(self.task, '_f_last_press', -1)
        if f_press > self.last_opener:
            self.opener_armed = True
            waited = time.time() - f_press
            delay = f_settings(self.task)[1]
            if waited < delay:
                return f'F pressed {waited:.2f}s ago, waiting {delay:.2f}s for the mobs'
            return None

        if not self.opener_armed:
            return 'already armed-down (ran once this combat)'
        if self.last_opener >= 0 and time.time() - self.last_opener < self.OPENER_MIN_GAP:
            return f'ran {time.time() - self.last_opener:.1f}s ago (< {self.OPENER_MIN_GAP:.0f}s)'
        if not self.task.use_liberation:
            return 'task.use_liberation is off'
        return None

    # ==================== 时间轴记录 ====================
    def macro_start(self):
        self.macro_t0 = time.perf_counter()
        self.macro_marks = []

    def macro_mark(self, name):
        self.macro_marks.append(f'{name}@{time.perf_counter() - self.macro_t0:.2f}')

    def macro_timeline(self):
        return ' '.join(self.macro_marks)

    # ==================== 战斗检查屏蔽层 ====================
    @staticmethod
    def _is_not_in_combat(exc):
        name = type(exc).__name__
        return ('NotInCombat' in name
                or 'OutOfCombat' in name
                or 'not in combat' in str(exc).lower())

    def safe_next_frame(self):
        try:
            self.task.next_frame()
        except Exception as e:
            if self._is_not_in_combat(e):
                self._ignored_combat_lost += 1
                return
            raise

    def safe_click(self):
        try:
            self.task.click()
        except Exception as e:
            if self._is_not_in_combat(e):
                self._ignored_combat_lost += 1
                return
            raise

    def safe_in_team(self):
        try:
            return self.task.in_team()[0]
        except Exception as e:
            if self._is_not_in_combat(e):
                self._ignored_combat_lost += 1
                return False
            raise

    # ==================== 定时原语 ====================
    def check_enabled(self):
        try:
            self.task.executor.check_enabled(check_pause=False)
        except Exception as e:
            if self._is_not_in_combat(e):
                self._ignored_combat_lost += 1
                return
            raise

    def sleep_until(self, target):
        while True:
            left = target - time.perf_counter()
            if left <= 0:
                return
            if left > 0.06:
                time.sleep(min(0.05, left - 0.02))
                self.check_enabled()
            else:
                time.sleep(left)

    def macro_wait(self, sec):
        self.sleep_until(time.perf_counter() + max(0.0, sec))

    def center(self):
        return self.task.width_of_screen(0.5), self.task.height_of_screen(0.5)

    def key_of(self, token):
        if token == 'E':
            return self.get_resonance_key()
        if token == 'Q':
            return self.get_echo_key()
        if token == 'R':
            return self.get_liberation_key()
        if token == 'SP':
            return self.task.key_config.get('Jump Key', 'space')
        if token == 'F':
            return 'f'
        return None

    def press_down(self, token, char_by_token):
        if token == 'L':
            x, y = self.center()
            self.task.mouse_down(x, y)
        elif token == 'RB':
            x, y = self.center()
            self.task.mouse_down(x, y, key='right')
        elif token in SWITCH_TOKENS:
            target = char_by_token.get(token)
            if target is None:
                return
            self.task.send_key_down(str(target.index + 1))
            if target is not self.cur:
                self.handoff(self.cur if self.cur is not None else self, target)
        else:
            self.task.send_key_down(self.key_of(token))
            if token == 'E' and self.cur is not None:
                self.cur.record_resonance_use()
            elif token == 'Q' and self.cur is not None:
                self.cur.record_echo_use()
            elif token == 'R' and self.cur is not None:
                self.cur.record_liberation_use()
        self.held.add(token)

    def press_up(self, token, char_by_token):
        if token == 'L':
            self.task.mouse_up()
        elif token == 'RB':
            self.task.mouse_up(key='right')
        elif token in SWITCH_TOKENS:
            target = char_by_token.get(token)
            if target is not None:
                self.task.send_key_up(str(target.index + 1))
        else:
            self.task.send_key_up(self.key_of(token))
        self.held.discard(token)

    def release_all(self):
        chars = self.char_by_token()
        for token in list(self.held):
            try:
                self.press_up(token, chars)
            except Exception:
                pass
        self.held.clear()

    def tap(self, token, hold):
        chars = self.char_by_token()
        down = time.perf_counter()
        self.press_down(token, chars)
        self.macro_wait(max(hold, self.MIN_KEY_HOLD))
        self.press_up(token, chars)
        return down

    def char_by_token(self):
        return {'卡': self, '夏': self.teammate('Ciaccona'), '千': self.teammate('Chisa')}

    def handoff(self, from_char, to_char):
        if from_char is None:
            from_char = self
        self.task.in_liberation = False
        try:
            from_char.switch_out(con_full=False)
        except Exception:
            pass
        to_char.is_current_char = True
        to_char.has_intro = False
        to_char.has_sub_dps_intro = False
        to_char.last_switch_in_time = time.time()
        self.cur = to_char

    def force_release_con(self):
        for name, value in (('current_con', 0), ('con_full', False)):
            try:
                setattr(self, name, value)
            except Exception:
                pass
        self.is_current_char = True
        self.has_intro = False
        self.has_sub_dps_intro = False

    # ==================== 变奏段补切卡提 ====================
    def _retap_self_key(self):
        key = str(self.index + 1)
        for i in range(self.L_CART_RETAP_TIMES):
            self.task.send_key_down(key)
            self.macro_wait(self.L_CART_RETAP_PRESS)
            self.task.send_key_up(key)
            self.macro_wait(self.L_CART_RETAP_GAP)
        self.macro_mark(f'补切卡提x{self.L_CART_RETAP_TIMES}')

    # ==================== 启动轴前补切卡提 ====================
    def _ensure_cartethyia_initial(self):
        key = str(self.index + 1)
        for _ in range(self.L_OPENER_CART_TAP_TIMES):
            self.task.send_key_down(key)
            self.macro_wait(self.L_OPENER_CART_TAP_PRESS)
            self.task.send_key_up(key)
            self.macro_wait(self.L_OPENER_CART_TAP_GAP)
        self.macro_wait(self.L_OPENER_CART_TAP_AFTER)
        self.cur = self
        self.is_current_char = True
        self.macro_mark('补切卡提(启动轴前)')

    # ==================== API 探针 ====================
    def _try_attr(self, name):
        try:
            v = getattr(self, name, None)
            if v is None:
                return 'N/A'
            if callable(v):
                return v()
            return v
        except Exception as e:
            return f'ERR:{type(e).__name__}'

    def _probe_apis(self):
        if self._api_probed:
            return
        self._api_probed = True
        results = []
        for name in ('is_forte_full', 'liberation_available', 'resonance_available'):
            results.append(f'{name}={self._try_attr(name)!r}')
        self.logger.info(f'KXQ-PROBE API: {", ".join(results)}')

    # ==================== R 空按检测 ====================
    def _r_hud_effective(self, pressed_at, tag, watch=None):
        watch = self.R_HUD_WATCH if watch is None else watch
        deadline = pressed_at + watch
        while time.perf_counter() < deadline:
            self.safe_next_frame()
            if not self.safe_in_team():
                self.macro_mark(f'{tag}HUD掉(+{time.perf_counter() - pressed_at:.2f})')
                return True
            time.sleep(self.R_HUD_POLL)
        return False

    def _do_ar_compensation(self, tag, idx, cap, a_gap, role):
        deadline = time.perf_counter() + cap
        rnd = 0
        while time.perf_counter() < deadline:
            rnd += 1
            self.safe_click()
            self.macro_wait(a_gap)
            r_down = self.tap('R', self.EQR_R_HOLD)
            if self._r_hud_effective(r_down, f'RCHK {tag}#{idx}{role}补R#{rnd}',
                                     watch=self.R_HUD_WATCH):
                self.macro_mark(f'RCHK {tag}#{idx}{role}R补偿成功#{rnd}')
                self._comp_count += 1
                return r_down
            self.macro_mark(f'RCHK {tag}#{idx}{role}补R#{rnd}没出')
        self.macro_mark(f'RCHK {tag}#{idx}{role}R补偿超时')
        self._comp_count += 1
        return None

    def _check_and_compensate_r(self, original_r_down, tag, idx, role):
        if self._r_hud_effective(original_r_down, f'RCHK {tag}#{idx}原R[{role}]'):
            return 0.0

        self.macro_mark(f'RCHK {tag}#{idx}{role}R空按,补按')
        new_r_down = self.tap('R', self.EQR_R_HOLD)

        if self._r_hud_effective(new_r_down, f'RCHK {tag}#{idx}补R[{role}]'):
            self.macro_mark(f'RCHK {tag}#{idx}{role}R补按生效')
            self._comp_count += 1
            return new_r_down - original_r_down

        self.macro_mark(f'RCHK {tag}#{idx}{role}R补按也失败')
        self._comp_count += 1

        if role == 'chisa':
            self.macro_mark(f'RCHK {tag}#{idx}千咲R失败,进A↔R循环')
            comp_r_down = self._do_ar_compensation(
                tag, idx, self.COMP_CHISA_R_CAP, self.COMP_CHISA_R_A_GAP, 'chisa')
            if comp_r_down is not None:
                return comp_r_down - original_r_down
            self._chisa_r_failed = True
            return new_r_down - original_r_down

        self.macro_mark(f'RCHK {tag}#{idx}夏空R失败,进A↔R循环')
        comp_r_down = self._do_ar_compensation(
            tag, idx, self.COMP_CIAC_R_CAP, self.COMP_CIAC_R_A_GAP, 'ciaccona')
        if comp_r_down is not None:
            return comp_r_down - original_r_down
        self.macro_mark(f'RCHK {tag}#{idx}夏空R补偿超时→CycleAbort')
        raise CycleAbort(f'夏空R补偿超时({tag}#{idx})')

    def _do_jump_fall_compensation(self, tag='FCJump'):
        self.macro_mark(f'{tag}开始@{time.perf_counter() - self.macro_t0:.2f}')
        self.macro_wait(self.COMP_WAIT_BEFORE_JUMP)
        self.tap('SP', self.JUMP_HOLD)
        jump_done = time.perf_counter()
        self.macro_mark(f'{tag}跳@{jump_done - self.macro_t0:.2f}')
        self.macro_wait(self.L_CIAC_L1_GAP)
        fall_down = self.tap('L', self.L_CIAC_L2_HOLD)
        self.macro_mark(f'{tag}下落(A@{fall_down - self.macro_t0:.2f})')
        self.macro_wait(self.L_CIAC_FALL_TO_LAND)
        end_time = time.perf_counter()
        self.macro_mark(f'{tag}结束@{end_time - self.macro_t0:.2f}')
        return end_time + 0.05

    # ==================== 变奏段变身 R 补偿 ====================
    def _do_transform_compensation(self, tag='TFCOMP'):
        deadline = time.perf_counter() + self.COMP_TRANSFORM_CAP
        rnd = 0
        while time.perf_counter() < deadline:
            rnd += 1
            self.safe_click()
            self.macro_wait(self.COMP_TRANSFORM_A_GAP)
            r_down = self.tap('R', self.EQR_R_HOLD)
            if self._r_hud_effective(
                    r_down, f'{tag}#{rnd}',
                    watch=self.COMP_TRANSFORM_R_HUD_WATCH):
                self.macro_mark(f'{tag}#{rnd}变身成功')
                self._comp_count += 1
                self.wait_anim(f'{tag}#{rnd}收尾', self.CART_TRANSFORM_ANIM)
                return True, r_down
            self.macro_mark(f'{tag}#{rnd}没出')

        self.macro_mark(f'{tag}超时{self.COMP_TRANSFORM_CAP:.1f}s→CycleAbort')
        self._comp_count += 1
        raise CycleAbort(f'变奏段变身补偿超时({self.COMP_TRANSFORM_CAP:.1f}s)')

    # ==================== 芙段 R2 补偿 ====================
    def _do_fleur_r2_compensation(self, tag='FR2C'):
        for rnd in range(self.COMP_FLEUR_ROUNDS):
            self.macro_mark(f'{tag}轮{rnd + 1}开始@{time.perf_counter() - self.macro_t0:.2f}')
            for _ in range(self.COMP_FLEUR_A_FIRST):
                self.safe_click()
                self.macro_wait(self.COMP_FLEUR_A_GAP)
            self.wait_hud_up(tag=f'{tag}轮{rnd + 1}切回大卡')
            self.tap('R', self.EQR_R_HOLD)
            self.macro_mark(f'{tag}轮{rnd + 1}切换R')
            for _ in range(self.COMP_FLEUR_A_SECOND):
                self.safe_click()
                self.macro_wait(self.COMP_FLEUR_A_GAP)
            self.wait_hud_up(tag=f'{tag}轮{rnd + 1}末R前')
            r_down = self.tap('R', self.EQR_R_HOLD)
            self.macro_mark(f'{tag}轮{rnd + 1}末R按下@{r_down - self.macro_t0:.2f}')
            if self.wait_hud_gone(self.COMP_FLEUR_R_HUD_WATCH, r_down,
                                  tag=f'{tag}轮{rnd + 1}末R'):
                self.macro_mark(f'{tag}轮{rnd + 1}出手')
                self.wait_anim('芙大招', self.FLEUR_LIB_ANIM)
                return True
            self.macro_mark(f'{tag}轮{rnd + 1}没出')

        self.macro_mark(f'{tag}补偿失败({self.COMP_FLEUR_ROUNDS}轮)→CycleAbort')
        self._comp_count += 1
        raise CycleAbort(f'芙段R2补偿失败({self.COMP_FLEUR_ROUNDS}轮)')

    def _do_fleur_r2(self, tag='FR2'):
        fleur_start = time.perf_counter()
        self.click_until(fleur_start + self.FLEUR_A_FIRST)
        self.macro_mark(f'{tag}芙A完({self.FLEUR_A_FIRST:.2f}s)')

        self.wait_hud_up(tag=f'{tag}前')
        r_down = self.tap('R', self.EQR_R_HOLD)
        self.macro_mark(f'{tag}#1按下@{r_down - self.macro_t0:.2f}')
        if self.wait_hud_gone(self.R2_PRESS_WATCH, r_down, tag=f'{tag}#1'):
            self.macro_mark(f'{tag}#1出手')
            self.wait_anim('芙大招', self.FLEUR_LIB_ANIM)
            return True

        self.macro_mark(f'{tag}#1没出,切回小卡,进补偿序列')
        self._comp_count += 1
        return self._do_fleur_r2_compensation(tag)

    # ==================== 宏回放 ====================
    def play_macro(self, macro, tag, start=None, done_mark=True, r_checks=None):
        r_checks = r_checks or {}
        chars = self.char_by_token()
        now = time.perf_counter()
        t0 = now if start is None else start
        if t0 < now:
            if now - t0 > 0.02:
                self.macro_mark(f'{tag}起点晚{now - t0:.2f}s')
            t0 = now
        self.sleep_until(t0)
        at = 0.0
        last_down = t0
        worst = 0.0
        late = []
        for i, (token, hold_ms, gap_ms) in enumerate(macro):
            down_at = t0 + at
            hold = hold_ms / 1000.0
            gap = 0.0 if gap_ms is None else gap_ms / 1000.0
            up_at = down_at + max(hold, self.MIN_KEY_HOLD)
            next_at = down_at + hold + gap
            if gap_ms is not None and up_at > next_at:
                up_at = next_at
            self.sleep_until(down_at)
            lag = time.perf_counter() - down_at
            self.press_down(token, chars)
            worst = max(worst, lag)
            if lag > self.LATE_WARN:
                late.append(f'#{i}{token}+{lag * 1000:.0f}ms')
            if token in SWITCH_TOKENS or token in ('E', 'Q', 'R'):
                self.macro_mark(f'{tag}{token}')
            last_down = down_at
            self.sleep_until(up_at)
            self.press_up(token, chars)

            if token == 'R' and i in r_checks:
                role = r_checks[i]
                delay = self._check_and_compensate_r(down_at, tag, i, role)
                if delay > 0:
                    t0 += delay

            at += hold + gap

        if macro:
            self.sleep_until(t0 + at)
        end_time = t0 + at

        if done_mark or late:
            self.macro_mark(f'{tag}{"宏完" if done_mark else "宏前段"}(最晚+{worst * 1000:.0f}ms'
                            + (f' {",".join(late)}' if late else '') + ')')
        return end_time, last_down

    # ==================== 读屏原语 ====================
    def wait_anim(self, tag, time_out, gone_grace=None):
        gone_grace = self.ANIM_GONE_GRACE if gone_grace is None else gone_grace
        start = time.perf_counter()
        wall = time.time()
        gone = False
        while time.perf_counter() - start < time_out:
            self.safe_next_frame()
            if not self.safe_in_team():
                gone = True
            elif gone:
                break
            elif time.perf_counter() - start >= gone_grace:
                break
            time.sleep(0.01)
            self.check_enabled()
        back = time.perf_counter()
        if gone:
            self.add_freeze_duration(wall, back - start)
        self.macro_mark(f'{tag}({"演出" if gone else "没演出"},{back - start:.2f}s)')
        return gone, back

    def wait_hud_up(self, cap=0.8, tag='HUD'):
        start = time.perf_counter()
        while time.perf_counter() - start < cap:
            self.safe_next_frame()
            if self.safe_in_team():
                return True
            time.sleep(0.02)
        return False

    def wait_hud_gone(self, cap, pressed_at, tag):
        start = time.perf_counter()
        while time.perf_counter() - start < cap:
            self.safe_next_frame()
            if not self.safe_in_team():
                self.macro_mark(f'{tag}演出(+{time.perf_counter() - pressed_at:.2f})')
                return True
            time.sleep(0.01)
            self.check_enabled()
        return False

    def click_until(self, target, interval=None):
        interval = self.A_INTERVAL if interval is None else interval
        n = 0
        while True:
            now = time.perf_counter()
            if now >= target:
                return n
            self.safe_click()
            n += 1
            self.sleep_until(min(target, now + interval))

    def on_field_char(self, time_out=0.5):
        start = time.time()
        while time.time() - start < time_out:
            for char in self.task.chars:
                if char is not None and getattr(char, 'is_current_char', False):
                    return char
            time.sleep(0.05)
        return None

    def add_freeze_duration(self, wall, duration):
        pass

    # ==================== 轴步骤 ====================
    def run_opener_macro(self):
        # 启动轴前补切卡提（防前场不是卡提）
        self._ensure_cartethyia_initial()

        t0, _ = self.play_macro(
            OP_SEG1_A, 'op1a',
            r_checks={OP_SEG1_A_CHISA_R: 'chisa'},
        )
        t0, _ = self.play_macro(OP_SEG1_B, 'op1b', start=t0)
        if self._chisa_r_failed:
            self._chisa_r_failed = False
            t0 = self._do_jump_fall_compensation('FCJump_op')
        t0, _ = self.play_macro(
            OP_SEG1_C, 'op1c', start=t0,
            r_checks={OP_SEG1_C_CIAC_R: 'ciaccona'},
        )
        t0, _ = self.play_macro((OP_CHISA_E,), 'op_e2', start=t0)
        t0, _ = self.play_macro(OP_SEG2, 'op2', start=t0)
        t0, _ = self.play_macro(OP_LAST, 'op_last', start=t0)
        self.cur = self
        self.is_current_char = True
        # 记录启动轴结束时间，供 F 监视判断"新 session"
        self.task._opener_last_time = time.time()

    def run_loop_macro(self):
        t0, _ = self.play_macro(LOOP_SEG1, 'loop1')
        self.ciac_heavy_then_switch('loop_ciac')
        t0, _ = self.play_macro(
            LOOP_SEG2_A, 'loop2a', start=t0,
            r_checks={LOOP_SEG2_A_CHISA_R: 'chisa'},
        )
        if self._chisa_r_failed:
            self._chisa_r_failed = False
            t0 = self._do_jump_fall_compensation('FCJump_loop')
        t0, _ = self.play_macro(
            LOOP_SEG2_B, 'loop2b', start=t0,
            r_checks={LOOP_SEG2_B_CIAC_R: 'ciaccona'},
        )
        t0, _ = self.play_macro((LOOP_CHISA_E,), 'loop_e2', start=t0)
        t0, _ = self.play_macro(LOOP_SEG3, 'loop3', start=t0)
        t0, _ = self.play_macro(LOOP_LAST, 'loop_last', start=t0)
        self.cur = self
        self.is_current_char = True

    def ciac_heavy_then_switch(self, tag):
        chars = self.char_by_token()
        self.tap('L', self.L_CIAC_L1_HOLD)
        self.macro_mark(f'{tag}夏空L1')
        self.macro_wait(self.L_CIAC_L1_GAP)
        self.tap('L', self.L_CIAC_L2_HOLD)
        self.macro_mark(f'{tag}夏空L2下落')
        self.macro_wait(self.L_CIAC_FALL_TO_LAND)
        self.tap('L', self.L_CIAC_LAND_A_HOLD)
        self.macro_mark(f'{tag}夏空落地A')
        self.macro_wait(self.L_CIAC_LAND_A_GAP)
        self.tap('RB', self.L_CIAC_RB_HOLD)
        self.macro_mark(f'{tag}夏空RB')
        self.press_down('L', chars)
        self.macro_wait(self.L_CIAC_HEAVY_HOLD)
        self.press_up('L', chars)
        self.macro_mark(f'{tag}夏空重击')

    def _eqr_burst(self, tag):
        self.macro_wait(self.EQR_AFTER)
        for _ in range(self.EQR_E_TAPS):
            self.tap('E', self.EQR_E_HOLD)
            self.macro_wait(self.EQR_E_TAP_GAP)
        self.tap('Q', self.EQR_Q_HOLD)
        r_down = self.tap('R', self.EQR_R_HOLD)
        self.macro_mark(tag)
        return r_down

    def run_common_cycle(self, after_fleur_switch=False):
        # ---------- 变奏段 ----------
        self.macro_mark('变奏段开始')
        self.macro_wait(self.L_INTRO_TO_JUMP)
        self._retap_self_key()
        self.macro_wait(self.L_CART_RETAP_AFTER)

        self.tap('SP', self.JUMP_HOLD)
        self.macro_wait(self.JUMP_TO_AIR_A)
        self.tap('L', self.AIR_A_HOLD)
        self.macro_wait(self.AIR_A_RETRY)
        self.tap('L', self.AIR_A_HOLD)
        self.macro_wait(self.L_JUMP_TO_LANDED)

        eqr_start = time.perf_counter()
        while time.perf_counter() - eqr_start < self.EQR_WAIT_CAP:
            self.safe_click()
            self.safe_next_frame()
            ready = True
            try:
                if hasattr(self, 'get_resonance_cd') and self.get_resonance_cd() > 0:
                    ready = False
                if hasattr(self, 'get_liberation_cd') and self.get_liberation_cd() > 0:
                    ready = False
            except Exception:
                pass
            if ready:
                break
            time.sleep(0.1)

        r_down = self._eqr_burst('EQR变身')
        gone, back = self.wait_anim('变身', self.CART_TRANSFORM_ANIM)

        if not gone:
            ok, r_down_comp = self._do_transform_compensation('TFCOMP')
            r_down = r_down_comp

        # ---------- 剑切宏 ----------
        sword_start = r_down + self.L_R1_TO_SWORD
        self.macro_mark(f'剑切宏起手@{sword_start - self.macro_t0:.2f}')
        for dt in self.SWORD_E_PREPRESS:
            if sword_start - dt > time.perf_counter():
                self.sleep_until(sword_start - dt)
                self.tap('E', self.SWORD_E_PREPRESS_HOLD)
        t0, sword_r_down = self.play_macro(SWORD_MACRO, 'sword', start=sword_start)
        self.macro_mark(f'剑切R@{sword_r_down - self.macro_t0:.2f}')

        # ---------- 小卡段 ----------
        small_base = sword_r_down
        chars = self.char_by_token()

        self.sleep_until(small_base + self.L_SMALL_A_FROM)
        self.click_until(small_base + self.L_SMALL_HOLD_AT)

        self.press_down('L', chars)
        self.sleep_until(small_base + self.L_SMALL_HOLD_UP)
        self.press_up('L', chars)
        self.macro_mark('小卡重击')

        self.sleep_until(small_base + self.L_SMALL_JUMP_AT)
        self.tap('SP', self.JUMP_HOLD)
        jump_done = time.perf_counter()
        self.macro_mark(f'小卡跳@{jump_done - self.macro_t0:.2f}')
        self.macro_wait(self.JUMP_TO_AIR_A)
        last_fall_a = self.tap('L', self.AIR_A_HOLD)
        self.macro_mark(f'小卡三剑下落(A@{last_fall_a - self.macro_t0:.2f}, '
                        f'跳后{last_fall_a - jump_done:.2f}s)')

        r_at = max(small_base + self.L_SMALL_R_AT,
                   last_fall_a + self.SMALL_FALL_SETTLE)
        self.sleep_until(r_at)
        r_down_small = self.tap('R', self.EQR_R_HOLD)
        self.macro_mark(f'小卡R变芙(按下@{r_down_small - self.macro_t0:.2f}, '
                        f'目标@{r_at - self.macro_t0:.2f}, '
                        f'下落A后{r_down_small - last_fall_a:.2f}s)')
        self.wait_anim('小卡变芙', self.CART_TRANSFORM_ANIM)

        # ---------- 芙段 ----------
        self.macro_mark(f'芙段开始@{time.perf_counter() - self.macro_t0:.2f}')
        self._do_fleur_r2('FR2')
        self.macro_mark(f'芙段结束@{time.perf_counter() - self.macro_t0:.2f}')

        if after_fleur_switch:
            self.force_release_con()
            self.macro_mark('芙后压con')

    # ==================== 核心入口 ====================
    def do_perform(self):
        if not self.is_in_kxq_cycle:
            super().do_perform()
            return

        if self.cur is None:
            self.cur = self

        try:
            self.macro_start()
            self._probe_apis()

            if self.opener_pending():
                self.logger.info('kxq: running opener macro')
                self.run_opener_macro()
                self.last_opener = time.time()
                self.opener_armed = False
                self.run_common_cycle(after_fleur_switch=False)
            else:
                self.logger.info('kxq: running loop macro')
                self.run_loop_macro()
                self.run_common_cycle(after_fleur_switch=True)

            self.cur = self
            self.is_current_char = True
            self.logger.info(
                f'kxq: cycle done at: {self.macro_timeline()} '
                f'(ignored_combat_lost={self._ignored_combat_lost}, '
                f'compensations={self._comp_count})'
            )
        except CycleAbort as e:
            self.logger.warning(
                f'kxq: CycleAbort ({e}) at: {self.macro_timeline()} '
                f'(compensations={self._comp_count})'
            )
            self.release_all()
            if self.opener_armed is False and self.last_opener >= 0:
                elapsed = time.time() - self.last_opener
                if elapsed < self.OPENER_MIN_GAP:
                    self.last_opener = -1
                    self.opener_armed = True
            return
        except Exception as e:
            self.logger.warning(f'kxq aborted ({type(e).__name__}: {e}) at: {self.macro_timeline()}')
            self.release_all()
            raise