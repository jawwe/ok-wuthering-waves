import base64
from collections import deque
import os
import time
from threading import Thread
from time import perf_counter

import cv2
import numpy as np

from src.char.Hiyuki import Hiyuki as NativeHiyuki


class KendoChainReady(RuntimeError):
    """【v115】末尾两刀已发完、不再等读豆：立刻去起强化重击（不是失败）。"""


class Hiyuki(NativeHiyuki):
    """千咲/绯雪/洛瑟菈固定轴。其他两个角色通过 task.chars 委托到这里。"""

    AXIS_BUILD = 'CHL-20261015-Hiyuki-E115-first-noA-LucillaE070-comp158-HUDstop-v125'
    SWITCH_TIMEOUT = 3.5
    # 变奏前限时补协奏；超过上限后允许降级平切。
    INTRO_CON_FILL_CAP = 6.0
    CHISA_INTRO_CON_FILL_CAP = 12.0  # 千咲补协奏上限，其他角色使用通用上限
    INTRO_HOLD_TIMEOUT = 8.0
    # 以下为旧强化E辅助参数，当前主轴不使用。
    POST_R_SETTLE = 0.0  # 历史值；R后不追加固定等待
    CHI_PROBE_INTERVAL = 0.20
    CHI_PROBE_COUNT = 8
    # 一阶段跨变奏和Q保持攻击，并尝试R1。
    PHASE1_MIN_HOLD = 0.00
    PHASE1_R_INTERVAL = 0.15
    # 常态E点按起飞；二阶段长按时长由PHASE2_E_HOLD控制。
    TAKEOFF_E_HOLD = 0.05
    TAKEOFF_E_SETTLE = 0.05  # 第18格交接保留；第1格启动E不追加等待
    # 跨切人保持E预输入；洛瑟拉到场后按LUCILA_E_HOLD计时松手。
    LUCILA_E_PREINPUT = True
    LUCILA_E_HOLD = 0.70          # 洛瑟拉到场后的E保持时长
    # 洛瑟拉补协奏时每次重击的按住时长。
    LUCILA_COMP_HEAVY_HOLD = 1.58
    # 洛瑟拉二阶段第二拍起在按住A期间检测HUD和通用重击提示。
    LUCILA_PHASE2_A_HOLD = 0.60
    LUCILA_PHASE2_A_GAP = 0.02
    LUCILA_PHASE2_POLL = 0.03
    LUCILA_PHASE2_OUTPUT_CAP = 9.0
    LUCILA_HUD_RETURN_CAP = 25.0
    LUCILA_E_PREINPUT_MAX = 3.0   # 从按下到松开的硬上限，只做防卡键兜底(不是功能限制)
    CHISA_E_NO_ATTACK_WINDOW = 1.20  # R收招/图标过渡期间先等E，不插普攻
    CHISA_E_CONFIRM_CAP = 1.20    # 点按后等确认的上限，超时先松开预输入键再重试
    # 旧强化E重试参数。
    CHI_RETRY_GAP = 0.05          # 快补间隔（先快补 CHI_RETRY_CAP 发）
    CHI_RETRY_CAP = 6             # 快补发数上限
    CHI_SLOW_RETRY_GAP = 0.35     # 超过上限后退回的补按间隔（= 原行为）
    # 旧强化E冷却确认阈值。
    CHISA_E_CD_CONFIRM = 0.2
    # 旧空中居合参数，当前主轴不使用。
    AIR_KENDO_INTERVAL = 0.60
    AIR_KENDO_TO_PLUNGE = 0.55
    AIR_KENDO_COUNT = 2
    AFTER_PLUNGE = 0.90
    HEAVY_FORTE_SETTLE = 1.20
    # 落地E后接普攻的等待时间。
    CHISA_LANDING_E_SETTLE = 0.05
    # 来源：Chisa__Suisui__YangYangSp 普通 A 表(50ms 按下 + 200/250/350~450ms gap)。
    CHISA_NORMAL_A_GAPS = (0.20, 0.25, 0.45)
    # 从首次普攻起计时发送切人键，到场确认另计。
    CHISA_SAW_SWITCH_DELAY = 1.50
    CHISA_SAW_TAP_GAP = 0.10
    CHISA_FINISHER_SETTLE = 0.30
    # 未观察到离地时，超过等待窗口可用连续两帧声骸图标亮确认落地。
    CHISA_LANDING_ARM_FALLBACK = 0.45
    # 残响条使用逐格填充终点与亮星交叉确认；HUD缩放变化后需重新标定。
    SAW_GATE_ENABLED = True      # False = 只打探针、不改轴行为(标定用)
    SAW_PROBE_SECONDS = 2.2      # 探针模式下平A的时长(与原来的定时平A等长)
    # 按相对坐标裁框，统一到372×11标定尺寸后读取。
    SAW_BOX = (0.4219, 0.9250, 0.5672, 0.9326)   # (x1, y1, x2, y2)，画面比例；x2 开区间
    SAW_MID_WIDTH = 24           # 中点小框只进诊断日志，不参与判据(屏幕像素)
    # 实测：填充亮品红≈(255,80,180)，空轨灰≈(130,140,140)，所以判据要"红高、绿低"
    SAW_LIT_COLOR = {'r': (100, 255), 'g': (0, 120), 'b': (50, 235)}
    SAW_REF_SIZE = (372, 11)
    SAW_CELL_FIRST = 8          # 格子中心，1440p采样框内坐标
    SAW_CELL_PITCH = 9
    SAW_CELL_COUNT = 40         # 用户确认总数固定40，不逐帧重新寻找总格数
    # 固定几何索引只算一次；只读数组，逐帧状态仍独立计算。
    SAW_CELL_CENTERS = SAW_CELL_FIRST + np.arange(SAW_CELL_COUNT) * SAW_CELL_PITCH
    SAW_PATCH_INDEX = SAW_CELL_CENTERS[:, None] + np.arange(-2, 3)
    SAW_CORE_INDEX = SAW_CELL_CENTERS[:, None] + np.arange(-1, 2)
    SAW_GAP_INDEX = SAW_CELL_CENTERS[:, None] + np.arange(3, 5)
    SAW_CELL_CENTERS.setflags(write=False)
    SAW_PATCH_INDEX.setflags(write=False)
    SAW_CORE_INDEX.setflags(write=False)
    SAW_GAP_INDEX.setflags(write=False)
    SAW_CELL_LIT_MIN = 0.50     # 格子中心5x7像素中明确品红的比例
    SAW_STAR_EDGE_TOLERANCE = 0.04  # 亮星与逐格终点最多差约1.5格
    # 放R门槛按真实条长比例计算。
    SAW_LIT_MIN = 0.60
    # 最近窗口内累计足够命中，防止单帧特效误判。
    SAW_CONFIRM_HITS = 4
    SAW_CONFIRM_WINDOW = 6
    SAW_PEAK_TOLERANCE = 0.20    # 当前帧必须 ≥ peak-0.20 才算"真的还在高位"(挡 v20 那种假高后暴跌)
    # 落地E特效可能染色；等待稳定并排除峰值后的大幅回落。
    SAW_SETTLE = 0.9             # 秒：进这一步后先不打判定
    SAW_DROP_TOLERANCE = 0.05    # 只用于回落诊断
    SAW_FILL_CAP = 6.0           # 单次识别上限；未确认则交回框架保留本步重试，不越过门槛放R
    SAW_FILL_INTERVAL = 0.15     # 千咲普攻2段带派生，点太密互相吞
    # 读条采样与普攻节奏独立。
    SAW_SAMPLE_INTERVAL = 0.08
    # 居合豆使用梯度模板匹配，最多识别3个。
    HIYUKI_IAI_BOX = (0.4023, 0.8958, 0.6094, 0.9479)   # 相对坐标 (x1, y1, x2, y2)
    HIYUKI_IAI_REF_SIZE = (2560, 1440)                    # 模板与去重距离的标定分辨率
    HIYUKI_IAI_MATCH_MIN = 0.40                          # 梯度匹配置信阈值
    HIYUKI_IAI_MIN_GAP = 40                              # 两个图标中心至少隔这么多像素才算两个
    HIYUKI_IAI_MAX = 3                                   # 上限
    HIYUKI_IAI_TPL_B64 = (
        'iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAIAAACR5s1WAAAUZklEQVRYCR3BB3gVZboA4O//p5wpp9ckpBNNIBSVJt2OXVEU'
        'UVGU9VGxIAooKmABAQsiuLIqrmvbx4a6uqhI8SIgJSEQAumE1JOcnF5mzrR/5nrv+6IHnvhFymIlT8bWjK4dU1ZWCgjD4YNd'
        'R44exIAURaOwDSyKGJRpWggYimExxpZFMCDjL7oFQGNEY4wBwAKdosE0NdPSTcuwLIIxIERhygRsakShaCyKvCjygAxFzaqa'
        'zLAWWr3hJM/zNlYcWV5s58Ey4PDhgZP1jYRYQICiKAATAAjRddPCiKFpFiPashC2gBCLGGBZFFjoL5hCAAbCpgW6BZppaoBM'
        'AAshbGEwgVAUwhQgZNIMMCwgbJiWDFhF+w9bxASMofe8CqatqaGr/tiZvGwEfUFB4NS8An9BBjFlw7QwOGiKx4i2LMsgGpjk'
        '/1nEAIQQRWOKojCiEAZAmmUZFuiACIAJ2DJNg2VZE2FZlg1DFUTW4eZZTlVJGB06aiUS0NcndXV1DXRHh3qJyIc8Tte5zlaX'
        'mxZ4O1EYCwzVithYu5L1ANhtHNXT26lrEi8gTGsG0SgkcDbRIHo2o+RzlCA4S8tCCBsGUTgeqVqOYgyL5F1OXzKly3lSXl4+'
        'HI0CRZVUcBnjCHps6fFcNp9Op8E0TF0c7IaqikscnLOx6XjAD5ZFKNOrqiowWdM00mkqm8lzIpSUhKZOnujzg8sDCAEx4C+E'
        'gK5DX4/Z093f0dkWj8cddpfD4bAsZOMoZMomIL+3ou3c+YmTxmblfHtruOxCATlOoHl3f2cayDSBqCaN/B1npJuuu86QYe/+'
        '+qoqjphKPicYOrYsfSja6S2AG2+ZMXVGoLoaEAGWAQSgKCDLYAHYbGDjgRdBVeH0KTh2JNxQ39l2NopIQShYTKGcRhRRcJ1p'
        'b7jj7ssolv3y08OXTKmmXCfRrXd+jYGhMEeZQi6D25ria1fd0nMePvrnb9XVI9R8hqGFnt7zFZUFc66/9Io5UD0KevrgxAmj'
        'pzMaG5bCA7FEImEQWRBtPp/P7eH9ITxqdPXY0Vx5GXR1ws5v1ON/nuvuigic6Pf7DYK6+hseeerKgkL3iyu/Gz1ulCN4Ht11'
        '389AsEUEynRFB+VsUn3vvdmnTsHrm772iqNT6QSiBu64e8b8e0sqK6GxDn74Vm5sao4MJfMZhIDhOM7upBmbrihyNm2qqqbr'
        'it0hBPxFl04dN+d6mDwVwkPwwfvn9+1qlbNcIFAWz7U+s3rmmHGOpx45iGk+WBpD99z/h2mALrEM8kWGkgJHv/X2xa3t8PrG'
        'L41sqdvtvXthzW3zYWAIPv+08dC+wWgY2x0hgXc5RS9CiKIQzViIki3LApPHyJZK5cBC2VxmaPgcy2fvWDB78SPewgL44St4'
        'Y8MhVeEYPv7ylqurqvGqJxuTCc1dlESLFp02dEQUmqhCX093oIB6ce30rATrXt2eGGIXP7j44Yfht92wY/vp0ye7vN5g8YgK'
        'nnOaJsGUgRCYpqXrOiEGwoRhKIpiHGIwEokyrGWzsX19/f0D50ePLZp3x8R7F8IXn8E7bx0LFlIvvT3R7YOXVpweGMj6i1W0'
        '8J5WXQNs8lgX2jubisvZF9ZOFxzwzNPv9nXAzm8ebzkL61/5ITHkHjN6MssZCFkI0aZJTJAwxsjiADD1F5qYIGmapiscz/OI'
        '0mRJEflQJpNq7TjK8tryFbfdcANcfcXeygsdq16b4vfDq893NZ3qKa+2oUV3d+kaGDqtZkkqGQkUwcrnp1RUwycfn/1429k7'
        '5975067fTRNGVU2wLKQqEgAIvMsykaLKugqyZNlFZzIV4UXMC1jTNJEvQAixnP6XvAScgDwB7djxP3KScc89dx44fOCa68ff'
        'Mt9NdNiwurvlzOCIkSa6/+4OolFg8kjjTzYerRnje2bVRF8RZJKw5qkTXW0qpqUbbryaBmhoaPe43JZl6YqeSWezsiTwHiAu'
        'iqJEB+TVlCznLAshixNFkWaJ2+1maTEc6bxkSsCyyLdfH/L7PVnj7Nt/f7S6FmJDsP2tZGNDT7BYQyuWRpJRWZFY2gq1t52p'
        'qEbLnhuHBXCIsG3j4I87j1VU+leunHH8EBw62OHz+HUln8slRKfN5RUH+mNSWiwsLJw8VThzNtLa0hMKFtntgmWhSCQq8HaH'
        'wxFLnps0PTRtauGbr3X2DHRccTO9au3V6azJU/jvG/WDB1rLL6DQe5utTBJUGaID0NLaSvHhNeuucBeCjYWm4/DuO3sEnt20'
        'YfZXn8Gfh9rAIIToYFoTLx1XXokPHGztbJFqa2svv4Y7dmzwRF3HmNETRteK0SicqDunKCrCBmeXJkz1PLi4ZsNL+qnTh199'
        'Z8bkGXRfLwGVWr2sLRWjPSEDvbY6pcrI0Gy95xOtzWdKR3qXPDUhVAGYApGF1187erqh89OP7931Pez4cK/bYWNoXkrhSyaN'
        'u7CWbjrb01g/PHLkyNqLvO3tbWdPh8ePvXT8eL61FU6fanM6nYaZjaZOP/Do1MV/G7Fg3ilvwL5uc1U8rdoFW/85ePm5Y6rk'
        '8Ph5tP6FhK7SmkLVHTkNABOmjBtzsTD1KhiOJd0OT18PfPnZrjUv3NB6Gp579svpk6extLf+cK8g8pdfWzEUjR491FNTPap6'
        'jNjS2tLeMjRxwvTiEeyB/+mORqOzZ0/SDXP/wS+27Vg4ZjysfOaPm+fOmnkFnGyMjKkJ7f/NOvBbX393nhgUWv9sKps20km9'
        '+UzPpElTsE3Nac2rN1w8GM2oeRzw25vPREbXhJAOy5ft9IkXjBs17sBvUjjcP+uacoZHv//WWlpaPn2W8/CRlnA4PGvmlciC'
        'PXsOe/3ClVde3Hw2Gk+3v/vR9KQEvX3JESUesMAyoSQIq5//0+0sZZmi/+z8E61bnsqm9URCOXSw7pElc/vDSmPzrk3bbkdM'
        'imPdiUSmMOTUVKgsh6cf/3XnF2eeXrL8fDs0t7QVV7JTZ1Ts2x2Tcvmrri05cqxR05TLL5vS1pJtaGiYPn3syCrvjg+/umnu'
        'pS9vKmvtNjiBzsr5vIQ9Dpsqwapnv582bVrQF9q8cTdatyypKUx4aPj4yWPbtt1VVwf//mb7uzvu8QaAKE5iAMcZDINCQSoV'
        'h2tnfl1VPm3azOJDhxsyycytN1/WcFyLxSPTZ5ecPnNKN+ipl475aWeTy+W54oriffvrI/Gz3353f/EF0Nll6tggGPKS6Xdz'
        'vZ3w5BMf33rbtVOnFD758G60flkuk9TPnT8Xk/o/2HHLrh/gtdfXr331xnkLxod7TIbBFJ13e3iDQFEAPn4P3n7r23sXzsvl'
        '5CMHG8bUTCSEiSUGp88q/uXXfeUVtabBd7UPjB832i7AZ19uf2TJZSvWjBroAd4FCYnklHwum6+qDHz1L3jzzQ+Xrbhr5izH'
        '8seb0Ppn9OSwUn/qaLCM3rTpsl3fwbp1n15/U+X612fEE0AxwHHAcWBZ4HCAqcNtN34Q7vIse+KOX3+NhArcLKd397ZcOn3S'
        'yZONBaESWdL7uyPz7hj3yce7Tbp79/6HKQ4UCVQdZJ1Ium6Z2EazG1+M7N178KnnL3vwQf+SRRG0/hk1GVV+/2Nv9UXBF16Y'
        'UXcQNr910ONRVr9y9aixEE8Tp4PCFHi8kFcgEIA/9qgLbvpg3k1P+AJw+EjzRROLk+mw21MQjSaCgaIzTW2XjBufTCa//3Hr'
        'F1+tvewGyKZyPGsPR7LACMmMVlbKH9oHm9acTKbTi5dWL3m8cOlDGfTGi3omqf2y++eykQUbNs6o+xM2bdhHA7pyzphHlwY1'
        'AjQFdidwdh3TeV0nXodn2/rsW6/9Z9Gie/vCMQ1i5RWFkUhcFNxSWlNkavJFgZff3PH0yomrXrpIzgGFQckrqgF5AtkcF3DB'
        '1jcjP359zkDSshen3D7P+dKzSfTK03lVgb1794wcFVq3fvL+3bBl888loZGqEXnsqVnX3QSRCAhOoNkkzaoYMQLjQzI89MDR'
        '+vrw3Lm3dfW1u9yCZVI0bcsk5GCg+MC+49W1/AefjUUsYAskCTRFRwyTyCrBILdvF3zwbj0yi851n1j58qx5813PLh1Ai28f'
        'xqbteP3/1E5wv7hmVt1h2LplT2XJyOFo39hxhStWXWizgwYpl8syDd3tDmYS4HRBLg73zP/VMLyja2vS6WTA6+vvDxcVjDjf'
        '05xMdX25c74nCIYJal5jaDYdA6BAs8A0Yf0LvR3N+cJQeX3Tz8vXzLx3of/xxefQgusGWcrZ3HbEV5Ta+MbtkT544bldos3t'
        '9wZiw4Pz751x30NUWjYEUaKwSRQWI4ZlWU6EdAyWPHogl0FVlbW6Yrpcjo6ORtElb3n3ctEBmIFYPG0XOAw2KQOyDP4Q/PsL'
        'fce7Ry8on9Hb2z8wfHTtm9deeZVj1dIOtGjusCKBZiQk/eymN24zDXj80f/Y2ZKgtzwZTSnGwIoXZs65CeJpBeEUDTxns5sG'
        '0DaKtoGuwupnT3W2SNWVk3VDornImnXVnBNyEuF4PZtNC1xAlghNMRwLR4/A+pf3YFJs50qlnBZJ1m3//BqWhWWP7EeL7uhW'
        'ZdBUqfP88aeeWXT9jbBq5fHDe4Zrqqb5vK7+/haaTW79x8ziKsA0pJIph+DgBEqSLMQiYoKDgX2/wu+/Df33x13X3jhx4+bx'
        'BoBKcghpgsMdH8whcDoEGBqE5Uv3DPTRlaUTwORPnmycMrNwy4cjPv20c+umenTf/GNaHgyFPnmi/eprJmzacsFnn0Tff6ul'
        'euQM0aEoajbck/CHjLe3j3X6gOFAFEDKAGZB8EA8kfY6XZoM/efh1dXf1x1t27zluTnzIJuVOYGXJElVdZ/HE++FpU8eiMWw'
        '01HGUn5Flc82/7l0+c0PPQZr1zT88kMY3XX7b4aKTdUxeN4UHMbWHTPiMVi55JhoK6e5tMflpMDX39ciegb+8dF1JSNhYMB0'
        '2LGNB1lLsTyNLYbBNpoCMOCdTR1nm+s3b1+AGV3TTYa10QgSw7Dkwd+HBnBJWbkg+KUsDg+eY8WBze/M8fhg1XOHIn02dPtN'
        'uy2DsTS3knINDHQ8vGz2Aw9wj/1t8GR9V2VVkShysqxwrK2zrYMTcm9uu2HCZEjlgOE0lmYSyYzb4dJUsCxweQAM6OrUMkr3'
        '+IsuzEkGS9NNdfDcM7/nUlxl1SiN5Gy8Q5VtR+t+vX5u0eYtk3/aCa+s3VlZMRrNvWEXEA50F5GCfb3dnlD2p1+uP1EHLz6/'
        'x9CdPl9AFHWappUc1dj4e0Y99skXL11zfUEiThhMOd2gq5BJmR4PTiYNUaRZFhADqYxiF7njx7JP/O2zXNpfXjbKHwhZmKgq'
        'GR7KGtbw+/+aXVkJjz7Q2dEaL60oRXNv/MEyOdBdVi5g6Li7r37pijvmLYCtW3u+2HHW5SjGbAzjVOXIEZVVnomTC4pLxYpK'
        'KtxvjghilxNSOdlmQ0TjLRMwBhNANyGdkUIhsa1DbmnKdbRnhgaktrYwywaHhpJ5JTv/7jnPrxE+/8x4/aWdZcXj7S4Huvnm'
        'fyPCguZLDzoKAxUE4uH4ie3/vMsXgFdW9cajWvUY96gx/poaCBYAx0M6CT4fHNg39M3nP993352zr7LbeMimIJsFXQeEAVEA'
        'FJimSTPY6YBMFuIxaG+FluZEe0e3z+9+cHFlIgFvbPovUso4JhCLD6Nb531kGQzSgsm+QIG/oqLK6Qkq4yeJ02YAAkhngGaB'
        'mJBXIK8Qg6gWMR12e9AHn/4j+clH39SOK1lwz3XBEJSWgS8AyTTkNcA0ZLNKLpfjBI9lUmBCcQnoJuSyIPLAsXDsINQdVXIJ'
        'rvNcfyIRR/MWvG8SFuk+NVmg5JAFMm8n5eXemtElhSOcbg/t8QLHA0UBTYPNBiYBWQZDhUIPvLFJ/uWX/9KMWVDkvnhCzUWX'
        'lJugFRSyLAehEDAMKArYWMAY0lnQdMhK0NMlnT+X6G5P9PekpKwq5/Mjq0rR/IUfmgaDTJ7INLbsWp7L56jhoXwinnW73T6/'
        '28ZYoQK/KPIYgyiKrI1OpVKxWCyXzvv9QUO3MKbT6WwsFuM41jA0n9/NC4wocoIgMAyDEDYMQ9WM3p6hXD4v5fJyPmfneZ/f'
        'IdiRw41MyKD5C983CQOEIqrG0Z5cSkRG0FC8iswytCBJkq5mJDmlqFmGpTDGukbcbl95eamiJAKBgCxpugYsYycGUBRD03Q8'
        'EeF4JpWOJpPRvCJpmmKaJjHpsWOn93QPeLyi6KBMknZ6gOGzQKUYIY/uuv/vlsGYhKEIY2PcqYRhqKJluIkmUCDGYjGPl58y'
        'dbTbC01NHW3NHZpCUchj6MjnDSBE8ZydEGSZ2LIsXdedLj6VjvSHO4iVKyzysjZUWOSrrqnSFKqpMRYZSvn8dsGOdDPOiZqF'
        'k4DTiM6iexZvBcKahCYqiJwHLJumMJmkKWWBQU6MuHgiOmrUBTNmVU6cBE4R2lrh6BGlpzscHkj2dA9QFI0xpv4PTibjCBs1'
        'oyqLS0IFhb7aMc7aWrDboakJvvj8ZDgsOZ0uQLqmp50e2sZrij7MCQZgCd3/8GaLsIRYIsfncoqaByVvIdNGISfRbRS49Tw3'
        'FE6rinHRxbV33VU+dSbwDlAUaGuB813Q09sdj0eJqbg9dr/f43TZR4/yjygCCgNvg4Y62LK5obW5Lxj02RxqoNCRz2d1Q3a4'
        'WAsUw0xTjEazOlr06EaTUMRApmGAhXnOmUzIWh5sjFvOIQo8iLixZc+ktWhsECBVXOacdGnFxZeMqyhjCgsAUyCKQDOgavCX'
        'TAaGhiA6DL/va2o52xMJ54nOFRdVG5C3OZPEShpEcbp4YuYNIrm9Ns3IUrSOFj6yBgGDgLUIa1mUqhh52bQ0jkIOIA6TMERD'
        'AMDQNEa0lDOScdnUGBtrd7hdHMc5HV6Xy8MyrK4b+XxeN7Se3g5FkVRNYhjK4XDY7XaKoiykAJNClIwpgrAGtIJpFVMqpnVM'
        'qf8LPiqaL9S7mpgAAAAASUVORK5CYII='
    )
    # ---- 没敌人就结束这场战斗：轴里整段压住了框架的脱战判定，得自己查 ----
    ENEMY_RELOCK_CAP = 0.60     # 连续丢失后短重锁，恢复框架原超时
    ENEMY_CHECK_GAP = 0.4        # 秒：多久查一次"还有没有敌人"
    # 连续丢失达到阈值后短暂重锁；重锁失败才结束战斗。
    ENEMY_LOST_CONFIRM = 3
    # HUD持续不可读时中止；阈值需覆盖正常演出，且会优先于更长的HUD等待上限。
    HUD_LOST_ABORT = 12.0        # 秒：队伍 HUD 连续这么久没再读到 = 停止整圈，交回框架
    # 变奏进洛瑟拉后立刻盲按 R 的次数与间隔：图标在入场/动画期间会假阴性，先看再按会一次都不按
    LUCILA_R_BLIND_PRESSES = 3
    LUCILA_R_PRESS_GAP = 0.15
    # 二阶段普攻窗口与闪避后等待。
    A_CHAIN_FIRST_TIME = 1.10
    A_CHAIN_TIME = 1.10
    A_INTERVAL = 0.15
    AFTER_DODGE = 0.25
    KENDO1_DELAY = 0.20
    KENDO_DERIVE = 0.65
    KENDO_OUT_TO_HOLD = 0.30
    # 全轮计划首刀1次、双E后末尾2次。
    PHASE2_E_HOLD = 1.15
    PHASE2_E_TAP_HOLD = 0.05
    PHASE2_E_TAP_GAP = 0.30
    PHASE2_E_READY_CAP = 2.0
    PHASE2_HEAVY_MIN_HOLD = 0.60
    PHASE2_HEAVY_ABSENT_TIME = 0.01
    PHASE2_IAI_READ_LEAD = 0.35
    PHASE2_HEAVY_HOLD_CAP = 3.50
    PHASE2_HEAVY_TRIES = 2
    PHASE2_HEAVY_CONFIRM_TIME = 0.08
    # 旧读豆确认辅助路径保留的右左间隔；当前首刀改用 FIRST_KENDO_RIGHT_GAP。
    DODGE_TO_KENDO = 0.0
    # 首刀专用：按右时只取一次有效处决提示；松右 .45 后单次左键，不连点。
    FIRST_KENDO_RIGHT_GAP = 0.45
    FIRST_EXECUTE_HOLD = 0.05
    FIRST_EXECUTE_SETTLE = 1.45
    FIRST_NO_EXECUTE_SETTLE = 0.60
    # 末尾按时序连点居合、预输入重击并接R2；豆数仅作诊断。
    KENDO_FIRST_DELAY = 0.20        # 架势就绪 -> 第一刀出刀（= 参考队 KENDO1_DELAY）
    KENDO_CLICK_HOLD = 0.02         # 连点每一下的按下时长（参考队用 task.click=0.01）
    KENDO_FINAL_LAST_GAP = 0.05     # 最后一下点击离"预输入重击"至少这么远
    KENDO_POST_IAI_SETTLE = 0.05    # 旧读豆确认辅助路径使用；当前首刀不引用
    KENDO_INPUT_HOLD = 0.05
    # 双E后已进入架势，末尾不发右键，避免退出架势。
    FINAL_KENDO_RIGHT_HOLD = 0.05   # 留档：若哪天需要重新按右键进架势，这个值可用
    FINAL_KENDO_RIGHT_GAP = 0.05    # 旧架势等待参数，当前末尾链不使用
    FINAL_KENDO_LEFT_GAP = 0.10     # 旧两刀间隔参数，当前末尾链不使用
    KENDO_LEFT_FOLLOWUP_CAP = 0.60
    KENDO_LEFT_FOLLOWUP_MAX = 3
    KENDO_BEAN_READ_CAP = 0.80
    KENDO_BEAN_STABLE_TIME = 0.08
    KENDO_BLADE_TRIES = 2
    KENDO_RETRY_RIGHT_DELAY = 0.20
    KENDO_SPAM_INTERVAL = 0.10
    KENDO_SPAM_LAST_GAP = 0.05
    # 旧处决轮询参数留档；当前首刀只在按右时检测一次，不轮询。
    KENDO_F_POLL = 0.40
    # 重击起手至松攻击并按R的间隔，同时影响预输入重击的保持时间。
    HEAVY_TO_R = 0.80
    # 旧起手延迟参数，当前主轴不使用。
    HEAVY_START_DELAY = 0.35
    HEAVY_ANIM = 2.50
    R2_CHARGE_FIRST = 7.35
    R2_CHARGE_LOOP = 2.35

    def reset_state(self):
        super().reset_state()
        # 工厂会用内置实例覆盖 __dict__，必须在 reset_state 再关掉切人自动 F。
        self.check_f_on_switch = False
        self.reset_team_axis()

    def reset_team_axis(self):
        self.task._chl_axis_build = self.AXIS_BUILD
        self.task._chl_axis_phase = 'opener'
        self.task._chl_axis_busy = False
        self.task._chl_axis_failed = False
        self.task._chl_axis_step = 0
        self.task._chl_hiyuki_transformed = False
        self.task._chl_hiyuki_phase1_active = False
        self.task._chl_hiyuki_phase1_a_held = False
        self.task._chl_hiyuki_phase2_step = None
        self.task._chl_hiyuki_phase2_finish_step = 0
        self.task._chl_hiyuki_phase2_kendo = {}
        self.task._chl_hiyuki_phase2_execute_at = None
        self.task._chl_hiyuki_phase2_heavy_at = None
        self.task._chl_hiyuki_phase2_r2_sent = False
        self.task._chl_lucilla_phase2 = None
        self.task._chl_enemy_lost = 0
        self.task._chl_chisa_enhanced_e_sent = False
        # 预输入按住 E 的状态：键字符串与按下时刻，None = 现在没按住。
        self.task._chl_lucila_e_hold_key = None
        self.task._chl_lucila_e_down_at = None
        # 预输入那一下是否已经在切人途中按满并松开(松开后绝不再按第二次)。
        self.task._chl_lucila_e_preinput_done = False
        # 最近一次切人到场(时刻 + 目标名)：预输入按住时长从这一刻起算。
        self.task._chl_last_arrive_at = None
        self.task._chl_last_arrive_name = None

    def on_combat_end(self, chars):
        self.reset_team_axis()
        return super().on_combat_end(chars)

    def teammate(self, name):
        return next((c for c in self.task.chars if c is not None and c.name == name), None)

    def is_chisa_hiyuki_lucilla_team(self):
        return {'Chisa', 'Hiyuki', 'Lucilla'}.issubset(
            {c.name for c in self.task.chars if c is not None})

    def do_perform(self):
        if self.is_chisa_hiyuki_lucilla_team():
            return self.drive_team_axis(self)
        return super().do_perform()

    def axis_sync_current_char_flag(self):
        """【v36】把"当前在场"标记修回唯一一个（按 `index`）。

        背景（2026-10-12 21:21 实机崩溃，`AutoCombatTask.run` 第 64 行
        `self.get_current_char().perform()` → `'NoneType' object has no attribute 'perform'`）：
        在 ok-ww 界面里"保存队伍代码"会走 `CharacterCodeTab._reload_live_team_code()`
        → `apply_team_char_classes()`，**把 `task.chars` 里的角色对象整批换成新实例**；
        而 `axis_switch` 原来用**对象身份**打标记（`char is target`），换对象后一个都不匹配
        → 三个 `is_current_char` 全变 False → 框架 `get_current_char()` 返回 None → 每次
        开自动战斗都在那一行崩掉。

        修法：① `axis_switch` 一律按 **index** 打标记（框架 `BaseCombatTask.combat_start`
        自己也是按 index 刷的）；② 这里兜底自愈 —— 一个标记都没有时，按 HUD 上报的当前位
        补回来。**必须在返回框架之前调用**，否则框架下一轮 `get_current_char()` 就崩了。
        日志只有 `logger.info`（见 v37 说明），不写进 timeline。
        """
        chars = [c for c in self.task.chars if c is not None]
        if not chars or any(c.is_current_char for c in chars):
            return False
        inside, index, _ = self.task.in_team()
        if not inside:
            return False
        for char in chars:
            char.is_current_char = (char.index == index)
        # 入口尚未建立时间线，修复标记时只用logger，避免调用axis_mark。
        self.logger.info(f'{self.AXIS_BUILD} CHL current-char flag repaired by index -> '
                         f'{index} (HUD)')
        return True

    def drive_team_axis(self, entry_char=None):
        if not self.is_chisa_hiyuki_lucilla_team():
            return False
        if getattr(self.task, '_chl_axis_build', None) != self.AXIS_BUILD:
            self.reset_team_axis()
        if getattr(self.task, '_chl_axis_busy', False):
            return True
        # 角色对象可能被热重载替换，先按槽位修复在场标记。
        self.axis_sync_current_char_flag()
        self.task._chl_axis_busy = True
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        for char in self.task.chars:
            if char is not None:
                char.check_f_on_switch = False
        self._chl_start = time.time()
        self._chl_marks = []
        # 本次调用的HUD看门狗基线。
        self.task._chl_hud_seen_at = time.time()
        phase = getattr(self.task, '_chl_axis_phase', 'opener')
        self.logger.info(f'{self.AXIS_BUILD} loaded file={__file__} phase={phase} '
                         f'entry={getattr(entry_char, "name", None)} '
                         f'team={[type(c).__module__ + "." + c.name for c in self.task.chars]}')
        try:
            self._axis_run(self.teammate('Chisa'), self.teammate('Lucilla'), phase == 'opener')
            self.task._chl_axis_phase = 'loop'
            self.task._chl_axis_step = 0
            self.axis_mark('complete; next loop starts at Chisa step 2')
            return True
        except Exception as exc:
            # 停用任务的异常必须继续抛出，不能吞掉后又开始输入。
            self.task.executor.check_enabled(check_pause=False)
            from src.task.BaseCombatTask import NotInCombatException
            if isinstance(exc, NotInCombatException):
                raise
            phase1_active = getattr(self.task, '_chl_hiyuki_phase1_active', False)
            phase2_active = getattr(self.task, '_chl_hiyuki_phase2_step', None) is not None
            lucilla_phase2_active = getattr(self.task, '_chl_lucilla_phase2', None) is not None
            recovery = ('held heavy/direct R1' if phase1_active else
                        'phase2 checkpoint' if phase2_active else
                        'Lucilla phase2 checkpoint' if lucilla_phase2_active else 'normal A')
            self.logger.exception(f'{self.AXIS_BUILD} recover with {recovery}: {exc}; '
                                  f'timeline={" | ".join(self._chl_marks)}')
            if phase1_active:
                self.axis_mark('phase1 recovery: retry held heavy/direct R1 next call; no normal A')
                self.axis_wait(0.20)
            elif phase2_active:
                self.axis_mark('phase2 recovery: preserve checkpoint; no extra kendo/normal A')
                self.axis_wait(0.20)
            elif lucilla_phase2_active:
                self.axis_mark('Lucilla phase2 recovery: preserve output/HUD wait; no normal A or Q-R replay')
                self.axis_wait(0.20)
            else:
                self.axis_chain(0.60, 'recovery normal A; resume current step next call')
            return True
        finally:
            self.task.mouse_up()
            self.task._chl_hiyuki_phase1_a_held = False
            # 兜底：任何异常/收尾路径都不许把预输入的 E 键按死在手里。
            self.axis_key_hold_abort()
            # 交回框架前修复在场标记，避免找不到当前角色。
            self.axis_sync_current_char_flag()
            self.task._chl_axis_busy = False
            self.task.skip_combat_check = previous

    def axis_wait(self, seconds, combat_check=True):
        # 绝对截止时间包含检查耗时；长等待和连续宏也轮询敌人，避免对空气打完整套。
        deadline = time.time() + max(0.0, seconds)
        while True:
            left = deadline - time.time()
            if left <= 0:
                return
            if (combat_check and left >= 0.08
                    and not getattr(self, '_chl_enemy_polling', False)):
                self.axis_require_enemy()
                left = deadline - time.time()
                if left <= 0:
                    return
            time.sleep(min(0.05, left))
            self.task.executor.check_enabled(check_pause=False)

    def axis_wait_intro_freeze(self, duration, release_at, tag):
        """入场冻结等待；到 release_at 就先把预输入的 E 松开(冻结期也算洛瑟拉蓄力)。

        冻结(默认 0.9s)往往比按住时长长，若等冻结结束才松手，`LUCILA_E_HOLD` 就等于
        冻结时长、旋钮会失灵 —— 所以松手要在冻结内部就发生。
        """
        end = time.time() + max(0.0, duration)
        while True:
            now = time.time()
            if (release_at is not None and now >= release_at
                    and getattr(self.task, '_chl_lucila_e_hold_key', None)):
                self.axis_key_hold_end(f'{tag} released during intro freeze')
                self.task._chl_lucila_e_preinput_done = True
                release_at = None
            left = end - now
            if left <= 0:
                return
            self.axis_wait(min(0.05, left))

    def axis_mark(self, tag):
        mark = f'{tag}@{time.time() - self._chl_start:.2f}s'
        self._chl_marks.append(mark)
        self.logger.info(f'{self.AXIS_BUILD} {mark}')
        self.axis_hud_watchdog()

    def axis_hud_ok(self):
        """队伍 HUD 现在在不在？读到就记下时刻，给看门狗用（参考 Hsin.hud_ok()）。

        这里只能用 logger，不能走 axis_mark —— 否则和看门狗互相递归。
        """
        try:
            inside = bool(self.task.in_team()[0])
        except Exception as exc:
            self.logger.info(f'{self.AXIS_BUILD} CHL in_team probe failed: {exc}')
            inside = False
        if inside:
            self.task._chl_hud_seen_at = time.time()
        return inside

    def axis_hud_watchdog(self):
        """【v40】队伍 HUD 连续 HUD_LOST_ABORT 秒读不到 = 结算/过场/窗口不可见 ⇒ 停止整圈。

        axis_mark和等待段目标轮询都检查；HUD读到就刷新基线
        （切人循环每 0.22s、R1 等 HUD 每 8s、R2 等 HUD 每 1s），一处就能兜住全部。
        旧版没有这条，HUD 一丢就没有任何收尾路径（2026-10-12 22:04 那次卡死）。
        """
        if self.axis_hud_ok():
            return
        seen = getattr(self.task, '_chl_hud_seen_at', 0.0)
        if seen <= 0.0 or time.time() - seen <= self.HUD_LOST_ABORT:
            return
        self.task._chl_hud_seen_at = time.time()      # 防止同一次卡死反复触发
        from src.task.BaseCombatTask import NotInCombatException
        self.logger.error(f'{self.AXIS_BUILD} CHL team HUD lost >{self.HUD_LOST_ABORT:.1f}s '
                          f'(settle/cutscene/window hidden?); stop this rotation')
        raise NotInCombatException('CHL team HUD lost')

    def axis_poll(self, predicate, timeout, interval=0.08):
        end = time.time() + timeout
        while True:
            self.task.next_frame()
            if predicate():
                return True
            if time.time() >= end:
                return False
            self.axis_wait(min(interval, max(0.0, end - time.time())))

    def axis_enemy_alive(self):
        """视野里还有敌人吗？只看敌人名牌(has_target) / 敌人血条(has_health_bar)。

        【v40】把两条路分开（参考队 Douling__Hsin__Rover 的分工）：
          · 队伍 HUD **短时间**读不到（洛瑟拉变身收招那几秒糊屏）⇒ 仍沿用 v29 的
            "按还有敌人算"，不许据此结束战斗（19:49 那次就是这样把整场判成脱战的）；
          · 队伍 HUD **超过 HUD_LOST_ABORT** 还读不到 ⇒ 不再当作有敌人，交给
            axis_hud_watchdog() 收尾 —— 旧写法没有这个时限，"没敌人"永远判不出来。
        """
        if not self.axis_hud_ok():
            seen = getattr(self.task, '_chl_hud_seen_at', 0.0)
            if seen <= 0.0 or time.time() - seen <= self.HUD_LOST_ABORT:
                return True
            return False
        for name in ('has_target', 'has_health_bar'):
            probe = getattr(self.task, name, None)
            if probe is None:
                continue
            try:
                if probe():
                    return True
            except Exception as exc:
                self.logger.info(f'{self.AXIS_BUILD} CHL {name} probe failed: {exc}')
        return False

    def axis_require_enemy(self):
        """整套轴通用：视野里没有敌人就结束这场战斗，不再对着空气把剩下的步骤打完。

        轴里 skip_combat_check 全程为 True；步骤边界与等待段独立抓帧检查。
        【v40】判定成立后先按参考队那样 target_enemy(wait=True) 重锁一次：演出/特效造成的
        假阴性在这里被救回来；真没怪时短重锁0.6s后返回 None，再走框架收尾
        task.raise_not_in_combat()（比直接 raise 多一层"排除阵亡弹窗 + reset_to_false"）。
        """
        now = time.time()
        if now - getattr(self, '_chl_enemy_checked_at', 0.0) < self.ENEMY_CHECK_GAP:
            return
        self._chl_enemy_checked_at = now
        self._chl_enemy_polling = True
        try:
            self.task.next_frame()
            self.axis_hud_watchdog()
            # 与原生一样保护大招演出；HUD恢复后继续独立目标检查。
            if getattr(self.task, 'in_liberation', False):
                self.task._chl_enemy_lost = 0
                return
            self._axis_require_enemy_on_frame()
        finally:
            self._chl_enemy_polling = False

    def _axis_require_enemy_on_frame(self):
        if self.axis_enemy_alive():
            self.task._chl_enemy_lost = 0
            return
        lost = getattr(self.task, '_chl_enemy_lost', 0) + 1
        self.task._chl_enemy_lost = lost
        self.axis_mark(f'CHL no enemy in sight ({lost}/{self.ENEMY_LOST_CONFIRM})')
        if lost < self.ENEMY_LOST_CONFIRM:
            return
        self.axis_mark('CHL no enemy; try relock before ending this fight')
        previous_timeout = getattr(self.task, 'target_enemy_time_out', None)
        self.task.target_enemy_time_out = self.ENEMY_RELOCK_CAP
        try:
            relocked = self.task.target_enemy(wait=True)
        finally:
            if previous_timeout is None:
                del self.task.target_enemy_time_out
            else:
                self.task.target_enemy_time_out = previous_timeout
        if relocked:
            self.task._chl_enemy_lost = 0
            self._chl_enemy_checked_at = time.time()
            self.axis_mark('CHL relock ok; continue current axis')
            return
        # 框架收尾还会检查阵亡弹窗，先松开输入，不能在这段检查里继续蓄力/普攻。
        self.task.mouse_up()
        charge_key = getattr(self.task, '_chl_r2_held_key', None)
        if charge_key is not None:
            self.task.send_key_up(charge_key)
            self.task._chl_r2_held_key = None
        self.axis_key_hold_abort()
        self.axis_mark('CHL no enemy left; inputs released; end this fight')
        self.task.raise_not_in_combat('CHL no enemy left')

    def axis_recovery_check(self):
        self.task.executor.check_enabled(check_pause=False)
        self.axis_require_enemy()
        now = time.time()
        if now - getattr(self, '_chl_recovery_check_at', 0.0) >= 1.0:
            self._chl_recovery_check_at = now
            if self.task.in_team()[0] and not getattr(self.task, '_chl_enemy_lost', 0):
                previous = self.task.skip_combat_check
                self.task.skip_combat_check = False
                try:
                    self.task.check_combat()
                finally:
                    self.task.skip_combat_check = previous

    def axis_attack_until(self, predicate, tag):
        """资源不足就持续点按普攻，满足条件后接当前动作，不设失败超时。"""
        started = time.time()
        next_log = started
        waiting = False
        while True:
            self.task.next_frame()
            if predicate():
                if waiting:
                    self.axis_mark(f'{tag} ready after normal A {time.time() - started:.2f}s')
                return
            waiting = True
            if time.time() >= next_log:
                self.axis_mark(tag + ' not ready; continue normal A')
                next_log = time.time() + 10.0
            self.axis_recovery_check()
            self.axis_tap()
            self.axis_wait(0.10)

    def axis_attack_until_bounded(self, predicate, timeout, tag):
        """带秒数上限的补普攻：到点记日志返回 False，让轴继续走，不无限空转。"""
        started = time.time()
        next_log = started
        while True:
            self.task.next_frame()
            if predicate():
                self.axis_mark(f'{tag} ready after normal A {time.time() - started:.2f}s')
                return True
            if time.time() - started >= timeout:
                self.axis_mark(f'{tag} not ready after {timeout:.1f}s; continue axis anyway')
                return False
            if time.time() >= next_log:
                self.axis_mark(tag + ' not ready; continue normal A')
                next_log = time.time() + 10.0
            self.axis_recovery_check()
            self.axis_tap()
            self.axis_wait(0.10)

    def current_axis_char(self):
        inside, index, _ = self.task.in_team()
        if inside:
            return next((c for c in self.task.chars if c is not None and c.index == index), None)
        return self.task.get_current_char()

    def axis_con_value(self, char):
        # 协奏属于当前 HUD；动画遮挡或不是该角色时，不能使用缓存的满协奏。
        inside, index, _ = self.task.in_team()
        if not inside or index != char.index:
            return None
        char.current_con = 0
        return char.get_current_con()

    def axis_con_full(self, char):
        return self.axis_con_value(char) == 1

    def axis_fill_con(self, source, target, cap=None):
        """变奏交接前连续两帧确认满协奏；不足就普攻补满。

        【v29】带上限：`cap`（默认 `INTRO_CON_FILL_CAP`）秒内没补满就返回 False，
        由 `axis_switch` 决定降级成平切 —— 原来"不设失败超时"，实机出现过
        `con=65% → HUD unavailable` 空点 26 下 A、卡 5 秒直到敌人死亡的情况。
        """
        if cap is None:
            cap = (self.CHISA_INTRO_CON_FILL_CAP if source.name == 'Chisa'
                   else self.INTRO_CON_FILL_CAP)
        started = time.time()
        next_log = started
        stable = 0
        attacks = 0
        # 洛瑟拉用长按重击补协奏，其他角色使用普通点按。
        lucilla_heavy = (source.name == 'Lucilla')
        action = f'heavy {self.LUCILA_COMP_HEAVY_HOLD:.2f}s' if lucilla_heavy else 'normal A'
        tag = f'{source.name} con for intro {target.name}'
        while True:
            self.task.next_frame()
            con = self.axis_con_value(source)
            if con == 1:
                stable += 1
                if stable >= 2:
                    self.axis_mark(f'{tag} stable full 2 frames; {action} count={attacks} '
                                   f'elapsed={time.time() - started:.2f}s')
                    return True
                self.axis_wait(0.03)
                continue
            stable = 0
            if cap and time.time() - started >= cap:
                value = 'HUD unavailable' if con is None else f'{con:.0%}'
                self.axis_mark(f'{tag} fill capped at {cap:.1f}s con={value} '
                               f'count={attacks}; give up full con')
                return False
            if time.time() >= next_log:
                value = 'HUD unavailable' if con is None else f'{con:.0%}'
                self.axis_mark(f'{tag} not ready con={value}; continue {action} count={attacks}')
                next_log = time.time() + 5.0
            self.axis_recovery_check()
            if lucilla_heavy:
                self.axis_hold_attack(self.LUCILA_COMP_HEAVY_HOLD)
            else:
                self.axis_tap()
            attacks += 1
            # 千咲点按需要给普攻动画留时间，参考普通 A1 的 200ms gap。
            self.axis_wait(0.20 if source.name == 'Chisa' else 0.10)

    def axis_switch(self, target, intro=False, air_handoff=False, preinput_hold=None, attack_handoff=None, phase1_hold=False):
        self.task.next_frame()
        source = self.current_axis_char()
        if source is None:
            if attack_handoff is not None:
                raise RuntimeError('CHL Chisa attack handoff HUD unavailable; retry current step')
            self.axis_attack_until(lambda: self.current_axis_char() is not None,
                                   f'active character before {target.name}')
            source = self.current_axis_char()
        if source is target:
            # 按槽位标记，兼容角色对象热重载。
            for char in self.task.chars:
                if char is not None:
                    char.is_current_char = (char.index == target.index)
            if phase1_hold:
                self.axis_hiyuki_phase1_hold_begin()
            return
        intro_cap = (self.CHISA_INTRO_CON_FILL_CAP if source.name == 'Chisa'
                     else self.INTRO_CON_FILL_CAP)
        if intro and not self.axis_fill_con(source, target, cap=intro_cap):
            # 补协奏超时后允许平切，避免卡住整轴。
            self.axis_mark(f'{source.name}->{target.name} con not full within '
                           f'{intro_cap:.1f}s; downgrade to plain switch (no intro buff)')
            intro = False
        # 普通切人也可能自然触发变奏；记录真实协奏，不能强行当作无变奏。
        con_full = True if intro else self.axis_con_full(source)
        deadline = time.time() + self.SWITCH_TIMEOUT
        next_send = 0.0
        recovering = False
        switch_sent = False
        while True:
            self.task.next_frame()
            inside, index, _ = self.task.in_team()
            if inside and index == target.index:
                source.switch_out(con_full=con_full)
                for char in self.task.chars:
                    if char is not None:
                        char.is_current_char = (char.index == target.index)
                target.has_intro = con_full
                target.has_sub_dps_intro = con_full and source.is_sub_dps
                target.last_switch_in_time = time.time()
                # 记录到场时刻，作为预输入E的计时起点。
                arrive_at = time.time()
                self.task._chl_last_arrive_at = arrive_at
                self.task._chl_last_arrive_name = target.name
                self.task.in_liberation = False
                self.axis_mark(f'switch arrived {target.name} intro={con_full}')
                if phase1_hold:
                    self.axis_hiyuki_phase1_hold_begin()
                # 预输入按住 E：以"到场"为起点排定松手时刻；松手可以发生在入场冻结内部。
                release_at = None
                if (preinput_hold is not None
                        and getattr(self.task, '_chl_lucila_e_hold_key', None)):
                    release_at = arrive_at + float(preinput_hold)
                    self.axis_mark(f'switch pre-input E held; release at arrive+{preinput_hold:.2f}s')
                if con_full:
                    now = time.time()
                    duration = float(target.intro_motion_freeze_duration)
                    self.task.add_freeze_duration(now, duration, -100)
                    source.last_outro_time = now
                    if not air_handoff:
                        if release_at is None:
                            self.axis_wait(duration)
                        else:
                            self.axis_wait_intro_freeze(duration, release_at, '05 Lucilla pre-input E')
                    else:
                        self.axis_mark('Chisa air handoff: no extra intro sleep before jump-air A')
                if (release_at is not None
                        and getattr(self.task, '_chl_lucila_e_hold_key', None)):
                    # 没走冻结等待(或冻结比按住短)：到场后把剩余按住时间走完再松手。
                    self.axis_key_hold_end('05 Lucilla pre-input E on arrival',
                                           max(0.0, release_at - time.time()))
                    self.task._chl_lucila_e_preinput_done = True
                return
            if intro and switch_sent and not inside:
                # 已发送切人且 HUD 被变奏动画遮挡时，等 HUD 恢复再判断结果。
                # 这时不能把目标角色的协奏当成源角色，也不能向目标补 A。
                self.axis_recovery_check()
                self.axis_wait(0.03)
                continue
            if time.time() >= deadline:
                if attack_handoff is not None:
                    raise RuntimeError('CHL Chisa attack handoff delayed; retry current step')
                self.axis_mark(f'switch {target.name} delayed; normal A and retry')
                recovering = True
                deadline = time.time() + self.SWITCH_TIMEOUT
            if recovering:
                self.axis_recovery_check()
                self.axis_tap()
                self.axis_wait(0.10)
                self.task.next_frame()
                inside, index, _ = self.task.in_team()
                if inside and index == target.index:
                    continue
            if time.time() >= next_send:
                if intro:
                    # 每次重试都先看新截图；补满协奏有上限，超时降级平切而不是卡死。
                    if not self.axis_con_full(source):
                        self.axis_mark(f'{source.name}->{target.name} pre-switch con not full; '
                                       'resume normal A compensation')
                        if not self.axis_fill_con(source, target, cap=intro_cap):
                            self.axis_mark(f'{source.name}->{target.name} con not full within '
                                           f'{intro_cap:.1f}s; '
                                           'downgrade to plain switch (no intro buff)')
                            intro = False
                            deadline = time.time() + self.SWITCH_TIMEOUT
                            continue
                        deadline = time.time() + self.SWITCH_TIMEOUT
                        recovering = False
                        continue
                    con_full = True
                else:
                    con_full = self.axis_con_full(source)
                request = (f'switch request {source.name}->{target.name} intro={con_full} '
                           f'required_intro={intro}')
                if attack_handoff is None:
                    self.axis_mark(request)
                    self.task.send_key(target.index + 1)
                else:
                    # 第6格提前做切人准备，持续点A至首次发键截止时刻。
                    send_at, release_attack = attack_handoff[:2]
                    if len(attack_handoff) > 2:
                        attack_handoff[2](send_at)
                    else:
                        self.axis_wait(max(0.0, send_at - time.time()), combat_check=False)
                    sent_at = time.time()
                    self.task.send_key(target.index + 1)
                    release_attack(sent_at)
                    attack_handoff = None  # 被吞后的重试恢复原切人逻辑，A已松开。
                    self.axis_mark(request)
                switch_sent = True
                next_send = time.time() + 0.22
            self.axis_wait(0.03)

    def axis_tap(self):
        self.task.mouse_down()
        try:
            self.axis_wait(0.05)
        finally:
            self.task.mouse_up()

    def axis_hold_attack(self, seconds):
        self.task.mouse_down()
        try:
            self.axis_wait(seconds)
        finally:
            self.task.mouse_up()

    def axis_chain(self, duration, tag):
        # A3 由连段动画时长决定。三次快速点按只有约半秒，根本打不到第三段。
        self.axis_mark(tag + ' begin')
        end = time.time() + duration
        while time.time() < end:
            self.axis_tap()
            self.axis_wait(min(0.10, max(0.0, end - time.time())))
        self.axis_mark(tag + ' inputs complete')

    def axis_resonance(self, char, hold, tag, settle=0.0):
        self.axis_mark(tag + ' key down')
        key = char.get_resonance_key()
        self.task.send_key_down(key)
        try:
            self.axis_wait(hold)
        finally:
            self.task.send_key_up(key)
        char.record_resonance_use()
        self.axis_wait(settle)
        self.axis_mark(tag + ' key up')

    # E预输入跨切人保持；正常释放与异常清理必须成对。
    def axis_key_hold_begin(self, key, tag):
        self.task.send_key_down(key)
        self.task._chl_lucila_e_hold_key = key
        self.task._chl_lucila_e_down_at = time.time()
        self.task._chl_lucila_e_preinput_done = False
        self.axis_mark(f'{tag} E HOLD DOWN; pre-input across switch')

    def axis_key_hold_end(self, tag, extra=0.0):
        """松开预输入键；extra 秒内继续按住。返回从按下到松开的实际时长。"""
        key = getattr(self.task, '_chl_lucila_e_hold_key', None)
        if key is None:
            return 0.0
        down_at = getattr(self.task, '_chl_lucila_e_down_at', time.time())
        self.task._chl_lucila_e_hold_key = None
        self.task._chl_lucila_e_down_at = None
        try:
            if extra > 0:
                self.axis_wait(extra)
        finally:
            self.task.send_key_up(key)
        held = time.time() - down_at
        self.axis_mark(f'{tag} E HOLD UP held={held:.2f}s')
        return held

    def axis_key_hold_abort(self):
        """异常兜底：不等待、不加时序，无条件松开预输入键。"""
        key = getattr(self.task, '_chl_lucila_e_hold_key', None)
        if key is None:
            return
        self.task._chl_lucila_e_hold_key = None
        self.task._chl_lucila_e_down_at = None
        try:
            self.task.send_key_up(key)
        except Exception as exc:
            self.logger.info(f'pre-input E release failed: {exc}')

    def axis_echo(self, char, settle=0.10):
        self.task.next_frame()
        if char.echo_available():
            char.send_echo_key()
            char.record_echo_use()
            self.axis_mark(char.name + ' Q sent')
            self.axis_wait(settle)
        else:
            self.axis_mark(char.name + ' Q on cooldown')

    def axis_liberation(self, char, tag, ready_timeout=0.8, transformed=False, press_first=0,
                        intro_if_full=False):
        confirmed = False
        animated = False
        start = time.time()
        if press_first:
            # 入场期间R图标可能暂不可读，先尝试发送再确认。
            for i in range(int(press_first)):
                char.send_liberation_key()
                self.axis_wait(self.LUCILA_R_PRESS_GAP)
                self.task.next_frame()
                animated = not self.task.in_team()[0]
                confirmed = animated or (not char.liberation_available()
                                          and self.task.get_cd('liberation') > 0.2)
                if confirmed:
                    self.axis_mark(f'{tag} fired on early attempt {i + 1}')
                    break
            if not confirmed:
                self.axis_mark(f'{tag} still grey after {press_first} early attempts; '
                               f'top up normal A and press it the moment it lights')
        handoff = False
        def ready_or_intro():
            nonlocal handoff
            if self.task.use_liberation and char.liberation_available():
                return True
            # 千咲补R期间满协奏：两帧确认后直接走变奏，不再补R或发强化E。
            if intro_if_full and self.axis_con_full(char):
                self.axis_wait(0.03)
                self.task.next_frame()
                if self.axis_con_full(char):
                    handoff = True
                    return True
            return False

        while not confirmed:
            self.axis_attack_until(ready_or_intro, tag + ' energy/cooldown')
            if handoff:
                self.axis_mark(tag + ' unready; con stable full 2 frames; direct intro to Lucilla')
                return False
            self.axis_mark(tag + ' ready; sending R')
            start = time.time()
            animated = False
            while time.time() - start < 2.0:
                char.send_liberation_key()
                self.axis_wait(0.12)
                self.task.next_frame()
                animated = not self.task.in_team()[0]
                # 洛瑟菈变身期间 HUD 会一直消失；普通 R 还可以用已进入 CD 作确认。
                confirmed = animated or (not char.liberation_available()
                                          and self.task.get_cd('liberation') > 0.2)
                if confirmed:
                    break
            if confirmed:
                break
            self.axis_mark(tag + ' input not confirmed; normal A then retry R')
            self.axis_recovery_check()
            self.axis_chain(0.45, tag + ' input recovery normal A')
        if animated and not transformed:
            self.task.in_liberation = True
            try:
                if not self.axis_poll(lambda: self.task.in_team()[0], 8.0):
                    self.axis_attack_until(lambda: self.task.in_team()[0], tag + ' HUD return')
            finally:
                self.task.in_liberation = False
        if transformed:
            self.axis_wait(3.0)
        char.record_liberation_use()
        char.add_freeze_duration(start, time.time() - start)
        self.axis_mark(tag + ' confirmed')

    # 图标形状识别与六张模板复用 Chisa__Suisui__YangYangSp/YangYangSp.py。
    CHI_GLYPH_MARGIN = 0.10

    CHI_GLYPHS = (
        'AAAAAAAIHBwjHBAAAAAAAAAAAAcoQUNDQ0VGMREAAAAAAAw6OzgyNDdBWz5FHwAAAAY1NjBLoNCxm8NEPEYYAAAi'
        'MC6CwYhrduHX3k0/OgIGNS6DdDI8XNh4dNWtNz8YFjNmWS43MKuci0Y1eEM7LhQ7XDVTPpN/K3ZUKC5AOi0YQzdh'
        'NayljCp4WykvSjkzEi5EaTTLx1s5eFErTU84LQs5TmhNlEsmXFQ1Kns1NyIAZHCuwjo4T0krKFl3LzMFADKAznI6'
        'MCcnJlKpLzIeAAAAaI9WQDElN4C/QiwiAgAAAAA1y8itvt6tQSgYAgAAAAAAAAdXn4tSJBoEAAAAAAAAAAAACBwc'
        'IxwQAAAAAAAAAAAHKEFDQ0NFRjERAAAAAAAMOjs4MjQ3QVs+RR8AAAAGNTYwS6DQsZvDRDxGGAAAIS8ugsGIa3bh'
        '195NPjoCBjIug3QyPFzYeHTVrTQ7FxQvZlkuNzCrnItGNXk9NywTOFw1Uz6Tfit2VCguOTMqF0I3YTWtpowpeFsp'
        'L0gwMBIuRGk0y8ZbOXlRK01HLyoLOU5oTZNLJlxUNSp6LS4gAGVwrsI6OE9JKyhZdiouBAAzgM5yOjAnJyZSqS4u'
        'HAAAAGiPVkAxJTeAv0IsIAIAAAAANcvIrb7frUEoGAIAAAAAAAAHWKSOUCEZBAAAAAAAAAAAAAcZGR8aEAAAAAAA'
        'AAAABiQ6ODo8QUQvEAAAAAAACzQ6OTZrNzk9PkIeAAAABjY6OjZt7Eo3NzdARBYAACI7PztF2PujNDU3Ojs2AgY4'
        'O2Jxk/j68FE5Ozk1OxcXOzk7eOuTvfu3VnR1OTgqFzo4OLDMPji69LiPQzc6Kh03NF3oXj2CQKy/OTk2OTEXOjjE'
        'oDeR+IJDo3ZANDcqDnCb2j9E4btSOzp0dEI2HgFO3oZQoN/l26+ZyYlSMwQAMPb0+PLj1LeMdG3cQxsAAABt5s+g'
        'cUs3RFZ19HcCAAAAAB9IbIWkyN7r3YYJAAAAAAAABSY7PUM6Mg0AAAAAAAAAAAAFFBQZFg8AAAAAAAAAAAUdMTU2'
        'Njg+Kw8AAAAAAAouMjM3cDs7Ozo8GwAAAAUvNDM1dOxWPT06OTwUAAAdNDo2Rdz8rUA/PDk7MgIFMDNodJ36+/Rg'
        'PT07OTkUEzMzO4Xrn8f8uVlyfEU2JRMyNDmtzkxKxfTEnks3NCMXMTZk725MkUq4x0U8NjAmEzRByKdFnPmRRaqA'
        'PzQuIQxtnd5OWOTEWENFfnlALxkBSOGJX67o6uG8oNCPWjAEADD4+Pv26ty/lXZ13kQYAAAAbebNoHFVQk1aevB3'
        'AgAAAAAhQ2qJq8rh7eOGCQAAAAAAAAUmPTs9OjINAAAAAAAAAAAABxoTExAJAAAAAAAAAAAHLEpPMyUmKh0KAAAA'
        'AAAPR05OUkMhIyYmJhEAAAAHSExLTF1jJiIlJSUoDgAAL09QTVB1aUcgJCMjJiIBCVBRVllof2tgKiAhIyUnDiBS'
        'TlNhgmxbYUUjKzUoJhshVFBRb45SNE11WD4mJSYbKVZUXZnTVkZPoYwmISQmICJYVH2KxWt2Y2SIPSQjJRwUYWyf'
        'r+OQlXJ3fjwyKCYUAUOCbF2Lg5x/kXRcQiwjAwAehYWGg357c2pkX20uFAAAADqAeXBiWFVVV2SCRgIAAAAAIExf'
        'Z3B4f4B7SgUAAAAAAAADI0BARj0vCQAAAAAAAAAAAAYWERINBwAAAAAAAAAAByxHTjIkIh8WBwAAAAAAD0lUU1ZC'
        'JSAeHh0NAAAAB0xUVFNlai0fHBwcHgoAADJWV1ZZfXdIIR0cGx8bAQlRVVphcIx2Zy8eHx8gIQwiVlNYaIJ2YWtN'
        'Kjc7KCQZIldVWXeWYUBbjWdELCYkGSpYV2Od02NQin2yOCcjIhsiWl+AksZ0eJB7wU0sJSQYFWlyoq/kk5hBU6BJ'
        'PSsmFAFJgXNpkYmjeoRmV0UtJgMAHoeLjIuKgnpZQT1cMBcAAAA8iIB2cWhiVkJEazYCAAAAACJTaXF2fYN7ZDkE'
        'AAAAAAAAAyRHSVNINgcAAAAA'
    )

    @staticmethod
    def glyph_vec(a):
        v = a.astype(np.float32).flatten()
        v = v - v.mean()
        n = float(np.linalg.norm(v))
        return v / n if n > 0 else v

    def axis_chisa_e_glyph(self):
        """千咲 E 图标的图案: 'gear'(齿轨轮回, 强化E 还在) / 'e1'(解弦之眼, 亮或冷却) / None(读不准)。"""
        try:
            tv = getattr(self, '_chi_glyph_vecs', None)
            if tv is None:
                raw = base64.b64decode(''.join(self.CHI_GLYPHS))
                arr = np.frombuffer(raw, np.uint8).reshape(6, 16, 16).astype(np.float32)
                tv = self._chi_glyph_vecs = [self.glyph_vec(a) for a in arr]
            box = self.task.get_box_by_name('box_resonance')
            frame = self.task.frame
            cx, cy = int(box.x + box.width / 2), int(box.y + box.height / 2)
            h = int(box.height * 1.1)
            icon = frame[max(0, cy - h):cy + h, max(0, cx - h):cx + h, :3]
            g = cv2.cvtColor(cv2.resize(icon, (96, 96), interpolation=cv2.INTER_AREA),
                             cv2.COLOR_BGR2GRAY).astype(np.float32)
            yy, xx = np.mgrid[:96, :96]
            g = g * (((xx - 48) ** 2 + (yy - 44) ** 2) <= 25 ** 2)
            v = self.glyph_vec(cv2.resize(g[18:70, 22:74], (16, 16), interpolation=cv2.INTER_AREA))
            score = [float(v @ t) for t in tv]
            gear, e1 = max(score[:2]), max(score[2:])
            if max(gear, e1) < 0.6:
                return None
            if gear - e1 >= self.CHI_GLYPH_MARGIN:
                return 'gear'
            if e1 - gear >= self.CHI_GLYPH_MARGIN:
                return 'e1'
            return None
        except Exception as e:
            now = time.time()
            if now >= getattr(self, '_chl_chisa_glyph_error_log_at', 0.0):
                self.logger.info(f'chi_e_glyph probe failed ({e})')
                self._chl_chisa_glyph_error_log_at = now + 5.0
            return None

    def axis_chisa_open(self, chisa, airborne=False):
        self.task._chl_chisa_enhanced_e_sent = False
        if airborne:
            self.axis_mark('02 Chisa already airborne after Hiyuki intro; skip jump -> air A -> landing E')
        else:
            self.axis_mark('02 Chisa jump-air A -> wait landing -> E -> normal A 2.2s-Q-R')
            self.task.send_key('space', down_time=0.05)
            self.axis_wait(0.10)
        self._chl_chisa_air_a_at = time.time()
        self.axis_tap()
        self.axis_wait(0.08)
        self.axis_chisa_landing_e(chisa)

    def axis_wait_chisa_landing(self, chisa):
        """密集落地检测：空A 之后从第一帧就开始查，不再等 0.30 秒。

        顺序是"先认离地、再等落地"：声骸图标变灰(=在空中)先把闸门打开，
        之后图标一亮(=落地)且连续 2 帧就立刻返回，马上按 E。
        0.45 秒内一次都没读到灰(jump 被打断等)就退回宽松判据，避免卡死。
        """
        started = time.time()
        next_log = started
        stable = 0
        airborne_seen = False
        while True:
            self.task.next_frame()
            inside, index, _ = self.task.in_team()
            white = chisa.current_echo() if inside and index == chisa.index else -1.0
            now = time.time()
            if white == 0.0:
                airborne_seen = True          # 图标是灰的 = 确认离地，闸门打开
            lit = white > 0
            armed = airborne_seen or now - started >= self.CHISA_LANDING_ARM_FALLBACK
            if lit and armed:
                stable += 1
                if stable >= 2:
                    self.axis_mark(f'02 Chisa landing confirmed echo_white={white:.3f}; '
                                   f'waited={now - started:.2f}s; airborne_seen={airborne_seen}; E allowed')
                    return
            else:
                stable = 0
            if now >= next_log:
                state = 'HUD unavailable' if white < 0 else f'echo_white={white:.3f}'
                self.axis_mark(f'02 Chisa wait landing {state}; no E during plunge animation')
                next_log = now + 5.0
            self.axis_recovery_check()
            # 不用 axis_attack_until，避免空A尚未落地时连续追加普攻改变动作。
            self.axis_wait(0.03)

    def axis_chisa_landing_e(self, chisa):
        # 第2步必须空A砸地后才按普通 E；第4步的强化 E 独立识别和确认。
        attempt = 0
        next_log = time.time()
        while True:
            self.axis_wait_chisa_landing(chisa)
            if not chisa.resonance_available():
                if time.time() >= next_log:
                    self.axis_mark('02 Chisa landed but E not ready; continue normal A')
                    next_log = time.time() + 5.0
                self.axis_recovery_check()
                self.axis_tap()
                self.axis_wait(0.20)
                continue
            attempt += 1
            self.axis_resonance(chisa, 0.05, f'02 Chisa landing E attempt {attempt}', 0.10)
            # 冷却显示可能延迟，仅作非阻塞诊断；发送后直接接普攻，不据此重试。
            cd = self.task.get_cd('resonance')
            self.axis_mark(f'02 Chisa landing E sent cd={cd:.2f} (non-blocking); '
                           'continue normal A 2.2s-Q-R')
            self.axis_wait(self.CHISA_LANDING_E_SETTLE)
            return

    def axis_chisa_e_state(self, chisa):
        inside, index, _ = self.task.in_team()
        if not inside or index != chisa.index:
            return None, -1.0
        glyph = self.axis_chisa_e_glyph()
        box = self.task.get_box_by_name('box_resonance')
        color = {'r': (200, 255), 'g': (200, 255), 'b': (200, 255)}
        return glyph, self.task.calculate_color_percentage(color, box)

    def axis_chisa_enhanced_e(self, chisa):
        # 强化E发送后直接切人，不检查效果或重试。
        self.task.executor.check_enabled(check_pause=False)
        if not getattr(self.task, '_chl_chisa_enhanced_e_sent', False):
            self.axis_resonance(chisa, 0.05, '04 Chisa enhanced E', 0.03)
            self.task._chl_chisa_enhanced_e_sent = True
            self.axis_mark('04 Chisa enhanced E input sent; effect unchecked; continue to Lucilla')
        if (self.LUCILA_E_PREINPUT
                and not getattr(self.task, '_chl_lucila_e_hold_key', None)
                and not getattr(self.task, '_chl_lucila_e_preinput_done', False)):
            self.axis_key_hold_begin(chisa.get_resonance_key(), '04 Chisa enhanced E')

    def axis_chisa_first_lucilla(self, chisa, lucilla):
        if not getattr(self.task, '_chl_chisa_enhanced_e_sent', False):
            self.axis_chisa_enhanced_e(chisa)
        self.axis_mark('05 first Chisa->Lucilla after E input; effect unchecked')
        # E预输入由axis_switch按到场时刻安排释放，不在此重复按下。
        hold = None
        if (self.LUCILA_E_PREINPUT
                and getattr(self.task, '_chl_lucila_e_hold_key', None)):
            hold = self.LUCILA_E_HOLD
            self.axis_mark(f'05 switch to Lucilla with E held; release at arrive+{hold:.2f}s')
        self.axis_switch(lucilla, preinput_hold=hold)

    def axis_lucilla_perfect_e(self, lucilla):
        attempt = 0
        while True:
            # 跨切人E通常已按到场时刻释放；这里只补足剩余保持时间并检查冷却。
            down_at = getattr(self.task, '_chl_lucila_e_down_at', None)
            preinput = down_at is not None
            done = getattr(self.task, '_chl_lucila_e_preinput_done', False)
            if not preinput and not done:
                self.axis_attack_until(lucilla.resonance_available, 'Lucilla perfect E cooldown')
            attempt += 1
            if preinput:
                # 兜底：切人途中没走 axis_switch 的排定释放(没冻结/被跳过)，这里把剩余按住走完。
                arrive = getattr(self.task, '_chl_last_arrive_at', None)
                if (arrive is None or arrive < down_at
                        or getattr(self.task, '_chl_last_arrive_name', None) != lucilla.name):
                    arrive = time.time()   # 拿不到本次到场时刻就退化成"从现在起算"
                release_at = min(arrive + self.LUCILA_E_HOLD,
                                 down_at + self.LUCILA_E_PREINPUT_MAX)
                extra = max(0.0, release_at - time.time())
                self.axis_mark(f'05 Lucilla perfect E attempt {attempt} pre-input hold; '
                               f'lead={arrive - down_at:.2f}s; '
                               f'hold_after_arrive={release_at - arrive:.2f}s; '
                               f'keep_holding={extra:.2f}s')
                self.axis_key_hold_end(f'05 Lucilla perfect E attempt {attempt}', extra)
                lucilla.record_resonance_use()
            elif done:
                # 预输入已释放，先检查冷却；未确认时下一轮再走普通重试。
                self.task._chl_lucila_e_preinput_done = False
                lucilla.record_resonance_use()
                self.axis_mark(f'05 Lucilla perfect E attempt {attempt} from pre-input hold; '
                               'E already released at arrive+hold; no second press')
            else:
                self.axis_resonance(lucilla, self.LUCILA_E_HOLD,
                                    f'05 Lucilla perfect E attempt {attempt}')
            if self.axis_poll(lambda: self.task.get_cd('resonance') > 0.2, 0.35):
                self.axis_mark('Lucilla E cooldown confirmed')
                # 松开 E 并确认释放成功后留出收招时间，再切回千咲。
                self.axis_mark('05 Lucilla E released; wait 0.70s before Chisa switch')
                self.axis_wait(0.70)
                self.axis_mark('05 Lucilla post-E wait complete; Chisa switch allowed')
                return
            self.axis_recovery_check()
            self.axis_chain(0.45, 'Lucilla E input recovery normal A')

    def axis_lucilla_burst(self, lucilla):
        state = getattr(self.task, '_chl_lucilla_phase2', None)
        if state is None:
            self.axis_mark('09 Lucilla Q-R')
            self.axis_echo(lucilla)
            # 保留入场后的R盲按、补能及3秒变身等待。
            self.axis_liberation(lucilla, 'Lucilla R', transformed=True,
                                 press_first=self.LUCILA_R_BLIND_PRESSES)
            state = {'stage': 'attack', 'started_at': time.time(), 'pulses': 0,
                     'wait_started_at': None}
            self.task._chl_lucilla_phase2 = state
            self.axis_mark('10 Lucilla hold A begin; monitor HUD + mouse_forte from second pulse')
        if state['stage'] == 'attack':
            self.axis_lucilla_phase2_output(lucilla, state)
        if state['stage'] == 'hud':
            self.axis_lucilla_wait_hud(state)
        self.axis_mark('Lucilla hold A ended; HUD returned')
        self.task._chl_lucilla_phase2 = None

    def axis_lucilla_phase2_output(self, lucilla, state):
        end = state['started_at'] + self.LUCILA_PHASE2_OUTPUT_CAP
        ended = False
        while time.time() < end:
            self.task.executor.check_enabled(check_pause=False)
            state['pulses'] += 1
            self.task.mouse_down()
            hold_end = min(time.time() + self.LUCILA_PHASE2_A_HOLD, end)
            try:
                if state['pulses'] == 1:
                    # 第一拍仍完整按 .60s；第二拍按下后即开始在保持期间监测。
                    self.axis_wait(max(0.0, hold_end - time.time()))
                else:
                    while time.time() < hold_end:
                        self.task.executor.check_enabled(check_pause=False)
                        sampled_at = time.time()
                        self.task.next_frame()
                        hud = self.axis_hud_ok()
                        heavy = bool(lucilla.is_mouse_forte_full())  # 通用 mouse_forte 提示
                        if not hud and not heavy:
                            ended = True
                            break  # finally 立即松A，不等这拍 .60s 结束。
                        self.axis_hud_watchdog()
                        self.axis_require_enemy()
                        # 截图与识别耗时计入 .03s 周期，超过周期则直接取下一帧。
                        delay = min(hold_end, sampled_at + self.LUCILA_PHASE2_POLL) - time.time()
                        self.axis_wait(max(0.0, delay), combat_check=False)
            finally:
                self.task.mouse_up()
            if ended or time.time() >= end:
                break
            self.axis_wait(self.LUCILA_PHASE2_A_GAP)
        # 保存交接阶段，异常恢复只继续等待，不重放Q/R或已完成的输出。
        state['stage'] = 'hud'
        state['wait_started_at'] = time.time()
        reason = 'HUD and mouse_forte disappeared' if ended else 'output time cap reached'
        self.axis_mark('10 Lucilla A released: ' + reason + '; wait HUD without attacks')

    def axis_lucilla_wait_hud(self, state):
        deadline = state['wait_started_at'] + self.LUCILA_HUD_RETURN_CAP
        while True:
            self.task.executor.check_enabled(check_pause=False)
            self.task.next_frame()
            if self.axis_hud_ok():
                state['stage'] = 'done'
                return
            if time.time() >= deadline:
                # 未恢复HUD不能交给补协奏去盲打A；沿用战斗结束异常保护路径。
                from src.task.BaseCombatTask import NotInCombatException
                raise NotInCombatException('CHL Lucilla HUD return timed out')
            self.axis_recovery_check()
            self.axis_wait(self.LUCILA_PHASE2_POLL, combat_check=False)

    def axis_hiyuki_phase1_hold_begin(self):
        self.task.executor.check_enabled(check_pause=False)
        if getattr(self.task, '_chl_hiyuki_phase1_a_held', False):
            return
        self.task._chl_hiyuki_phase1_active = True
        self.task._chl_hiyuki_phase1_forte_before = bool(self.is_mouse_forte_full())
        self.task._chl_hiyuki_phase1_armed_at = time.time()
        self.task.mouse_down()
        self.task._chl_hiyuki_phase1_a_held = True
        self.axis_mark(f'Hiyuki phase1 A HOLD DOWN before Q; '
                       f'forte_before={self.task._chl_hiyuki_phase1_forte_before}')

    def axis_hiyuki_intro(self):
        try:
            self.axis_switch(self, intro=True, phase1_hold=True)
        except Exception:
            self.task.mouse_up()
            self.task._chl_hiyuki_phase1_a_held = False
            raise

    def axis_hiyuki_burst(self):
        if getattr(self.task, '_chl_hiyuki_transformed', False):
            self.task._chl_hiyuki_phase1_active = False
            return
        self.task._chl_hiyuki_phase1_active = True
        self.axis_mark('12 Hiyuki phase1 hold A across Q -> monitor forte with early R1 retries')
        try:
            # 入场时已按住A；直接调用/异常恢复时也必须先按住，再发Q。
            self.axis_hiyuki_phase1_hold_begin()
            self.axis_echo(self)
            before = self.task._chl_hiyuki_phase1_forte_before
            armed_at = self.task._chl_hiyuki_phase1_armed_at
            next_r = armed_at + self.PHASE1_MIN_HOLD
            next_log = time.time() + 10.0
            consumed = False
            attempts = 0
            animated = False
            while True:
                self.axis_wait(0.05)
                self.task.next_frame()
                self.axis_require_enemy()  # 首次重击/R1循环也不能等10秒日志才查敌人
                if before and not consumed and not bool(self.is_mouse_forte_full()):
                    consumed = True
                    self.axis_mark(f'Hiyuki phase1 forte consumed; R1 attempts so far={attempts}')
                now = time.time()
                if before and not consumed and now - armed_at >= 2.0:
                    # 长按起手被吞且回路未消耗：重发长按下沿，继续打强化重击。
                    self.task.mouse_up()
                    self.axis_wait(0.03)
                    self.task.mouse_down()
                    armed_at = time.time()
                    next_r = armed_at + self.PHASE1_MIN_HOLD
                    self.axis_mark('Hiyuki phase1 heavy not consumed; rearm A HOLD')
                    continue
                if now >= next_r and self.task.use_liberation:
                    if attempts == 0:
                        self.axis_mark('Hiyuki phase1 early R1 retries while holding A; monitor forte in parallel')
                    self.send_liberation_key()
                    attempts += 1
                    next_r = time.time() + self.PHASE1_R_INTERVAL
                    self.task.next_frame()
                    animated = not self.task.in_team()[0]
                    confirmed = animated or (not self.liberation_available()
                                              and self.task.get_cd('liberation') > 0.2)
                    if confirmed:
                        self.task._chl_hiyuki_transformed = True
                        self.axis_mark(f'Hiyuki R1 effect confirmed after {attempts} direct attempts')
                        break
                if now >= next_log:
                    self.axis_mark('Hiyuki R1 not confirmed; keep held heavy/direct R; no normal A')
                    self.axis_recovery_check()
                    next_log = time.time() + 10.0
        finally:
            self.task.mouse_up()
            self.task._chl_hiyuki_phase1_a_held = False
            self.axis_mark('Hiyuki phase1 A HOLD UP')
        if animated:
            self.task.in_liberation = True
            try:
                while not self.axis_poll(lambda: self.task.in_team()[0], 8.0):
                    self.axis_mark('Hiyuki R1 animation ongoing; wait for HUD without normal A')
                    self.task.executor.check_enabled(check_pause=False)
            finally:
                self.task.in_liberation = False
        self.record_liberation_use()
        self.task._chl_hiyuki_phase1_active = False
        # has_long_action2 是敌人长动作条，不是绯雪二阶段判据。
        self.task._chl_hiyuki_transformed = True
        self.axis_wait(0.20)
        self.axis_mark('Hiyuki R1 confirmed; enter phase2 macro')

    def axis_dodge(self, settle=0.05):
        self.task.click(key='right')
        self.axis_mark('Hiyuki dodge')
        self.axis_wait(settle)

    def axis_execute(self, tag='15', poll=0.0, phase2=False):
        """可选处决：画面中部出现 f_break 提示就按 F。

        poll>0 时在 poll 秒内逐帧等提示出现（给"居合平A 之后用处决取消后摇"用）。
        """
        box = self.task.box_of_screen(0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True)
        def prompt():
            return bool(self.task.find_one('f_break', box=box, target_height=720, threshold=0.90))
        deadline = time.time() + max(0.0, poll)
        while True:
            self.task.next_frame()
            if prompt() and not self.task.is_pick_f():
                start = time.time()
                self.task.send_key('f')
                if phase2:
                    self.task._chl_hiyuki_phase2_execute_at = start
                self.task.can_break = False
                self.axis_mark(f'{tag} F execute sent')
                self.axis_poll(lambda: not prompt(), 0.8)
                self.axis_wait(1.6)
                self.add_freeze_duration(start, time.time() - start)
                return True
            if time.time() >= deadline:
                self.axis_mark(f'{tag} F absent; skip optional execute')
                return False
            self.axis_wait(0.03)

    def axis_hiyuki_tail(self, first):
        if (getattr(self.task, '_chl_hiyuki_phase2_step', None) is None
                and not getattr(self.task, '_chl_hiyuki_transformed', False)):
            self.axis_hiyuki_burst()
        if getattr(self.task, '_chl_hiyuki_phase2_step', None) is None:
            self.task._chl_hiyuki_phase2_step = 0
            self.task._chl_hiyuki_phase2_finish_step = 0
            self.task._chl_hiyuki_phase2_kendo = {}
            self.task._chl_hiyuki_phase2_execute_at = None
            self.task._chl_hiyuki_phase2_heavy_at = None
            self.task._chl_hiyuki_phase2_heavy_pending = False
            self.task._chl_hiyuki_phase2_heavy_marker_seen = False
            self.task._chl_hiyuki_phase2_e = None
            self.task._chl_hiyuki_phase2_heavy_frames = set()
            self.task._chl_hiyuki_heavy_review_round = getattr(self.task, '_chl_hiyuki_heavy_review_round', 0) + 1
            self.task._chl_hiyuki_phase2_r2_sent = False
            self.axis_mark('Hiyuki phase2 macro: A1.10-dodge0.25 -> A1.10/read iai '
                           '-> right.05/F snapshot -> release.45 -> left.05 once '
                           '-> [F.05/wait1.45 or wait.60] -> A1.10 '
                           '-> tap E -> hold E/read iai -> no-right timed final iai '
                           '-> timed heavy -> R2 resource compensation -> R2; total planned kendo=3')
        steps = [
            lambda: self.axis_hiyuki_attack_chain('13 Hiyuki phase2 3A'),
            lambda: self.axis_dodge(self.AFTER_DODGE),
            lambda: self.axis_hiyuki_attack_chain('14 Hiyuki phase2 3A', read_iai=True),
            lambda: self.axis_hiyuki_ground_kendo(1, '14 first'),
            lambda: self.axis_hiyuki_attack_chain('15 Hiyuki post-kendo A'),
            self.axis_hiyuki_tap_hold_e,
            lambda: self.axis_finish_kendo_r2(first),
        ]
        for index in range(self.task._chl_hiyuki_phase2_step, len(steps)):
            self.task._chl_hiyuki_phase2_step = index
            self.axis_require_enemy()
            steps[index]()
            self.task._chl_hiyuki_phase2_step = index + 1
        self.task._chl_hiyuki_phase2_step = None

    def axis_hiyuki_iai_probe(self, tag):
        self.task.next_frame()
        value = self.axis_hiyuki_iai_count()
        self.axis_mark(f'Hiyuki iai count={value} ({tag})')
        return value

    def axis_hiyuki_attack_chain(self, tag, duration=None, read_iai=False):
        # 读豆放进点A的绝对时间窗口，不在结束后追加一个完整读图步骤。
        span = self.A_CHAIN_TIME if duration is None else duration
        self.axis_mark(tag + ' begin')
        end = time.time() + span
        read_at = end - min(self.PHASE2_IAI_READ_LEAD, span / 2)
        sampled = False
        while time.time() < end:
            if read_iai and not sampled and time.time() >= read_at:
                sampled = True
                self.axis_hiyuki_iai_probe('during ' + tag)
                if time.time() >= end:
                    break
            self.task.click()
            gap = min(self.A_INTERVAL, max(0.0, end - time.time()))
            if read_iai and not sampled:
                gap = min(gap, max(0.0, read_at - time.time()))
            self.axis_wait(gap)
        self.axis_mark(tag + ' inputs complete')

    def axis_hiyuki_kendo_read(self, before=None, prior_drop=False, prior_unknown=False, max_drop=1):
        # 只调用现有识别器；每次抓新帧，稳定两帧/.08s，避免单帧低读直接当消耗。
        deadline = time.time() + self.KENDO_BEAN_READ_CAP
        candidate, stable_at, hits = None, None, 0
        uncertain, saw_drop = prior_unknown, prior_drop
        while True:
            self.axis_require_enemy()
            self.task.next_frame()
            value = self.axis_hiyuki_iai_count()
            now = time.time()
            valid = (1 <= value <= self.HIYUKI_IAI_MAX if before is None
                     else max(0, before - max_drop) <= value <= before)
            if not valid:
                candidate, stable_at, hits = None, None, 0
                uncertain = True
            else:
                if before is not None:
                    if value < before:
                        saw_drop = True
                    elif saw_drop:
                        uncertain = True  # 曾减少又回升，不能据此认定吞键然后补刀。
                if candidate != value:
                    candidate, stable_at, hits = value, now, 1
                else:
                    hits += 1
                stable = hits >= 2 and now - stable_at >= self.KENDO_BEAN_STABLE_TIME
                if stable and (before is None or value < before):
                    return ('before' if before is None else 'consumed'), value
            if now >= deadline:
                if (before is not None and candidate == before and not uncertain
                        and hits >= 2 and now - stable_at >= self.KENDO_BEAN_STABLE_TIME):
                    return 'unchanged', before
                if before is None:
                    raise RuntimeError(f'CHL phase2 kendo beans unavailable ({value}); preserve blade')
                raise RuntimeError(f'CHL phase2 kendo bean evidence unknown/conflicting; '
                                   f'before={before} last={value}; preserve pending blade')
            self.axis_wait(min(0.05, max(0.0, deadline - now)))

    def axis_hiyuki_ground_kendo(self, count, tag, confirm_blocking=True):
        if tag == '17 final':
            try:
                return self.axis_hiyuki_final_kendo_chain(count, tag,
                                                          confirm_blocking=confirm_blocking)
            except KendoChainReady:
                # 末尾输入完成后进入重击收尾，不等待豆数确认。
                return None
        if tag == '14 first':
            return self.axis_hiyuki_first_blade(count, tag)
        # 每刀确认豆数恰少一个才递增confirmed；已发输入和实际消耗分别保存。
        states = self.task._chl_hiyuki_phase2_kendo
        state = states.get(tag)
        if state is None:
            if count not in (1, 2) or sum(s['count'] for s in states.values()) + count > 3:
                raise RuntimeError('CHL phase2 planned kendo exceeds three')
            state = {'count': count, 'confirmed': 0, 'blades_sent': 0, 'clicks': 0,
                     'stage': 'prepare', 'before': None, 'attempt': 0,
                     'dodge_at': None, 'right_done_at': None, 'left_at': None,
                     'next_at': 0.0, 'finish_at': 0.0}
            states[tag] = state
        while state['confirmed'] + state.get('skipped', 0) < count:
            if state['stage'] == 'prepare':
                self.axis_wait(max(0.0, state['next_at'] - time.time()))
                try:
                    _, beans = self.axis_hiyuki_kendo_read()
                except RuntimeError:
                    self.axis_hiyuki_kendo_diag(state, tag + '_beans_unavailable')
                    raise
                self.axis_mark(f'Hiyuki iai count={beans} '
                               f'(before ground kendo {tag} blade {state["confirmed"] + 1}; stable)')
                state.update(before=beans, attempt=0, stage='right',
                             dodge_at=None, right_done_at=None,
                             followup_drop_seen=False, followup_uncertain=False)
            if state['stage'] == 'retry':
                self.axis_wait(max(0.0, state['next_at'] - time.time()))
                # 补按前最后抓一帧；若此时出现延迟消耗/遮挡，先回到确认，不抢发第二刀。
                self.axis_require_enemy()
                self.task.next_frame()
                if self.axis_hiyuki_iai_count() != state['before']:
                    state['stage'] = 'confirm'
                    continue
                state.update(stage='right', dodge_at=None, right_done_at=None)
            if state['stage'] == 'right':
                if state['dodge_at'] is None:
                    self.task.executor.check_enabled(check_pause=False)
                    state['attempt'] += 1
                    state['dodge_at'] = time.time()
                    state['right_held'] = self.axis_hiyuki_kendo_pulse('right')
                    state['right_done_at'] = time.time()
                right_done = (state['right_done_at'] if state['right_done_at'] is not None
                              else state['dodge_at'])
                gap = (self.DODGE_TO_KENDO if state['attempt'] == 1
                       else self.KENDO_RETRY_RIGHT_DELAY)
                self.axis_wait(max(0.0, right_done + gap - time.time()), combat_check=False)
                self.task.executor.check_enabled(check_pause=False)
                # 输入抛错也先保留待确认；恢复先读豆，不能直接重复可能已经生效的左键。
                state['stage'] = 'confirm'
                state['blades_sent'] += 1
                state['clicks'] += 1
                state['left_at'] = time.time()
                state['next_at'] = state['dodge_at'] + self.KENDO_DERIVE
                # Both BaseChar.click and BaseWWTask.click force a 10ms click.
                # Explicit down/up preserves the phase2 pulse at the device layer.
                state['left_held'] = self.axis_hiyuki_kendo_pulse('left')
                state['left_up_at'] = time.time()
                self.axis_hiyuki_kendo_left_followup(state, tag)
                # 收招锚点取左键释放后与原排期两者的较晚时间。
                state['finish_at'] = max(state['left_up_at'] + self.KENDO_POST_IAI_SETTLE,
                                         state['dodge_at'] + self.KENDO1_DELAY
                                         + self.KENDO_OUT_TO_HOLD - self.KENDO_SPAM_LAST_GAP)
                self.axis_mark(f'17 Hiyuki ground kendo {tag} blade input sent; '
                               f'blade={state["confirmed"] + 1}/{count}; attempt={state["attempt"]}; '
                               f'right-to-left={state["left_at"] - state["dodge_at"]:.3f}s; '
                               f'actual-hold=right:{state.get("right_held", 0):.3f}s/left:{state["left_held"]:.3f}s; '
                               'await bean consumption')
            status, after = self.axis_hiyuki_kendo_read(
                before=state['before'], prior_drop=state.get('followup_drop_seen', False),
                prior_unknown=state.get('followup_uncertain', False))
            if status == 'consumed':
                before = state['before']
                state['confirmed'] += 1
                state['stage'] = 'prepare'
                self.axis_mark(f'17 Hiyuki ground kendo {tag} bean consumption confirmed; '
                               f'blade={state["confirmed"]}/{count}; beans={before}->{after}; '
                               f'attempt={state["attempt"]}')
            elif state['attempt'] < self.KENDO_BLADE_TRIES:
                state['stage'] = 'retry'
                self.axis_mark(f'17 Hiyuki ground kendo {tag} beans unchanged={after}; '
                               f'retry same blade after attempt={state["attempt"]}')
            else:
                self.axis_hiyuki_kendo_diag(state, tag)
                raise RuntimeError(f'CHL phase2 kendo input unconsumed after {state["attempt"]} attempts; '
                                   'preserve pending blade, F/R2 blocked')
        self.axis_wait(max(0.0, state['finish_at'] - time.time()))
        self.axis_mark(f'17 Hiyuki ground kendo {tag} inputs complete; '
                       f'clicks={state["clicks"]}; confirmed blades={state["confirmed"]}/{count}; '
                       f'skipped={state.get("skipped", 0)}')

    def axis_hiyuki_first_blade(self, count, tag):
        """首刀固定右/左各一次；F仅在右键按下时取一次，松左后立即走保存的分支。"""
        if count != 1:
            raise RuntimeError('CHL first ground kendo must be a single blade')
        states = self.task._chl_hiyuki_phase2_kendo
        state = states.get(tag)
        if state is None:
            if sum(s['count'] for s in states.values()) + count > 3:
                raise RuntimeError('CHL phase2 planned kendo exceeds three')
            state = {'count': count, 'confirmed': 0, 'blades_sent': 0, 'clicks': 0,
                     'stage': 'confirm', 'before': None, 'chain': False,
                     'pair_step': 0, 'dodge_at': None, 'left_up_at': None,
                     'right_held': 0.0, 'left_held': 0.0,
                     'execute_valid': False, 'post_step': 0, 'f_up_at': None,
                     'followup_drop_seen': False, 'followup_uncertain': False}
            states[tag] = state
        if state['pair_step'] == 0:
            self.task.executor.check_enabled(check_pause=False)
            # 原有豆数读数只记日志，不决定首刀和F分支。
            self.task.next_frame()
            beans = self.axis_hiyuki_iai_count()
            state['before'] = beans if 0 <= beans <= self.HIYUKI_IAI_MAX else None
            self.axis_mark(f'17 Hiyuki first blade bean read (diagnostic only)={beans}')
            state['pair_step'] = 1  # 右键发出后，异常恢复也不再发第二次。
            self.task.mouse_down(key='right')
            state['dodge_at'] = time.time()
            try:
                # 取帧/识别计入右键 .05s 保持窗口；仅检测这一次，不在居合后重查。
                self.task.next_frame()
                box = self.task.box_of_screen(0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True)
                state['execute_valid'] = bool(self.task.find_one(
                    'f_break', box=box, target_height=720, threshold=0.90)) and not self.task.is_pick_f()
                self.axis_wait(max(0.0, state['dodge_at'] + self.KENDO_INPUT_HOLD - time.time()),
                               combat_check=False)
            finally:
                self.task.mouse_up(key='right')
                state['right_done_at'] = time.time()
                state['right_held'] = state['right_done_at'] - state['dodge_at']
        if state['pair_step'] == 1:
            self.axis_wait(max(0.0, state['right_done_at'] + self.FIRST_KENDO_RIGHT_GAP - time.time()),
                           combat_check=False)
            self.task.executor.check_enabled(check_pause=False)
            state['left_at'] = time.time()
            state['pair_step'] = 2  # 左键一旦发出，恢复时只继续F/等待分支，不再补刀。
            try:
                state['left_held'] = self.axis_hiyuki_kendo_pulse('left')
            finally:
                state['left_up_at'] = time.time()
                state['clicks'] = 1
                state['blades_sent'] = 1
                state['stage'] = 'done'
                state['confirmed'] = count  # 旧字段兼容：只代表输入进度，并非消耗确认。
        if state['pair_step'] == 2:
            # 不经过外层步骤的敌人检查/抓帧，也不插日志，确保松左后直接发F。
            self.axis_hiyuki_first_execute(state)
            state['pair_step'] = 3
        self.axis_mark(f'17 Hiyuki ground kendo {tag} inputs complete; '
                       f'clicks={state["clicks"]}; blades_sent={state["blades_sent"]}/{count}; '
                       f'F snapshot={state["execute_valid"]}; consumption unverified')
        return state['before']

    def axis_hiyuki_final_kendo_chain(self, count, tag, confirm_blocking=True):
        # 双E后不发右键；按刀数安排连点、重击预输入和R2，豆数只作诊断。
        if count < 1:
            raise RuntimeError('CHL final iai chain requires at least one blade')
        states = self.task._chl_hiyuki_phase2_kendo
        state = states.get(tag)
        if state is None:
            # 末尾刀数受全轮3刀剩余额度限制，时序随最终刀数计算。
            remaining = 3 - sum(s['count'] for s in states.values())
            if remaining < 1:
                remaining = 1
            count = min(count, remaining)
            state = {'count': count, 'confirmed': 0, 'blades_sent': 0, 'clicks': 0,
                     'stage': 'confirm', 'before': None, 'chain': True, 'attempt': 1,
                     'pair_step': 0, 'baseline_sampled': False, 'retry_lefts': 0,
                     'stance_ready_at': None, 'left_up_at': None,
                     'pending_left_blades': 0, 'left_presses': 0,
                     'followup_drop_seen': False, 'followup_uncertain': False}
            states[tag] = state
        if state['pair_step'] == 0:
            self.task.executor.check_enabled(check_pause=False)
            # step 0/1 都记 1：被打断也绝不补出那一下会关掉架势的右键。
            state['pair_step'] = 1
            state['stance_ready_at'] = time.time()
            self.axis_mark('17 Hiyuki final chain double-E stance already active; '
                           'no right input; timed kendo spam starts')
        if not state['baseline_sampled'] and state['pair_step'] == 1:
            # 豆数仅用于诊断，不参与放行。
            self.task.next_frame()
            beans = self.axis_hiyuki_iai_count()
            state['baseline_sampled'] = True
            state['before'] = beans if 0 <= beans <= self.HIYUKI_IAI_MAX else None
            self.axis_mark(f'17 Hiyuki final stance bean read (diagnostic only)={beans}; '
                           f'planned blades={count}; 时刻表从这里起算')
        if state['pair_step'] == 1:
            # 时刻表：最后一刀出刀 -> 预输入重击 -> 重击起手
            last_out = (state['stance_ready_at'] + self.KENDO_FIRST_DELAY
                        + (count - 1) * self.KENDO_DERIVE)
            hold_at = last_out + self.KENDO_OUT_TO_HOLD
            heavy_start = last_out + self.KENDO_DERIVE
            state['last_kendo_out_at'] = last_out
            state['heavy_hold_at'] = hold_at
            state['heavy_start_at'] = heavy_start
            # 按配置节奏连点，保留重击预输入前的松键间隔。
            last_click_by = hold_at - self.KENDO_FINAL_LAST_GAP
            self.axis_mark(f'17 Hiyuki final kendo spam begin; blades={count}; '
                           f'first_out={last_out - state["stance_ready_at"]:.2f}s; '
                           f'pre-input heavy at={(hold_at - state["stance_ready_at"]):.2f}s')
            # 进连点前先把进度推到 2：连点途中被打断也不会从头再点一遍。
            state['pair_step'] = 2
            while True:
                self.task.executor.check_enabled(check_pause=False)
                self.axis_hiyuki_kendo_pulse('left', hold=self.KENDO_CLICK_HOLD)
                state['clicks'] += 1
                state['left_up_at'] = time.time()
                next_click = time.time() + self.KENDO_SPAM_INTERVAL
                if next_click > last_click_by:
                    break
                self.axis_wait(max(0.0, next_click - time.time()), combat_check=False)
            self.axis_mark(f'17 Hiyuki final kendo spam end; clicks={state["clicks"]}')
        if state['pair_step'] == 2:
            # 连点结束（或被打断后恢复到这里）：下一步只按时刻表预输入重击，不再点左键。
            self.axis_wait(max(0.0, state['heavy_hold_at'] - time.time()), combat_check=False)
            self.task.executor.check_enabled(check_pause=False)
            state['pair_step'] = 3
            state['blades_sent'] = count
            state['pending_left_blades'] = count - state['confirmed']
            # stage 必须先离开 'confirm'：否则 device 层会把这次按住当成居合左键（不是重击）。
            state['stage'] = 'heavy_pre'
            self.task.mouse_down()
            state['heavy_pre_input_at'] = time.time()
            self.axis_mark(f'17 Hiyuki final pre-input empowered heavy; attack held at '
                           f'{state["heavy_pre_input_at"] - state["stance_ready_at"]:.2f}s')
            raise KendoChainReady(tag)
        self.axis_mark(f'17 Hiyuki final chain inputs complete; clicks={state["clicks"]}; '
                       f'blades={count}')

    def axis_hiyuki_kendo_left_followup(self, state, tag):
        # Native Hiyuki clicks while hiyuki_left is visible. An early single
        # press can precede that prompt; wait within a bounded derive window.
        deadline = time.time() + self.KENDO_LEFT_FOLLOWUP_CAP
        next_press = time.time() + self.KENDO_SPAM_INTERVAL
        seen_left = False
        presses = 0
        while time.time() < deadline:
            self.axis_wait(min(0.05, max(0.0, deadline - time.time())))
            self.axis_require_enemy()
            self.task.next_frame()
            beans = self.axis_hiyuki_iai_count()
            if beans != state['before']:
                if (beans == state['before'] - 1 or
                        (state.get('chain') and max(0, state['before'] - (state['count']-state['confirmed'])) <= beans < state['before'])):
                    state['followup_drop_seen'] = True
                else:
                    state['followup_uncertain'] = True
                break  # Unknown/changed resource: confirm first, never blind spam.
            ready = bool(self.task.find_one('hiyuki_left', threshold=.5))
            if seen_left and not ready:
                break
            seen_left = seen_left or ready
            if ready and time.time() >= next_press:
                state['clicks'] += 1
                presses += 1
                held = self.axis_hiyuki_kendo_pulse('left')
                self.axis_mark(f'17 Hiyuki ground kendo {tag} native-left followup; '
                               f'press={presses}; actual-hold={held:.3f}s; beans={beans}')
                if presses >= self.KENDO_LEFT_FOLLOWUP_MAX:
                    break
                next_press = time.time() + self.KENDO_SPAM_INTERVAL

    def axis_hiyuki_kendo_pulse(self, key, hold=None):
        # Only phase2 kendo uses this pulse. Always release even when stopped.
        started = time.time()
        try:
            self.task.mouse_down(key=key)
            started = time.time()
            self.axis_wait(self.KENDO_INPUT_HOLD if hold is None else hold, combat_check=False)
        finally:
            self.task.mouse_up(key=key)
        return time.time() - started

    def axis_hiyuki_kendo_diag(self, state, tag):
        # One last-read game frame per blocked blade; diagnostics cannot change
        # the checkpoint or turn a rejected input into a successful blade.
        if state.get('diag_queued'):
            return
        state['diag_queued'] = True
        try:
            frame = self.task.frame.copy()
            folder = os.path.join(os.path.dirname(__file__), 'docs', 'phase2_auto_review', 'frames')
            os.makedirs(folder, exist_ok=True)
            path = os.path.join(folder, f'kendo_{tag.replace(" ", "_")}_{int(time.time()*1000)}.png')
            ready = {name: bool(self.task.find_one(name, threshold=.5))
                     for name in ('hiyuki_left', 'hiyuki_right', 'hiyuki_lib_forte')}
            self.logger.info(f'{self.AXIS_BUILD} phase2 blocked snapshot queued={path}; '
                             f'before={state["before"]}; confirmed={state["confirmed"]}; '
                             f'attempts={state["attempt"]}; native_prompts={ready}')
            def save():
                try:
                    if not cv2.imwrite(path, frame):
                        raise OSError('imwrite failed')
                    self.logger.info(f'{self.AXIS_BUILD} phase2 blocked snapshot saved={path}')
                except Exception as exc:
                    self.logger.warning(f'{self.AXIS_BUILD} phase2 snapshot save failed: {exc}')
            Thread(target=save, daemon=True).start()
        except Exception as exc:
            self.logger.warning(f'{self.AXIS_BUILD} phase2 snapshot queue failed: {exc}')

    def axis_hiyuki_first_execute(self, state=None):
        if state is None:
            state = self.task._chl_hiyuki_phase2_kendo['14 first']
        if state['post_step'] >= 3:
            return
        if not state['execute_valid']:
            self.axis_wait(max(0.0, state['left_up_at'] + self.FIRST_NO_EXECUTE_SETTLE - time.time()),
                           combat_check=False)
            state['post_step'] = 3
            self.axis_mark('17 F absent/pickup at right-down; waited .60 after left-up; continue A1.10')
            return
        if state['post_step'] == 0:
            self.task.executor.check_enabled(check_pause=False)
            self.task._chl_hiyuki_phase2_execute_at = time.time()
            state['post_step'] = 1  # 按F前保存，异常恢复不重复F。
            self.task.can_break = False
            try:
                self.task.send_key('f', down_time=self.FIRST_EXECUTE_HOLD)
            finally:
                state['f_up_at'] = time.time()
        if state['post_step'] == 1:
            self.axis_wait(max(0.0, state['f_up_at'] + self.FIRST_EXECUTE_SETTLE - time.time()),
                           combat_check=False)
            self.task.executor.check_enabled(check_pause=False)
        state['post_step'] = 3
        start = self.task._chl_hiyuki_phase2_execute_at
        self.add_freeze_duration(start, state['f_up_at'] + self.FIRST_EXECUTE_SETTLE - start)
        self.axis_mark('17 F execute from right-down snapshot; F.05 -> wait1.45; continue A1.10')

    def axis_hiyuki_tap_hold_e(self):
        state = getattr(self.task, '_chl_hiyuki_phase2_e', None)
        if state is None:
            state = {'stage': 'tap', 'tap_up': None, 'held': 0.0, 'hold_attempts': 0}
            self.task._chl_hiyuki_phase2_e = state
        key = self.get_resonance_key()
        if state['stage'] == 'tap':
            self.axis_attack_until(lambda: self.task.get_cd('resonance') <= 0,
                                   'Hiyuki E tap cooldown')
            # Save input progress before sending: errors cannot blindly retap E.
            state['stage'] = 'ready'
            down_at = time.time()
            try:
                self.task.send_key_down(key)
                down_at = time.time()
                self.axis_wait(self.PHASE2_E_TAP_HOLD, combat_check=False)
            finally:
                self.task.send_key_up(key)
                state['tap_up'] = time.time()
            self.record_resonance_use()
            self.axis_mark(f'16 Hiyuki E TAP UP actual-hold={state["tap_up"]-down_at:.3f}s')
        if state['stage'] == 'ready':
            self.axis_wait(max(0.0, state['tap_up'] + self.PHASE2_E_TAP_GAP - time.time()),
                           combat_check=False)
            deadline = time.time() + self.PHASE2_E_READY_CAP
            while True:
                self.axis_require_enemy()
                self.task.next_frame()
                inside, index, _ = self.task.in_team()
                cd = self.task.get_cd('resonance')
                if inside and index == self.index and self.task.available('resonance', check_color=False):
                    break
                if time.time() >= deadline:
                    self.axis_mark(f'16 Hiyuki second E not ready; cd={cd:.2f}; keep E checkpoint')
                    raise RuntimeError('CHL phase2 second E not ready; preserve E, no blind hold')
                self.axis_wait(0.05)
            self.axis_mark(f'16 Hiyuki second E ready; release-to-press={time.time()-state["tap_up"]:.3f}s; cd={cd:.2f}')
            state['stage'] = 'done'
            state['hold_attempts'] = state.get('hold_attempts', 0) + 1
            started = time.time()
            try:
                self.task.send_key_down(key)
                started = time.time()
                end = started + self.PHASE2_E_HOLD
                self.axis_mark('16 Hiyuki E HOLD DOWN after ready')
                self.axis_wait(self.PHASE2_E_HOLD / 2, combat_check=False)
                # 中点读一次豆；这个数就是末尾该连按几次左键。
                hold_beans = self.axis_hiyuki_iai_probe('during E HOLD')
                final_state = getattr(self.task, '_chl_hiyuki_phase2_kendo', {}).get('17 final')
                if final_state is not None and 0 <= hold_beans <= self.HIYUKI_IAI_MAX:
                    final_state['left_presses'] = hold_beans
                self.axis_wait(max(0.0, end - time.time()), combat_check=False)
            finally:
                self.task.send_key_up(key)
                state['held'] = time.time() - started
            self.record_resonance_use()
            self.axis_mark(f'16 Hiyuki E HOLD UP held={state["held"]:.3f}s; proceed directly to final stance; no landing/bean gate')

    def axis_finish_kendo_r2(self, first):
        if self.task._chl_hiyuki_phase2_finish_step < 2:
            state = (getattr(self.task, '_chl_hiyuki_phase2_kendo', {}) or {}).get('17 final', {})
            if state.get('blades_sent'):
                # 末尾输入已经发过（恢复回到这里）：绝不重按左键/重击，直接按时刻表往下走。
                self.axis_mark('17 Hiyuki final inputs already sent; resume at heavy; no left replay')
            else:
                # 请求刀数由R2发送状态选择，最终受末尾链的剩余额度限制。
                count = 2 if getattr(self.task, '_chl_hiyuki_phase2_r2_sent', False) else 3
                try:
                    self.axis_hiyuki_ground_kendo(count, '17 final', confirm_blocking=False)
                except KendoChainReady:
                    pass
            # 输入发完就记进度：框架恢复时只按时刻表继续，不再重按。
            self.task._chl_hiyuki_phase2_finish_step = 1
        self.axis_hiyuki_r2(first)

    def axis_hiyuki_heavy_frame(self, tag):
        # Bounded diagnostic frames from the actual task capture, saved off-thread.
        # No action decision depends on a snapshot or its encoding succeeding.
        if getattr(self.task, '_chl_hiyuki_heavy_frame_build', None) != self.AXIS_BUILD:
            self.task._chl_hiyuki_heavy_frame_build = self.AXIS_BUILD
            self.task._chl_hiyuki_phase2_heavy_frames = set()
            self.task._chl_hiyuki_heavy_frame_count = 0
        if getattr(self.task, '_chl_hiyuki_heavy_frame_count', 0) >= 24:
            return
        seen = getattr(self.task, '_chl_hiyuki_phase2_heavy_frames', set())
        if tag in seen:
            return
        seen.add(tag)
        self.task._chl_hiyuki_heavy_frame_count += 1
        try:
            frame = self.task.frame.copy()
            folder = os.path.join(os.path.dirname(__file__), 'docs', 'phase2_auto_review', 'frames')
            os.makedirs(folder, exist_ok=True)
            path = os.path.join(folder, f'heavy_{tag}_{int(time.time()*1000)}.png')
            prompts = {}
            for name in ('hiyuki_left', 'hiyuki_right', 'hiyuki_lib_forte'):
                match = self.task.find_one(name, threshold=.5)
                prompts[name] = getattr(match, 'confidence', bool(match))
            self.logger.info(f'{self.AXIS_BUILD} phase2 heavy frame={path}; '
                             f'beans={self.axis_hiyuki_iai_count()}; lock={bool(self.has_long_action2())}; prompts={prompts}')
            def save():
                try:
                    if not cv2.imwrite(path, frame):
                        raise OSError('imwrite failed')
                except Exception as exc:
                    self.logger.warning(f'{self.AXIS_BUILD} heavy frame save failed: {exc}')
            Thread(target=save, daemon=True).start()
        except Exception as exc:
            self.logger.warning(f'{self.AXIS_BUILD} heavy frame queue failed: {exc}')

    def axis_hiyuki_heavy_released_effect(self):
        if not getattr(self.task, '_chl_hiyuki_phase2_heavy_pending', False):
            return None
        deadline = time.time() + .40
        absent_at, hits = None, 0
        while True:
            self.task.next_frame()
            self.axis_require_enemy()
            inside, index, _ = self.task.in_team()
            now = time.time()
            present = bool(self.task.find_one('hiyuki_lib_forte', threshold=.5))
            if inside and index == self.index and present:
                self.task._chl_hiyuki_phase2_heavy_marker_seen = True
            if (inside and index == self.index and not present
                    and getattr(self.task, '_chl_hiyuki_phase2_heavy_marker_seen', False)):
                hits += 1
                if absent_at is None:
                    absent_at = now
                if hits >= 3 and now - absent_at >= self.PHASE2_HEAVY_ABSENT_TIME:
                    # 至少连续3帧消失，排除单帧误判。
                    self.task._chl_hiyuki_phase2_heavy_at = now
                    self.task._chl_hiyuki_phase2_heavy_pending = False
                    self.axis_hiyuki_heavy_frame('consumed_after_release')
                    self.axis_mark('17 Hiyuki empowered heavy consumption confirmed; after release; no extra A')
                    return now
            else:
                absent_at, hits = None, 0
            if now >= deadline:
                return None
            self.axis_wait(.05)

    def axis_hiyuki_heavy_pre_input(self, first):
        """【v117】收尾段：末尾连点之后按住攻击，预输入强化重击（纯定时，不读屏判定）。"""
        self.task._chl_hiyuki_phase2_heavy_at = None
        self.task._chl_hiyuki_phase2_heavy_pending = True
        if getattr(self.task, 'mouse_at', None) is not None:
            # 攻击已经按住（例如恢复路径进来）：直接沿用这一刻当锚点，不重复按下。
            down_at = time.time()
            self.axis_mark(f'17 Hiyuki empowered heavy pre-input already held; first={bool(first)}')
            return down_at
        self.task.mouse_down()
        down_at = time.time()
        self.axis_mark(f'17 Hiyuki empowered heavy pre-input A HOLD DOWN; first={bool(first)}')
        return down_at

    def axis_hiyuki_confirm_heavy(self, first=False, pre_input_at=None):
        """【v117】强化重击确认：参考 Hiyuki__Lucilla__Suisui —— 纯定时，不读图标、不查豆数。

        预输入的重击在"最后一刀派生帧"起手（见收尾段时刻表），所以：
          起手时刻  = 按住攻击时刻 + KENDO_DERIVE - KENDO_OUT_TO_HOLD
          松攻击/按R = 起手时刻 + HEAVY_TO_R
        恢复路径也一样：只要预输入过一次就不再重按，仍然按同一时刻表往下走。
        """
        state = (getattr(self.task, '_chl_hiyuki_phase2_kendo', {}) or {}).get('17 final', {})
        if self.task._chl_hiyuki_phase2_heavy_at is not None:
            return self.task._chl_hiyuki_phase2_heavy_at
        if pre_input_at is None:
            pre_input_at = state.get('heavy_pre_input_at')
        if pre_input_at is None:
            # 恢复但状态没了：至少不重复按，把当前时刻当锚点。
            pre_input_at = time.time()
            self.axis_mark('17 Hiyuki heavy pre-input timestamp missing; use now as anchor')
        heavy_at = pre_input_at + self.KENDO_DERIVE - self.KENDO_OUT_TO_HOLD
        self.task._chl_hiyuki_phase2_heavy_at = heavy_at
        self.axis_mark(f'17 Hiyuki empowered heavy timing anchor; pre_input={pre_input_at:.3f}; '
                       f'heavy_start={heavy_at:.3f} (+{self.KENDO_DERIVE - self.KENDO_OUT_TO_HOLD:.2f}s)')
        return heavy_at

    def axis_hiyuki_r2(self, first):
        started = time.time()
        state = (getattr(self.task, '_chl_hiyuki_phase2_kendo', {}) or {}).get('17 final', {})
        pre_input_at = state.get('heavy_pre_input_at')
        if pre_input_at is None and state.get('pair_step', 0) >= 3:
            # 预输入中断后补按一次，沿用原排定时间，避免重等整段时序。
            pre_input_at = state.get('heavy_hold_at') or time.time()
            self.task.mouse_down()
            state['heavy_pre_input_at'] = time.time()
            self.axis_mark('17 Hiyuki heavy pre-input re-armed after interruption')
        if pre_input_at is None:
            # 兼容路径（用例/异常恢复直接进 R2）：没有走过末尾链，这里补一次预输入按住攻击。
            pre_input_at = self.axis_hiyuki_heavy_pre_input(first)
        # 采样强化图标仅作诊断，不参与时序判定。
        self.task.next_frame()
        self.lib_heavy_available()
        heavy_at = self.axis_hiyuki_confirm_heavy(first, pre_input_at)
        if self.task._chl_hiyuki_phase2_r2_sent:
            # 已发R2的异常恢复只收尾；不补发第二次R2或重复重击/居合。
            self.axis_mark('17 Hiyuki R2 resume after input interruption; no second charge')
            self.task.in_liberation = True
            try:
                while not self.axis_poll(lambda: self.task.in_team()[0], 1.0):
                    self.axis_recovery_check()
            finally:
                self.task.in_liberation = False
            self.task._chl_hiyuki_transformed = False
            self.axis_mark('Hiyuki R2 interrupted path ended; HUD returned; charge effect unchecked')
            return
        # 沿用预输入时序：重击起手后松攻击按R，达到蓄力截止时间后松R。
        self.task.next_frame()
        self.lib_heavy_available()
        heavy_at = self.axis_hiyuki_confirm_heavy(first, pre_input_at)
        charge = self.R2_CHARGE_FIRST if first else self.R2_CHARGE_LOOP
        # R2未就绪时先松攻击补能，就绪后恢复按住，仍沿用原时序。
        if not (self.task.use_liberation and self.liberation_available()):
            self.task.mouse_up()
            self.axis_attack_until(lambda: self.task.use_liberation and self.liberation_available(),
                                   'Hiyuki R2 energy/cooldown after heavy')
            self.task.mouse_down()
        # 等到重击后的R2时点；期间图标采样仅作诊断。
        while time.time() < heavy_at + self.HEAVY_TO_R:
            self.task.next_frame()
            self.task.executor.check_enabled(check_pause=False)
            self.lib_heavy_available()
            self.axis_wait(min(0.05, max(0.0, heavy_at + self.HEAVY_TO_R - time.time())),
                           combat_check=False)
        self.task.mouse_up()
        self.axis_mark(f'17 Hiyuki attack released at heavy_start+{self.HEAVY_TO_R:.2f}s; press R2')
        key = self.get_liberation_key()
        pressed_at = time.time()
        # 松 R 的时刻比"此刻"至少留够一个循环档的蓄力，避免恢复/延迟把按住截短。
        release_r = max(heavy_at + self.HEAVY_ANIM + charge, pressed_at + self.R2_CHARGE_LOOP)
        self.task.send_key_down(key)
        self.task._chl_r2_held_key = key
        self.task._chl_hiyuki_phase2_r2_sent = True
        try:
            self.axis_mark('17 Hiyuki R2 HOLD DOWN once')
            self.axis_wait(max(0.0, release_r - time.time()))
        finally:
            if getattr(self.task, '_chl_r2_held_key', None) is not None:
                self.task.send_key_up(key)
                self.task._chl_r2_held_key = None
        self.axis_mark(f'17 Hiyuki R2 HOLD UP held={time.time() - pressed_at:.2f}s')
        self.record_liberation_use()
        self.task.in_liberation = True
        try:
            while not self.axis_poll(lambda: self.task.in_team()[0], 1.0):
                self.axis_mark('Hiyuki R2 animation ongoing; wait for HUD')
        finally:
            self.task.in_liberation = False
        self.add_freeze_duration(started, time.time() - started)
        self.task._chl_hiyuki_transformed = False
        self.axis_mark('Hiyuki R2 inputs complete; HUD returned')

    def _axis_run(self, chisa, lucilla, first):
        # 每次成功动作后保存位置；动作异常恢复后从该动作重试，避免重跑启动轴。
        steps = []
        if first:
            steps.extend([
                lambda: self.axis_switch(self),
                lambda: self.axis_prepare_takeoff('01 Hiyuki E takeoff'),
            ])
        chisa_r_step = len(steps) + 4
        lucilla_intro_step = len(steps) + 14
        enhanced_e_step = len(steps) + 5
        steps.extend([
            lambda: self.axis_switch(chisa, air_handoff=True),
            lambda: self.axis_chisa_open(chisa, airborne=not first),
            lambda: self.axis_chisa_fill_to_half(chisa),
            lambda: self.axis_echo(chisa, settle=0.0),
            lambda: self.axis_liberation(chisa, '03 Chisa R', intro_if_full=True),
            lambda: self.axis_chisa_enhanced_e(chisa),
            lambda: self.axis_chisa_first_lucilla(chisa, lucilla),
            lambda: self.axis_lucilla_perfect_e(lucilla),
            lambda: self.axis_switch(chisa),
            self.axis_chisa_tap_chain,
            lambda: self.axis_switch(self),
            lambda: self.axis_chain(0.85, '07 Hiyuki A2-A3'),
            lambda: self.axis_switch(chisa),
            self.axis_chisa_saw_finisher,
            lambda: self.axis_switch(lucilla, intro=True),
            lambda: self.axis_lucilla_burst(lucilla),
            self.axis_hiyuki_intro,
            self.axis_hiyuki_burst,
            lambda: self.axis_hiyuki_tail(first),
            lambda: self.axis_prepare_takeoff('18 Hiyuki E takeoff handoff', require_intro=True),
            lambda: self.axis_switch(chisa, intro=True, air_handoff=True),
        ])
        index = getattr(self.task, '_chl_axis_step', 0)
        while index < len(steps):
            self.task._chl_axis_step = index
            # R返回后发E并直接切洛瑟拉；切人内部/后续步骤继续检查。
            if index not in (enhanced_e_step, enhanced_e_step + 1):
                self.axis_require_enemy()
            result = steps[index]()
            if index == chisa_r_step and result is False:
                index = lucilla_intro_step
            else:
                index += 1
            # 先保存分支目标；异常恢复不会再走被跳过的强化E和穿插段。
            self.task._chl_axis_step = index

    def axis_prepare_takeoff(self, tag, require_intro=False):
        # 起飞前限时补协奏；超时仍起飞，由后续切人处理平切降级。
        if require_intro:
            self.axis_attack_until_bounded(lambda: self.axis_con_full(self),
                                           self.INTRO_CON_FILL_CAP, 'Hiyuki con before takeoff')
        # 启动E松手即继续；末尾交接保留配置的等待。
        settle = self.TAKEOFF_E_SETTLE if require_intro else 0.0
        self.axis_resonance(self, self.TAKEOFF_E_HOLD, tag, settle)

    # ==================== 残响条读数：过半就放 R ====================
    def saw_bar_box(self):
        # 画面比例 -> 当前分辨率；非 16:9 由 box_of_screen 内部按 16:9 内容区换算
        return self.task.box_of_screen(*self.SAW_BOX, name='chl_saw_bar', hcenter=True)

    def saw_mid_box(self):
        x1, y1, x2, y2 = self.SAW_BOX
        mid = (x1 + x2) / 2
        half = (self.SAW_MID_WIDTH / max(1, self.task.screen_width)) / 2
        return self.task.box_of_screen(mid - half, y1 + 0.0007, mid + half, y2 - 0.0007,
                                       name='chl_saw_mid', hcenter=True)

    def saw_diag_scan(self):
        """标定用：把血条上方那一带按 6x2 网格打一遍品红占比，一行日志。

        换机器(不同分辨率/UI缩放)识别不到时，把这一行发出来就能定位条在哪。
        """
        cells = []
        for yy in (0.900, 0.925):
            row = []
            for i in range(6):
                x0 = 0.30 + i * 0.07
                box = self.task.box_of_screen(x0, yy, x0 + 0.07, yy + 0.02, name='chl_saw_diag')
                row.append(f'{self.task.calculate_color_percentage(self.SAW_LIT_COLOR, box):.2f}')
            cells.append('|'.join(row))
        self.axis_mark('03 Chisa saw diag y0.90=' + cells[0] + ' y0.925=' + cells[1])

    def saw_analyze(self, roi):
        """只计算小ROI；返回真实条长，-1表示遮挡/证据冲突。无抓帧、无输入、无写盘。"""
        started = perf_counter()
        if (roi.shape[1], roi.shape[0]) != self.SAW_REF_SIZE:
            interpolation = cv2.INTER_AREA if roi.shape[0] > self.SAW_REF_SIZE[1] else cv2.INTER_LINEAR
            roi = cv2.resize(roi[:, :, :3], self.SAW_REF_SIZE, interpolation=interpolation)
        rgb = roi[:, :, :3].astype(np.int16)
        b, g, r = rgb[:, :, 0], rgb[:, :, 1], rgb[:, :, 2]
        # 同时要求品红的两个色差：灰轨和红色特效都不能仅凭红高/绿低过门。
        lit = (r >= 150) & (r - g >= 50) & (r - b >= 25) & (b - g >= 25)
        centers = self.SAW_CELL_CENTERS
        patches = lit[2:9, self.SAW_PATCH_INDEX]
        scores = patches.mean(axis=(0, 2))
        states = np.where(scores >= self.SAW_CELL_LIT_MIN, 1, np.where(scores <= 0.20, 0, -1))
        white = cv2.inRange(roi[:, :, :3], (221, 221, 221), (255, 255, 255)) != 0
        covered = white[2:9, self.SAW_PATCH_INDEX].mean(axis=(0, 2))
        states[(states != 1) & (covered >= 0.35)] = -1
        missing = np.flatnonzero(states != 1)
        count = int(missing[0]) if missing.size else len(centers)
        slot_fill = float((centers[count] - self.SAW_CELL_PITCH / 2) / roi.shape[1]) if missing.size else 1.0
        # 亮星白色核心在11像素条内形成窄竖线；宽泛白光不能当成末端星。
        white_columns = np.flatnonzero(white.sum(axis=0) >= 2)
        groups = np.split(white_columns, np.flatnonzero(np.diff(white_columns) > 1) + 1) if white_columns.size else []
        stars = [float(group.mean() / roi.shape[1]) for group in groups if 1 <= len(group) <= 12]
        star = stars[0] if len(stars) == 1 else -1.0
        fill, reason = -1.0, 'occluded'
        if np.count_nonzero(states[count + 2:] == 1) > 1:
            reason = 'noncontiguous cells'
        elif len(stars) > 1:
            reason = 'multiple stars'
        elif star >= 0.0:
            if abs(star - slot_fill) <= self.SAW_STAR_EDGE_TOLERANCE:
                fill, reason = star, 'cells+star'
            else:
                reason = 'star/cells disagree'
        elif count == len(centers):
            # 满条亮星可能被右边界裁切；必须有40个明确亮格及格子/间隙纹理。
            # 整条被均匀染粉时没有格子纹理，不能被当成满条。
            gray = cv2.cvtColor(roi[:, :, :3], cv2.COLOR_BGR2GRAY).astype(np.float32)
            cores = gray[2:9, self.SAW_CORE_INDEX].mean(axis=(0, 2))
            gaps = gray[2:9, self.SAW_GAP_INDEX].mean(axis=(0, 2))
            if float(scores.min()) >= 0.60 and float(np.median(cores - gaps)) >= 15.0:
                fill, reason = 1.0, '40 clear cells with texture'
            else:
                reason = 'full track without clear star/texture'
        elif np.any(states == -1) or (count and float(scores[:count].min()) < 0.60):
            reason = 'uncertain cells without star'
        else:
            # 无亮星时只能用明确的连续亮格和空格，取保守的格间边界。
            fill, reason = (slot_fill if count else 0.0), 'clear cells only'
        return dict(fill=fill, slot_fill=slot_fill, star=star,
                    prefix=count, total=self.SAW_CELL_COUNT,
                    mid=float(lit[:, 174:198].mean()),
                    reason=reason, calc_ms=(perf_counter() - started) * 1000)

    def saw_read(self, which='mid'):
        """bar=可信填充长度；mid=诊断颜色读数。-1表示HUD不可读或识别冲突。"""
        if which == 'mid':
            return getattr(self, '_chl_saw_measure', {}).get('mid', -1.0)
        inside, index, _ = self.task.in_team()
        chisa = self.teammate('Chisa')
        if not inside or chisa is None or index != chisa.index:
            self._chl_saw_measure = dict(fill=-1.0, mid=-1.0, reason='HUD unavailable')
            return -1.0
        try:
            roi = self.saw_bar_box().crop_frame(self.task.frame)
            if roi is None or roi.size == 0:
                raise ValueError('empty saw ROI')
            self._chl_saw_measure = self.saw_analyze(roi)
            return self._chl_saw_measure['fill']
        except Exception as exc:
            self._chl_saw_measure = dict(fill=-1.0, mid=-1.0, reason=f'probe failed: {exc}')
            self.logger.info(f'CHL saw probe failed: {exc}')
            return -1.0

    # 绯雪二阶段居合豆识别。
    def hiyuki_iai_tpl(self):
        """解码并缓存居合图标模板的梯度图（只算一次）。"""
        cached = getattr(self, '_chl_iai_tpl', None)
        if cached is not None:
            return cached
        tpl = None
        try:
            buf = np.frombuffer(base64.b64decode(self.HIYUKI_IAI_TPL_B64), np.uint8)
            tpl = cv2.imdecode(buf, cv2.IMREAD_COLOR)
        except Exception as exc:
            self.logger.info(f'CHL iai template decode failed: {exc}')
        self._chl_iai_tpl = tpl
        return tpl

    @staticmethod
    def _chl_grad(img):
        """梯度幅值：重特效帧里亮度/颜色都在变，梯度最稳。"""
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)
        return np.clip(cv2.magnitude(gx, gy), 0, 255).astype(np.uint8)

    def axis_hiyuki_iai_count(self):
        """【v56】读"还能打几个居合" = 屏幕上那个紫底白翼圆图标有几个（上限 3）。

        返回 0~3；**-1 = 现在读不了**（不是绯雪在场 / 模板坏了）。
        图标只在自己在场时出现，所以先判 in_team。用户要求：**只识别，先不接判据**。
        """
        tpl = self.hiyuki_iai_tpl()
        if tpl is None:
            return -1
        hiyuki = self.teammate('Hiyuki')
        try:
            inside, index, _ = self.task.in_team()
        except Exception:
            return -1
        if not inside or hiyuki is None or index != hiyuki.index:
            return -1
        try:
            box = self.task.box_of_screen(*self.HIYUKI_IAI_BOX, name='chl_iai')
            roi = box.crop_frame(self.task.frame)
            if roi is None or roi.size == 0:
                return -1
            # 仅将HUD搜索区统一到1440p标定尺寸，再计算梯度。
            x1, y1, x2, y2 = self.HIYUKI_IAI_BOX
            ref_w, ref_h = self.HIYUKI_IAI_REF_SIZE
            target = (round((x2 - x1) * ref_w), round((y2 - y1) * ref_h))
            if (roi.shape[1], roi.shape[0]) != target:
                interpolation = cv2.INTER_AREA if roi.shape[0] > target[1] else cv2.INTER_LINEAR
                roi = cv2.resize(roi, target, interpolation=interpolation)
            tpl_g = self._chl_grad(tpl)
            roi_g = self._chl_grad(roi)
            if roi_g.shape[0] < tpl_g.shape[0] or roi_g.shape[1] < tpl_g.shape[1]:
                return -1
            res = cv2.matchTemplate(roi_g, tpl_g, cv2.TM_CCOEFF_NORMED)
            ys, xs = np.where(res >= self.HIYUKI_IAI_MATCH_MIN)
            if len(xs) == 0:
                return 0
            pts = sorted(zip(xs.tolist(), ys.tolist(), res[ys, xs].tolist()), key=lambda t: -t[2])
            # 非极大值抑制：已统一到标定尺寸，去重距离也使用标定像素。
            gap = self.HIYUKI_IAI_MIN_GAP
            keep = []
            for x, y, _ in pts:
                if all(abs(x - kx) > gap for kx, _, _ in keep):
                    keep.append((x, y, 0.0))
                if len(keep) >= self.HIYUKI_IAI_MAX:
                    break
            return len(keep)
        except Exception as exc:
            self.logger.info(f'CHL iai probe failed: {exc}')
            return -1

    def axis_saw_diag_save(self, bar, mid, peak, recent, elapsed, hits):
        """只复制判定帧并启动后台存图，Q/R不等待标注与PNG写盘。"""
        started = perf_counter()
        try:
            previous = getattr(self.task, '_chl_saw_diag_thread', None)
            if previous is not None and previous.is_alive():
                self.logger.info(f'{self.AXIS_BUILD} 03 Chisa saw DIAG skipped: writer busy')
                return None
            frame = self.task.frame.copy()
            box = self.saw_bar_box()
            coords = (int(box.x), int(box.y), int(box.width), int(box.height))
            measure = dict(getattr(self, '_chl_saw_measure', {}))
            out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'docs', 'saw_diag')
            path = os.path.join(out_dir, f'{self.AXIS_BUILD}_saw_gate_{int(time.time() * 1000)}_fill{bar:.3f}.png')
            worker = Thread(target=self._axis_saw_diag_write,
                            args=(frame, coords, measure, self.AXIS_BUILD, self.logger, path,
                                  bar, mid, peak, tuple(recent), elapsed, hits,
                                  self.SAW_LIT_MIN, self.SAW_CONFIRM_HITS, self.SAW_CONFIRM_WINDOW),
                            name='chl_saw_diag', daemon=True)
            self.task._chl_saw_diag_thread = worker
            worker.start()
            self.logger.info(f'{self.AXIS_BUILD} 03 Chisa saw DIAG queued {path}; '
                             f'copy_start={((perf_counter() - started) * 1000):.2f}ms (async)')
            return path
        except Exception as exc:
            self.logger.info(f'{self.AXIS_BUILD} 03 Chisa saw DIAG save failed: {exc}')
            return None

    @staticmethod
    def _axis_saw_diag_write(frame, coords, measure, build, logger, path, bar, mid, peak,
                             recent, elapsed, hits, threshold, need, window):
        """只使用已复制的帧和判定数据，绝不读取task、抓帧或发送输入。"""
        started = perf_counter()
        try:
            x, y, w, h = coords
            roi = frame[y:y + h, x:x + w, :3].copy()
            height, width = frame.shape[:2]
            cv2.rectangle(frame, (x - 2, y - 2), (x + w + 1, y + h + 1), (0, 255, 0), 1)
            threshold_x = x + int(round(threshold * w))
            cv2.line(frame, (threshold_x, y - 10), (threshold_x, y + h + 10), (0, 165, 255), 2)
            cv2.rectangle(frame, (8, 8), (width - 9, min(height - 1, 290)), (20, 20, 20), -1)
            lines = [
                f'{build} | Q-R GATE PASS | Chisa HUD | ASYNC',
                f'fill={bar:.3f} threshold={threshold:.2f} peak={peak:.3f} '
                f'old_color={measure.get("legacy", -1):.3f} mid={mid:.3f} elapsed={elapsed:.2f}s',
                f'recent hits={hits}/{len(recent)} need={need}/{window} '
                + 'values=' + ','.join(f'{v:.3f}' for v in recent),
                f'box={x},{y},{w},{h} | green=sample ROI | orange=threshold reference | raw ROI below',
            ]
            for number, line in enumerate(lines):
                cv2.putText(frame, line, (20, 34 + number * 30), cv2.FONT_HERSHEY_SIMPLEX,
                            0.58, (245, 245, 245), 1, cv2.LINE_AA)
            zoom = max(1, min(4, (width - 40) // max(1, w), (height - 150) // max(1, h)))
            enlarged = cv2.resize(roi, (w * zoom, h * zoom), interpolation=cv2.INTER_NEAREST)
            frame[145:145 + h * zoom, 20:20 + w * zoom] = enlarged
            colors = {1: (0, 255, 0), 0: (150, 150, 150), -1: (0, 220, 255)}
            for center, state in zip(measure.get('centers', ()), measure.get('states', ())):
                native_x = x + int(round(center * w / 372))
                cv2.circle(frame, (native_x, y - 18), 2, colors[state], -1)
                cv2.circle(frame, (20 + int(round(center * w * zoom / 372)), 145 + h * zoom + 12),
                           2, colors[state], -1)
            edge_x = x + int(round(bar * w))
            cv2.line(frame, (edge_x, y - 8), (edge_x, y + h + 8), (255, 255, 0), 1)
            extra = [f'lit-prefix={measure.get("prefix", -1)}/{measure.get("total", 40)} '
                     f'cells-end={measure.get("slot_fill", -1):.3f} star={measure.get("star", -1):.3f} '
                     f'reason={measure.get("reason", "unknown")} calc={measure.get("calc_ms", -1):.3f}ms',
                     'dots: green=lit grey=empty yellow=uncertain | cyan=detected end | orange=60%']
            for number, line in enumerate(extra):
                cv2.putText(frame, line, (20, 230 + number * 28), cv2.FONT_HERSHEY_SIMPLEX,
                            0.58, (245, 245, 245), 1, cv2.LINE_AA)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            if not cv2.imwrite(path, frame, [cv2.IMWRITE_PNG_COMPRESSION, 1]):
                raise OSError(f'cv2.imwrite returned False: {path}')
            logger.info(f'{build} 03 Chisa saw DIAG saved {path}; '
                        f'fill={bar:.3f} recent_hits={hits}/{len(recent)} '
                        f'worker={perf_counter() - started:.3f}s (async)')
            return path
        except Exception as exc:
            logger.info(f'{build} 03 Chisa saw DIAG save failed: {exc}')
            return None

    def axis_chisa_fill_to_half(self, chisa):
        """平A攒残响：可信填充长度达到60%才放行Q/R。

        SAW_GATE_ENABLED=False 时只打探针、不改轴行为(标定用)；
        判据6s未成立就交回框架，保留本步重试，不使用无条件Q/R兜底。

        【v42 用户定】点A 节奏不动（每 SAW_FILL_INTERVAL=0.15s 一下），但每个攻击间隔里
        **看 2 眼**（采样间隔 SAW_SAMPLE_INTERVAL=0.08s）。读条与点A 解耦：0.15s 是给攻击
        动画的，不是读条需要的。v64要求最近6帧至少4帧过线，不再全程累计。
        """
        cap = self.SAW_FILL_CAP if self.SAW_GATE_ENABLED else self.SAW_PROBE_SECONDS
        box0 = self.saw_bar_box()
        self.axis_mark(f'03 Chisa saw geom screen={self.task.screen_width}x{self.task.screen_height} '
                       f'box={box0.x},{box0.y},{box0.width},{box0.height}')
        started = time.time()
        hits = 0
        recent = deque(maxlen=self.SAW_CONFIRM_WINDOW)
        peak = -1.0
        last = -1.0
        trace = []
        next_trace = 0.0

        def sample():
            """看一眼 + 判定；放行返回 True。"""
            nonlocal hits, peak, last, next_trace
            # 每次读数前刷新缓存画面，防止同一帧被重复计入确认窗口。
            self.task.next_frame()
            elapsed = time.time() - started
            bar = self.saw_read('bar')
            mid = self.saw_read('mid')
            if self.SAW_GATE_ENABLED and elapsed >= self.SAW_SETTLE:
                # 遮挡和不可读也占窗口位置，避免拼接久远尖峰。
                recent.append(bar)
                hits = sum(value >= self.SAW_LIT_MIN for value in recent)
                if bar >= 0.0:
                    peak = max(peak, bar)
                if 0.0 <= bar < self.SAW_LIT_MIN and hits and last >= 0.0 and bar < last - self.SAW_DROP_TOLERANCE:
                    self.axis_mark(f'03 Chisa saw dip {last:.3f}->{bar:.3f} (occlusion?); '
                                   f'recent_hits={hits}/{len(recent)} peak={peak:.3f}')
            if elapsed >= next_trace and len(trace) < 14:
                next_trace = elapsed + 0.5
                trace.append(f'{elapsed:.2f}:{bar:.3f}/{mid:.3f}/h{hits}/{len(recent)}p{peak:.2f}')
            if self.SAW_GATE_ENABLED and elapsed >= self.SAW_SETTLE:
                # 最近窗口命中够 + 当前帧过线 + 当前帧贴峰值；维持0.60阈值。
                if (hits >= self.SAW_CONFIRM_HITS and bar >= self.SAW_LIT_MIN
                        and bar >= peak - self.SAW_PEAK_TOLERANCE):
                    self.axis_mark(f'03 Chisa saw trace {" ".join(trace)}')
                    self.axis_mark(f'03 Chisa saw over half bar={bar:.3f} peak={peak:.3f} '
                                   f'hits={hits}/{len(recent)} window={self.SAW_CONFIRM_WINDOW} '
                                   f'after {elapsed:.2f}s; fire Q-R now')
                    return True
            last = bar
            return False

        while time.time() - started < cap:
            # 平A 节奏不变：每 SAW_FILL_INTERVAL=0.15s 一下（窗口以下按时刻为锚）。
            self.axis_tap()
            window_end = time.time() + self.SAW_FILL_INTERVAL
            while True:
                # 这一个攻击间隔里看 2 眼（0.08s 一眼），读数与点A 互不牵制。
                if sample():
                    return True
                self.axis_recovery_check()
                left = window_end - time.time()
                if left <= 0:
                    break
                self.axis_wait(min(self.SAW_SAMPLE_INTERVAL, left))
        self.axis_mark(f'03 Chisa saw trace {" ".join(trace)}')
        if self.SAW_GATE_ENABLED:
            self.axis_mark(f'03 Chisa saw fill unconfirmed in {cap:.1f}s; '
                           f'return to framework and retry this step; Q-R blocked; '
                           f'reason={getattr(self, "_chl_saw_measure", {}).get("reason", "unknown")}')
            raise RuntimeError('CHL saw fill unconfirmed; retry current step')
        else:
            self.axis_mark(f'03 Chisa saw probe done ({cap:.1f}s); axis behaviour unchanged')
        return False

    def axis_chisa_tap_chain(self, saw=True):
        if saw:
            # 已到绯雪时，重试只确认，不再开始千咲的点A段。
            self.task.next_frame()
            current = self.current_axis_char()
            if current is not None and current.index == self.index:
                self.axis_switch(self)
                return
            chisa = self.teammate('Chisa')
            if current is None or chisa is None or current.index != chisa.index:
                raise RuntimeError('CHL Chisa attack handoff source unavailable; retry current step')
            started = time.time()
            send_at = started + self.CHISA_SAW_SWITCH_DELAY
            taps = 0
            self.axis_mark(f'06 Chisa saw A TAPS begin; duration={self.CHISA_SAW_SWITCH_DELAY:.2f}s to switch key')

            def tap_until(deadline):
                nonlocal taps
                while time.time() < deadline:
                    self.task.executor.check_enabled(check_pause=False)
                    self.task.mouse_down()
                    try:
                        self.axis_wait(min(0.05, max(0.0, deadline - time.time())), combat_check=False)
                    finally:
                        self.task.mouse_up()
                    taps += 1
                    self.axis_wait(min(self.CHISA_SAW_TAP_GAP, max(0.0, deadline - time.time())),
                                   combat_check=False)

            def attack_complete(sent_at):
                self.axis_mark(f'06 Chisa saw A TAPS complete; switch key sent after={sent_at - started:.3f}s; '
                               f'taps={taps}; A released before switch')

            # 最后0.20s预先做切人准备，再在剩余时间点A至绝对截止。
            tap_until(send_at - 0.20)
            self.axis_switch(self, attack_handoff=(send_at, attack_complete, tap_until))
            return
        tag = '03 Chisa normal 3A'
        gaps = self.CHISA_NORMAL_A_GAPS
        self.axis_mark(tag + ' begin: exactly 3 taps')
        for number, gap in enumerate(gaps, 1):
            self.axis_tap()
            self.axis_mark(f'{tag} A{number} sent; animation wait {gap:.2f}s')
            self.axis_wait(gap)
        self.axis_mark(tag + ' animations complete')

    def axis_chisa_saw_finisher(self):
        # 第6格持续点A至2.00s切绯雪；回场只点一次锯终。
        self.axis_tap()
        self.axis_wait(self.CHISA_FINISHER_SETTLE)
        self.axis_mark('08 Chisa saw finisher inputs complete')
