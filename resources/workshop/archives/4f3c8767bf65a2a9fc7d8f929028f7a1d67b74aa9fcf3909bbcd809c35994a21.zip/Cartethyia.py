import ctypes
import threading
import time

from src.char.BaseChar import SwitchPriority
from src.char.Cartethyia import Cartethyia as NativeCartethyia

# ==================== 物理 F 键监视 ====================
# 跟 Hsin__Rover__Suisui/Hsin.py(心雷穗 v1.0)里那份逐字相同, 说明见 Chisa__Suisui__YangYangSp/YangYangSp.py。
F_VK = 0x46              # 'F'
F_POLL_INTERVAL = 0.05   # 一次按键按住的时间远大于这个, 不会漏采
F_LOG_DEBOUNCE = 1.0     # 按住不放时别刷日志
F_TASK_NAME = 'FStartCombatTask'


def f_settings(task):
    """读界面上的(开关, F 之后等待秒数)。没装那张卡片就返回默认值(开, 0 秒)。"""
    executor = getattr(task, 'executor', None)
    for group in ('trigger_tasks', 'onetime_tasks'):
        for other in getattr(executor, group, None) or ():
            if type(other).__name__ == F_TASK_NAME:
                try:
                    return bool(other.enabled), float(getattr(other, 'f_start_delay', 0) or 0)
                except Exception:
                    return True, 0.0
    return True, 0.0


# ==================== 自动战斗开关监视 ====================
# 【玩家手动开关自动战斗, 必须从启动轴重跑】。手动停任务不走 combat_end(), opener_armed 会跨局留在
# False, 而角色对象常被粘性复用、reset_state() 不跑。只有独立线程能观察到 enabled 的 True->False->True。
ENABLE_POLL_INTERVAL = 0.2


def start_enable_watch(task, logger=None):
    """盯 task.enabled 的 False->True 跳变, 把时刻记到 task._ww_task_restarted_at。每个 task 只启一次。"""
    if getattr(task, '_ww_enable_watch_started', False):
        return
    task._ww_enable_watch_started = True
    if not hasattr(task, '_ww_task_restarted_at'):
        task._ww_task_restarted_at = -1

    def watch():
        was_on = None
        while True:
            try:
                now_on = bool(getattr(task, 'enabled', False))
                if was_on is False and now_on:
                    task._ww_task_restarted_at = time.time()
                    if logger:
                        logger.info('auto combat re-enabled -> opener re-armed')
                was_on = now_on
                time.sleep(ENABLE_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='ok_ww_enable_watch', daemon=True).start()


def start_f_watch(task, logger=None):
    """把【物理】F 键按下的墙钟时间记到 task._f_last_press。每个 task 只启一次。"""
    if getattr(task, '_f_watch_started', False):
        return
    task._f_watch_started = True
    if not hasattr(task, '_f_last_press'):
        # -1 = 从没按过, 跟 last_opener 的"没跑过"对齐(给 0 的话开局第一次判定恒成立)
        task._f_last_press = -1

    def watch():
        try:
            user32 = ctypes.windll.user32
            user32.GetAsyncKeyState.restype = ctypes.c_short
        except Exception as e:
            task._f_watch_started = False
            if logger:
                logger.error(f'f watch: GetAsyncKeyState unavailable ({e}), '
                             f'the "press F to re-arm the opener" shortcut stays off')
            return
        last_log = 0
        was_down = False
        while True:
            try:
                down = bool(user32.GetAsyncKeyState(F_VK) & 0x8000)
                if down and not was_down and f_settings(task)[0]:
                    now = time.time()
                    # 宏正在跑 = 正在战斗, 这下 F 是玩家手动处决, 不是重开副本
                    if (getattr(task, '_three_fire_macro_busy', False)
                            or getattr(task, '_ww_macro_busy', False)):
                        if logger and now - last_log >= F_LOG_DEBOUNCE:
                            last_log = now
                            logger.info('physical F pressed while the macro is running '
                                        '(manual execution) - opener NOT re-armed')
                        was_down = down
                        time.sleep(F_POLL_INTERVAL)
                        continue
                    task._f_last_press = now
                    task._f_pressed_at = now
                    if logger and now - last_log >= F_LOG_DEBOUNCE:
                        last_log = now
                        logger.info('physical F pressed, opener re-armed')
                was_down = down
                time.sleep(F_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='ok_ww_f_watch', daemon=True).start()


class MacroBroken(Exception):
    """某一步切人没成功 / HUD 长时间不在, 后面的按键会落在错的人身上 —— 整圈放弃, 交回框架。"""


class Cartethyia(NativeCartethyia):
    """卡提希娅。卡夏双人轴(卡提希娅/夏空/釉瑚)里她兼任【整条轴的持宏者】, 三个人的 do_perform 都转到 drive()。

    ================= 轴的出处 =================
    2026-10-27 22:32 用户实机手打一局, 用「跑轴记录」插件 v0.4.7 手打模式录下按键(反馈包
    20261027_223232_手打_Cartethyia__Ciaccona__Youhu_反馈.zip) + N 卡录屏(Wuthering Waves 2026.10.27 - 22.32.34.70.mp4,
    录屏秒 = 记录秒 - 3.70; 录屏把 16:9 画面压进了 2560x1296 加黑边, 读屏要先裁掉黑边拉回 2560x1440)。
    9 次夏空上场, 两种夏空段交替, 一整圈(两次夏空)约 40s、卡提 R1 变身 + R2 各一次。
    【釉瑚只凑人数, 从不上场】(两人队框架不加载自定义代码)。代码【按角色切人】, 编队随意。

    ================= 轴的形状 =================
    一圈从【R2 演完、小卡在场】开始(宏也在这一刻交回框架):
      Y1 小卡   [只有 L1: E 好了就按, 这圈三次下落] 切夏空(见 Y1_E_LOOPS)
      Y2 夏空   (变奏) A 到回路满 3 格 -> E -> 按住重击·四拍重奏 -> 回路清空就松手切卡提
      Y3 小卡   (变奏, 给异权剑) Q -> A 到 A4(神权剑) -> E(人权剑, 地转空) -> 前闪 -> A = 下落吸三把剑
                -> A 到 A4, A4 出手就按住重击(异权剑) -> [E 好了: E -> 闪 -> A] -> R1 变身
      X1 芙     演出里就连按 E -> E1(升空) -> E2 起手就切夏空(芙还在空中)
      X2 夏空   (空中进场) A ~0.75s(第一下是下落) -> E -> Q -> R(演绎) -> 演完连点切卡提
      X3 芙     A ~2.45s -> R(化身卡提希娅, 决意没满) -> 小卡
      X4 小卡   A 到 A4 -> 按住重击 -> E -> 闪 -> A(下落) -> R(化身芙)  [E 没好: 重击 -> 跳 -> A 下落]
                [Y3 重击后没下落(神权剑+异权剑还在): 直接 E -> 闪 -> A 下落吸三把]
      X5 芙     A 到决意满(lib_cartethyia_big) -> R2 -> 演完 = 下一圈的 Y1
    启动轴: 小卡 E -> R1 能放就直接变身接 X1; 能量不够先走 Y3 的身体攒能量。
    手打记录里各格的墙钟见 memory ok-ww-kaxiayou-axis.md。

    ================= 为什么这么打(nanoka + 帧表) =================
    - 小卡 A4 = 神权剑、重击/变奏 = 异权剑、E = 人权剑, 各最多 1 把、存 20s; 空中下落把场上的剑转成剑效果(人权之心/神权之意/异权之力),
      芙在【显化】期间吃这些效果。小卡 E 帧表位置状态「地转空」, 所以 E 后在空中, 接 A 就是下落。
    - R1(能量满, 小卡, 没显化) = 变身芙 + 12s 显化(第154F), 隐藏 HUD 203F; 芙 R 决意<120 = 化身卡提希娅(短, 暂停显化计时),
      小卡 R 显化中 = 化身芙(短, 不吃能量); 芙 R 决意 120 = 看潮怒风哮之刃(R2, 清显化, 演出 ~5s)。化身冷却 1.5s。
    - 夏空 A4 / 变奏各 +1 音律, 3 格时重击换成四拍重奏; 大招进演绎状态, 切走不结束。

    ================= 判据 =================
    - 形态: 原版 is_small()(sword3 半张模板); 决意满: 原版 is_lib_big_available()(lib_cartethyia_big)。
      录屏验过: R2 后小卡读数 +0.14s 翻; 决意满模板亮到按 R2 之间稳定。
    - 剑: 原版 get_sword_buffs()(阈值 0.9), 召唤出的白剑和吸收后的圆圈剑都认成亮; 只拿 sword2(神权剑)当 A4 打出来的信号。
    - 芙 E2 起手: has_cd('resonance') 亮约 0.15s(E1 期间一直不进 CD), 手打录屏 2K/1080 都读得到。
    - 下落吸了剑: 原版 is_mid_air_attack_available()(跳跃键那个小图标) 亮 -> 灭。录屏 Y3 灭在 E 后 1.15s。
      【X4(显化暂停的小卡)整段读不到亮】, 那一格只能计时。
    - 夏空回路满: is_mouse_forte_full()(重击位满图标), 录屏上满 -> 按住 0.72s 清空。
    - 能量: liberation_available() 走 ensure_r。录屏上 R 图标读数会闪(视频色偏), 实机待看。

    ================= 改这个文件之前先读 =================
    - 引擎(macro_* / quick_switch / fire_r / wait_hud_back / ensure_r ...)逐字抄自 skill 自带的心雷穗 v1.0 Hsin.py。
    - 【自定义 __init__ 里跟内置版不同的字段会被打回内置值】, 要保住就在 reset_state() 里重申。
    - 普攻一律走 tap()(按住 A_TAP 秒): task.click() 只按 10ms, 打不出来。
    - 长按期间不调 click()/mouse_down()/send_key() —— 它们先投 WM_ACTIVATE, 会把按住打断。
    """

    # ==================== 全局节奏(引擎用) ====================
    A_INTERVAL = 0.12
    KEY_INTERVAL = 0.10
    A_TAP = 0.06                 # 普攻按住这么久才算一下; task.click() 的 10ms 会被吞

    # ---- 切人 ----
    SWITCH_TIME_OUT = 2.5
    SWITCH_KEY_DOWN_TIME = 0.02
    SWITCH_KEY_INTERVAL = 0.0
    UNTRUSTED_CONFIRM = 3
    TRACE_SWITCH = True

    # ---- 大招 / 演出 ----
    LIB_KEY_INTERVAL = 0.03
    LIB_ANIM_TIME_OUT = 8.0
    HUD_NO_ANIM_GRACE = 0.35
    LIB_GONE_CONFIRM = 3         # HUD 连续这么多帧不在 = 演出真的开始了
    HUD_UP_CAP = 1.0             # 按 R 之前等 HUD 在场的上限(防假成功)
    HUD_BACK_CONFIRM = 2         # 演出中途 HUD 会闪一两帧, 回来要连读这么多帧

    # ---- 杂项 ----
    CON_SAMPLE_MAX = 24
    FIELD_SETTLE_TIME_OUT = 1.5
    E_RESEND_STEP = 0.06
    SKILL_BAR_SETTLE = 0.40      # 刚切进来多久没见过技能亮就当它在 CD 上
    CON_ENOUGH = 1.0
    CON_FULL_CONFIRM = 3
    CON_POLL = 0.03

    # ==================== 防重入 ====================
    OPENER_MIN_GAP = 60.0

    # ==================== 保底 ====================
    SWITCH_RETRIES = 2           # 切人超时后先等 HUD 回来再切, 最多再试这么多次(被击飞/硬直时游戏不放人)
    SWITCH_RETRY_TIME_OUT = 3.00
    HUD_LOST_ABORT = 9.00        # 队伍 HUD 连续这么久没见过 = 关卡结束/过场/窗口没了, 整圈放弃(R2 演出 ~5s)
    DRIVE_HUD_CAP = 1.50         # 框架调进来时 HUD 这么久都不在就什么都不做(结算画面上框架还会一直调进来)
    R_TRIES = 3                  # R 亮着但没放出去(被吞/被打断)就再按, 最多这么多次
    R_BLIND_EVERY = 3            # R 读成暗时每这么多轮攒能量盲按一次(防读数不准)
    R_BLIND_WINDOW = 0.40
    R_BUILD_SLICE = 0.60         # 攒能量每轮的连点时长

    # ==================== 处决 ====================
    # 手打记录里 F 都落在 Y3 小卡 A 打满一套之后(+3.1~5.0s)。只在提示读到时按, 读不到不按; 连段打完再按(见 y3_break)
    BREAK = True
    BREAK_CENTER_MIN = 0.90
    BREAK_PRESSES = 3
    BREAK_ANIM = 1.55            # 帧表 谐度破坏-2 派生帧 91F = 1.52s(无敌期间不能切人)
    BREAK_POLL = 0.30

    # ==================== 卡提希娅 ====================
    CT_E_CAP = 0.50              # Y1/启动轴: E 按到进 CD 的上限
    CT_E_READY_GRACE = 0.15      # 下落用的 E: 这么久没读到亮 = 在 CD 上, 不按
    CT_E_PRESSES = 2             # 亮着就连按两下(第一下被收招吞了第二下补上, 放出去后再按被 CD 挡掉)
    CT_E_PRESS_GAP = 0.08
    CT_E_CD_EVIDENCE = 1.30      # E 按下后这么久之内要读到进 CD。实机 X4: 按下 0.6~0.9s 才出冷却数字, 0.5s 时还读成可用
    HUD_SETTLE = 0.20            # 演出刚回 HUD 时技能栏渐显, 读到的"可用"是假的(Y1 读成 E_ok, 截图里 E 还有 6.5s)
    CT_E_TO_DODGE = 0.60         # E -> 前闪。手打 0.53~0.74(E 是地转空, 人权剑 43F 是脱手子弹, 闪掉不丢剑)
    CT_DODGE_HOLD = 0.07
    CT_DODGE_TO_A = 0.15         # 闪 -> 开始点 A(空中第一下 A 就是下落)。手打 0.15~0.20
    CT_JUMP_TO_A = 0.10          # 没 E 时跳 -> 点 A 下落(L1 那圈: 跳两下 + A, 跳 -> R 0.90s)
    CT_HEAVY_HOLD = 0.78         # 小卡重击按住时长。手打 0.72~0.81; 异权剑 56F = 0.93s 是脱手子弹
    # 【A4 一出手就按住重击】(预输入): 重击会直接打断 A4, 神权剑跟着 A4-2 在 A4-1(11F)脱手后自己出, 打断了也有。
    # 手打录屏启动轴 X4: 神权剑亮 -0.75s = A4 起手 16.55, 按住 16.58, 异权剑(重击 56F)17.99 -> 重击起手 = A4 +0.51;
    # 10-28 15:42 DVR 我们按在 A4 +0.29, 重击 A4 +0.58。按早了(A4 还没起手)这一下会变成重击把 A4 顶掉, 所以按在估的 A4 起手上
    CT_PRE_HOLD_QUIET = 0.10     # 按住之前这么久不再点 A(手打最后一下 A -> 按住 0.16s; 点在 A4 里的 A 会排成下一套 A1)
    # 重击按下 -> 连按 E(中间点着 A)。重击派生帧 60F, 10-28 实机重击按下 0.85s 就按 E, 两下都被吞(X4 每圈 E 不进 CD);
    # 预输入后重击起手 ≈ 按下 +0.45, 三下 E 盖住 起手 +0.95~1.2; 手打 E 在重击按下后 1.19~1.61s
    CT_HEAVY_PRESS_TO_E = 1.40
    CT_E_HEAVY_PRESSES = 3       # 重击后的 E 连按三下盖住派生帧前后(手打 x3~x4)
    CT_E_HEAVY_GAP = 0.12
    # E 在 CD: 重击 -> 跳 -> A 下落。重击聚怪 29F 脱手后爆发/异权剑自己出, 跳可以打断重击。
    # 手打跳在重击按下后 1.09/1.26(重击起手 +0.61, 下落吸剑时异权剑刚出); 10-28 实机等收招 A 0.52s + 读 E 0.15s, 按下后 1.55s 才跳
    CT_HEAVY_TO_JUMP = 1.12
    CT_HEAVY_JUMPS = 2           # 连跳两下(手打 x2): 第一下落在重击里被吞了第二下补上
    CT_JUMP_GAP = 0.12
    CT_R_CONFIRM = 0.60          # 化身(R)后读形态翻过来的窗口
    CT_R_RETRY_GAP = 0.45        # 化身没翻 -> 隔这么久补按(化身冷却 1.5s, 第一下被吞才补)
    CT_R_TRIES = 3
    CT_R1_ANIM_MIN = 2.80        # R1 变身隐藏 HUD 203F = 3.38s, 中途别认"回来"
    CT_R2_ANIM_MIN = 3.80        # R2 演出 HUD 不在 ~5.0s(手打 4.9~5.1)

    # ---- Y1: R2 演完的小卡 ----
    Y1_E_CAP = 0.45              # E 没好就不按(那一下 E 留给 Y3 的下落)
    # Y1 只在前这么多圈按 E(手打下落次数 启动轴1 / L1 3 / L2~ 2 = 13222): 按了 Y3 的 E 就在 CD 上, 走跳下落 + 重击后
    # E 又好了再下落一次, 一圈三次下落。第二圈起【不管 E 好没好都不按】: 10-28 v0.1.10 实机 X4 变快、L1 X4 的 E 差 1.2s
    # 没好只能跳, E 留到 L2 Y1 又好了, 之后每圈都按 L1 打。0 = 一直不按(v0.1.8 实机 5R 9 下落, 备份 5R9下落)
    # Y3 重击后的「前E」下落也只在这几圈打(见 seg_ct_build)
    Y1_E_LOOPS = 1
    # ---- Y3: 小卡(夏空变奏进来) ----
    Y3_Q_WINDOW = 0.15           # 到场就按 Q, 两下(声骸不受变奏锁挡; 手打 +0.07/+0.21)
    Y3_A_TO_E = 3.10             # 到场 -> E。变奏 69F + A2 46F + A3 60F ≈ 2.92s 起 A4, A4-1 11F 脱手后神权剑自己出
    Y3_SWORD2_EARLY = True       # 神权剑提前亮了就提前按 E(被打断重开连段时会更晚, 照计时)
    # E 在 CD 走跳下落时, 跳之前要等神权剑(中间那把)亮: 它跟着 A4-2 在 A4 起手后 45F 才生成,
    # 10-28 实机/手打都在到场 3.62~3.72s 亮; 3.3s 就跳的话下落只吸到两把(每圈都少中间那把)
    Y3_SWORD2_CAP = 4.60         # 到场这么久还没亮就照跳
    Y3_SWORD2_MORE = 0.60        # A 到 A4 拖长了、已经过了上限时, 至少再等这么久
    # 处决不打断连段: A 到 A4、等神权剑、下落后那段 A 里看到提示只记下来, 这一套打完再按 F。
    # 按 F 连段就从 A1 重来(A1 17F + A2 46F + A3 60F = 2.05s 才起 A4): v0.1.5 处决完再打 2.40s 到 A4 才 E,
    # 10-28 14:52 实机 L2/L3 到场 2.6~3.7s 出提示, 每次多花 2.4s; 手打记录的 F 也都在 A 打满 3.1~3.2s 之后
    Y3_PLUNGE_TO_BREAK = 0.60    # E 下落读到吸剑 -> F(下落 32F 第 9F 吸剑 + 落地派生 18F, 早按会把落地那下打掉)
    Y3_PLUNGE_CAP = 1.60         # E 后这么久还没读到下落吸剑(跳跃图标灭)就当吸了
    PLUNGE_GONE_CONFIRM = 3      # 跳跃图标连灭这么多次才算吸了(录屏: 变奏入场里单闪灭过 0.2s)
    # 下落 -> 按住重击: 中间打一套 A1~A4(补神权剑 + 攒能量), 按在估的 A4 起手上(见 CT_PRE_HOLD_QUIET)。
    # 连段 A1 -> A4 起手: 帧表 17+46+60F = 2.05s, 加上点按延迟 ~2.2s; 下落 32F + 落地派生 18F 之后才起 A1
    Y3_E_TO_HEAVY = 4.05         # 从 E 按下算: E 后 1.0s 起下落(录屏 1.15s 吸剑) + 0.83 落地 + 2.2。旧版下落读到后再 A 2.90 = E 后 4.3
    Y3_JUMP_TO_HEAVY = 3.15      # 从跳算(手打 L1 跳 -> 按住 3.18, 那下按在 A4 出手上)。旧版 3.8
    Y3_BREAK_TO_HEAVY = 2.30     # 处决完(do_break 返回)算, 连段从 A1 重来(手打 L2 处决动画完 -> 按住 2.38)。旧版 2.90
    Y3_A4_TO_BREAK = 0.25        # 重击前要处决: 估的 A4 起手后这么久再按 F(A4-1 11F 脱手, 神权剑才保得住), 处决完空手起重击
    # 重击按下 -> R1(手打 1.0~1.15s)。R1 打断重击, 要等聚怪 29F 脱手(预输入后重击起手 ≈ 按下 +0.45, 29F 之后 = +0.93)
    Y3_HEAVY_PRESS_TO_R = 1.05
    # 重击后 E 还好着: E -> 闪 -> A 下落, 落地打完再 R1。E 后 1.15s 才吸剑(下落起手), 加落地派生 18F;
    # 0.90 时 R1 按在闪避后 0.2s, 下落整个没出。手打 E -> R 1.98s
    Y3_PRE_R1_E_A = 1.85
    Y3_R1_WINDOW = 1.00
    Y3_R1_CAP = 8.00             # 能量不够就边 A 边等的上限
    OP_E_TO_R = 0.40             # 启动轴 E -> R1(手打 0.40, R 按在 E 的空中动作里)
    # 启动轴第一下离物理 F 至少这么久。按 F 挑战就开始、宝箱 Boss 从地里冒出来; 起手早了芙 E2 下劈前那段飞得更久,
    # 0.25s 切进来的夏空是普通空中(悬空点 A), 芙劈完前后游戏还自己把芙放回了场上(这期间宏只点了 A), 下落和夏空 R 全没了。
    # 10-28 实机: 物理 F -> 起手 0.30~0.34s(插件设 0.1/0.2)的 8 局全挂, 0.415/0.436s(设 0.3)的局全接上
    OP_AFTER_F = 0.43
    OP_AFTER_F_RECENT = 3.0      # 离 F 超过这么久(开关自动战斗进来的)就不等
    # ---- X1: 变身演完的芙 ----
    # 芙 E1 升空, E2 下砸; 切人要落在 E2 刚起手、芙还在空中时, 夏空才是空中进场(第一下 A 是下落, 地面 A 不给回路)
    X1_E_FROM_R = 2.50           # R1 第一下按下 -> 开始连按 E(演出 202F=3.37s 能动)。手打 R 后 2.47/3.05 起按
    X1_E_EVERY = 0.15
    X1_E2_GUARD = 0.40           # HUD 回来这么久之内读到 E 进 CD 不认(E2 最早在 E1 后 55F=0.92s)
    X1_E2_CAP = 1.25             # HUD 回来这么久没读到 E2 也切(手打 HUD 回来 -> 切夏空 1.01/1.07)
    # 读到 E2(E 进 CD) -> 切夏空。要切在芙往下劈的时候: 夏空的空中出场技就是空中A2-下落, 芙还在 E2 顶点时切进来
    # 是普通空中状态, 点 A 出的是悬空 0.5s 的空中 A1, 接着 E 把下落打断(10-28 实机 0.09s 就切, 夏空飘着打)。
    # 手打录屏: 进 CD 后 0.11s 按切人, 夏空 +0.23s 到场时芙已经在往下劈, 只比我们晚几十毫秒; E2 下劈 37F、40F 落地
    X1_E2_TO_SWITCH = 0.25
    X1_E_QUIET = 0.15            # 到点硬切前这么久不再按 E(切人期间的键会落到夏空身上)
    # 启动轴: 读到 E2 起手先点一下 A 再切夏空。开局夏空下落偶尔接不上, 用户实机确认是丢了锁定(芙劈完夏空进场没目标);
    # 点 A 让芙对着怪。只在启动轴(循环里没出过这事), 不改切人时刻(X1_E2_TO_SWITCH 从读到 E2 算)
    OP_X1_A_TAP = True
    # 切夏空之前把怪锁上(启动轴和循环都要, 夏空空中进场的下落要有目标): HUD 回来到 E2 起手这 ~1.2s 里每隔 X1_LOCK_GAP
    # 看一次锁定标记, 没锁就点中键。已经锁着不点(再点会解锁)。10-28 v0.1.12 实机光点 A 还是不稳, 用户手动按中键就稳了
    X1_LOCK = True
    X1_LOCK_GAP = 0.35           # 点完中键标记要一会儿才变, 隔这么久再看
    X1_LOCK_TRIES = 3
    # ---- X3: 芙(夏空大招演完切进来) ----
    X3_A = 2.45                  # 到场 -> R 化身卡提希娅。手打 2.44~2.79; 【不能放大】: 决意到 120 这下 R 就成了 R2
    X3_LIB_POLL = 0.25
    # 宏不读锁怪, 按 F 开打之后一直没锁上: F 开始战斗的保护期(10s)一过, 启动轴交回框架那一下框架要补锁 ~0.95s
    # (10-28 实机 R2 后愣住)。X3 点 A 的时候顺手看一眼, 没锁就点中键
    X3_LOCK_TRIES = 2
    X3_LOCK_GAP = 0.40
    # ---- X4: 小卡(显化暂停) ----
    # R -> 按住重击 = A4 起手 +0.06。10-28 15:42 DVR 启动轴 X4: 神权剑亮在 R 后 2.79s -> A4 起手 R +2.04
    # (手打 2.30, 点得慢); 旧版 2.25
    X4_A = 2.10
    # Y3 重击后没再下落(E 在 CD 直接 R1)时, 那套 A4 的神权剑和重击的异权剑还在场上(存 20s):
    # X4 不打 A4/重击, 化身过来直接 E -> 闪 -> A 下落吸三把。10-28 实机 X4 开头 E 都是好的
    X4_SKIP_BUILD = True
    # 重击松手时 E 还差这么多秒以内(get_cd 读冷却数字): 边点 A 边等它好再 E 下落(手打 L1 X4 E 在重击按下 +1.61)。
    # 【L1 X4 这一下 E 是时间节点】: 用掉了, L2 起 Y3 的 E 好、Y3 重击后 E 没好、X4 的 E 又好, 后面每圈都是两次下落;
    # 10-28 v0.1.10 L1 X4 松手时 E 还差 1.2s, 直接跳了, 之后每圈都三次下落。启动轴 X4 差 5.6s, 照跳
    X4_E_WAIT = 2.50
    Y3_E_WAIT = 1.00             # Y3 A 到 A4 后 E 差这么多以内也等(L2 起 Y3 的 E 离上一圈 X4 的 E 只有 ~16s, 正好卡在冷却边上)
    X4_E_TO_R = 1.80             # E -> R 化身芙。手打 1.72~1.84
    # 没 E 走跳: 跳 -> R。下落 32F + 落地派生 18F 打完再化身; 10-28 实机跳后 0.96s 就按 R,
    # 画面上刚落地、伤害数字还没出来就化身芙了(落地 ~0.9s)
    X4_JUMP_TO_R = 1.30
    # ---- X5: 芙 ----
    X5_LIB_CAP = 8.00            # A 到决意满的上限(手打 3.38~6.10)。显化 12s, 读到变回小卡就不等了
    X5_SMALL_CONFIRM = 3         # 连读这么多次小卡 = 显化结束变回来了
    X5_R2_WINDOW = 1.50

    # ==================== 夏空 ====================
    CI_ARRIVE_A = 0.75           # X2 到场 -> E。手打 0.77~0.88(L7 1.24)
    # X2 下落落地才按 E。芙离 Boss 高(10-28 F 之后等 0.1s 的局, 宝箱还在往上冒)时 E2 劈得晚, 夏空 0.35s 进场还是普通空中:
    # A 出的是悬空的空中A1(30F 后才接得上 A2-下落), 0.75s 的 E(优先级 7)把下落打断, 下一次 Y2 回路卡 2 格、R 也攒不满。
    # 落地信号 = 回路比到场时涨一截(落地打击给的): 13:55 DVR 接上的局到场 0.75s 起连续 0.70~1.09,
    # 没接上的三局一直 <0.30, 只有芙落地光柱闪出过单帧 0.88(所以要连读)
    CI_X2_LAND_RISE = 0.50
    CI_X2_LAND_CONFIRM = 2
    CI_X2_AIR_A = 1.00           # 没落地: 接着点 A 到到场这么久(保证悬空的 A1 接上 A2-下落)
    CI_X2_LAND_CAP = 2.00        # 之后不按键等落地, 到场这么久还没读到就照按 E
    # 关掉: 10-28 14:52 实机落地都在到场 1.02~1.07s 才读到, 比 0.75 晚 0.3s、一局 5 次; 0.1/0.2 开局没接上下落的
    # 真正原因是起手离 F 太近(见 OP_AFTER_F), 那几局等到 2.00s 也没落地。判据留着
    CI_X2_WAIT_LAND = False
    CI_E_TO_Q = 0.07
    CI_Q_HOLD = 0.12
    CI_R_WINDOW = 1.50
    CI_R_CAP = 3.00              # 能量不够就边 A 边等的上限, 超了不放(不按也能接着打)
    CI_R_ANIM_MIN = 2.60         # 夏空大招 HUD 不在 ~3.4s
    CI_R_ANIM_CAP = 6.00
    CI_FULL_CAP = 2.60           # Y2 A 到回路满的上限(手打 +1.55~1.75 满)
    CI_FULL_CONFIRM = 2
    CI_E_TO_HOLD = 0.15          # E -> 按住重击(手打 0.11~0.17)
    CI_HOLD_CAP = 1.30           # 按住到回路清空的上限(录屏 0.72s 清空; 手打按 0.79~1.06)
    CI_CLEAR_CONFIRM = 2
    CI_RETRY_FILL = 1.20         # 没满: E 之后再 A 这么久等满
    CI_INTRO_READ = 0.60         # Y2 到场这么久读回路: 变奏 +1 格(手打 X2 后 1.0 -> 进场 2.0)
    CI_NO_INTRO_LEVEL = 1.60     # 读到不到这么多 = 没吃到变奏, A 到满的上限放宽
    CI_FULL_CAP_NO_INTRO = 4.50
    # Y2 -> Y3 切卡提之前夏空协奏必须真满, 卡提才有变奏(异权剑 + 协奏 10 + 能量)。
    # 10-28 实机 L1 四拍重奏清空就切, 协奏只读到 0.852(强化重击 25 点还没结算), 卡提没变奏;
    # 剩下的协奏带进 X2, 变成 X2 -> X3 满了给芙变奏, 下一圈 Y2 从低位起又不满, 整圈错位
    CI_CON_CAP = 2.50            # 等协奏满(边点 A)的上限
    CI_CON_CONFIRM = 2
    CT_INTRO_SWORD_CAP = 1.50    # Y3 到场这么久之内读到异权剑 = 吃到了变奏(只记日志)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.opener_armed = True
        self.last_opener = -1
        self.macro_t0 = 0.0
        self.macro_marks = []
        self.cur = None
        self.holding_attack = False
        self.switch_press_at = 0.0
        self.lib_press_at = 0.0
        self.loop_count = 0
        self.hud_seen_at = 0.0         # 最后一次读到队伍 HUD 在场的时刻(HUD_LOST_ABORT 用)
        self.hud_watch = False         # 宏跑着的时候才查 HUD 丢没丢
        self.drive_log_at = 0.0
        self.timeline_logged = True
        self.breaks = 0
        self.break_seen_at = None      # 小卡连段里看到处决提示的时刻(连段打完 y3_break 再按)
        self.form_pressed_at = 0.0
        self.ct_e_at = 0.0             # 最近一次小卡 E 按下的时刻(ct_fire_e)
        self.ct_e_skipped = False      # 最近一次 ct_e_plunge 是 E 在 CD 一下没按(不是按了被吞)
        self.ct_swords_left = False    # Y3 末尾的神权剑+异权剑还在场上没被下落吸掉(X4 直接 E 下落)
        self.ci_level_left = -1.0      # X2 夏空走时的回路格数, Y2 拿来比变奏有没有 +1(-1 = 没读到)
        # reset_state() 只在 load_chars() 时跑, 而角色对象会被粘性复用 —— 这里也要启一次
        try:
            start_enable_watch(self.task, self.logger)
        except Exception:
            pass

    def reset_state(self):
        super().reset_state()
        self.opener_armed = True
        self.ci_level_left = -1.0
        # 内置非治疗角色默认 True, 换类时会被打回, 所以在这里重申(这条轴自己按处决)
        self.check_f_on_switch = False
        start_f_watch(self.task, self.logger)
        start_enable_watch(self.task, self.logger)

    # ==================== 队伍判定 ====================

    @property
    def is_in_kxy(self) -> bool:
        """本队 = 卡提希娅 + 夏空 + 釉瑚。按类名判。"""
        members = 0
        for char in self.task.chars:
            if char and char.name in {'Ciaccona', 'Youhu'}:
                members += 1
        return members == 2

    def teammate(self, name):
        for char in self.task.chars:
            if char is not None and char.name == name:
                return char
        return None

    def opener_pending(self):
        return self.opener_blocked_by() is None

    def opener_blocked_by(self):
        """启动轴不跑的原因; 返回 None 表示该跑。不查任何技能可用性(场下读数是旧的)。"""
        if not self.is_in_kxy:
            return 'team is not cartethyia/ciaccona/youhu'
        # 刚开关过自动战斗: 不管 armed 真假都放行, 直到启动轴真跑了改掉 last_opener
        # (选人时三个人的 get_switch_priority 都会调进来, 只放行一次会撞上 OPENER_MIN_GAP)
        restarted = getattr(self.task, '_ww_task_restarted_at', -1)
        if restarted > self.last_opener:
            if not self.opener_armed:
                self.logger.info('auto combat 重开过 — 启动轴重新武装, 从头跑')
                self.opener_armed = True
            return None
        if not self.opener_armed:
            return 'already armed-down (ran once this combat)'
        f_press = getattr(self.task, '_f_last_press', -1)
        if f_press > self.last_opener:
            waited = time.time() - f_press
            delay = f_settings(self.task)[1]
            if waited < delay:
                return f'F pressed {waited:.2f}s ago, waiting {delay:.2f}s for the mobs'
            return None
        if self.last_opener >= 0 and time.time() - self.last_opener < self.OPENER_MIN_GAP:
            return f'ran {time.time() - self.last_opener:.1f}s ago (< {self.OPENER_MIN_GAP:.0f}s)'
        if not self.task.use_liberation:
            return 'task.use_liberation is off'
        return None

    # ==================== 宏原语(引擎) ====================

    def macro_wait(self, sec):
        """精确等待, 【不点击】。切成 0.1 秒一片, 片间检查任务是否被停用。"""
        if sec <= 0:
            self.task.executor.check_enabled(check_pause=False)
            return
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)

    def wait_until_time(self, deadline):
        self.macro_wait(deadline - time.time())

    def macro_start(self):
        self.macro_t0 = time.time()
        self.macro_marks = []

    def macro_mark(self, name):
        self.macro_marks.append(f'{name}@{time.time() - self.macro_t0:.2f}')
        # 【看门狗】每一步都会打标记, 在这里顺手查: HUD 很久没出现 = 关卡结束/过场/窗口没了,
        # 再按下去就是在结算画面上乱按。不读屏, 只比时间戳
        if self.hud_watch and time.time() - self.hud_seen_at > self.HUD_LOST_ABORT:
            self.hud_watch = False
            raise MacroBroken(f'队伍 HUD {time.time() - self.hud_seen_at:.1f}s 没出现(关卡结束/过场/窗口没了?)')

    def hud_ok(self):
        """队伍 HUD 在不在(读当前帧)。见到就记下时刻, 给看门狗用。"""
        ok = bool(self.task.in_team()[0])
        if ok:
            self.hud_seen_at = time.time()
        return ok

    def macro_timeline(self, since=0):
        return ' '.join(self.macro_marks[since:])

    def macro_spam(self, window, interval=None, tag='A'):
        """连点一个窗口。打出几段由 window 决定(动画期间的点击被丢掉, 连点保证总有一下落在动画刚结束时)。"""
        interval = self.A_INTERVAL if interval is None else interval
        start = time.time()
        n = 0
        cap = int(window / max(interval, 0.01)) + 2
        while time.time() - start < window and n < cap:
            self.click()
            n += 1
            remaining = window - (time.time() - start)
            if remaining <= 0:
                break
            # click 自己按住 A_TAP 秒, 不扣的话连点周期从 interval 变成 interval + A_TAP
            self.macro_wait(min(max(0.0, interval - self.A_TAP), remaining))
        self.macro_mark(f'{tag}(x{n})')
        return n

    def spam_key(self, send, window, interval=None, tag='key', poke=None, presses=None,
                 click_interval=None, stop_when=None):
        """在一个窗口里反复发同一个技能键, 用来盖住动画那一段(动画期间的按键被丢掉、不排队)。

        【必须在这个角色自己的回合里跑完, 不要跟切人并行】: 切人期间发出去的键会被游戏带过换人边界落在新角色身上。
        poke: 发键期间要不要照常点普攻; stop_when: 每发一次键之后调一次, 返回 True 就停;
        presses: 只发这么多次, 均匀铺在窗口里。
        """
        interval = self.KEY_INTERVAL if interval is None else interval
        poke = bool(poke)
        click_interval = self.A_INTERVAL if click_interval is None else click_interval
        if presses is not None and presses > 0:
            interval = max(interval, window / presses)
        start = time.time()
        n = 0
        clicks = 0
        next_click = 0.0
        while True:
            send()
            n += 1
            if stop_when is not None and stop_when():
                break
            if presses is not None:
                if n >= presses:
                    break
                left = interval
            else:
                left = window - (time.time() - start)
                if left <= 0:
                    break
            step_end = time.time() + min(interval, left)
            # 发键的节奏和点击的节奏各走各的
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + click_interval
                self.macro_wait(min(0.02, step_end - time.time()))
        self.macro_mark(f'{tag}(x{n},A x{clicks})')
        return n

    def attack_down(self):
        self.task.mouse_down()
        self.holding_attack = True

    def release_attack(self):
        if self.holding_attack:
            self.task.mouse_up()
            self.holding_attack = False

    def tap(self, hold=None):
        """点一下普攻, 【真的按住 hold 秒】。"""
        hold = self.A_TAP if hold is None else hold
        self.task.mouse_down()
        self.holding_attack = True
        try:
            self.macro_wait(hold)
        finally:
            self.task.mouse_up()
            self.holding_attack = False

    def click(self, *args, **kwargs):
        """本队里所有的 self.click() 都改成按住 A_TAP(BaseChar.click 强制 10ms, 等于没点)。不在本队走原版。"""
        if not self.is_in_kxy:
            return super().click(*args, **kwargs)
        self.tap()

    def quick_switch(self, target, click_during=False, time_out=None, read_con=False, assume_con=False):
        """按数字键直切给指定角色(不走 switch_next_char 选人)。

        read_con: 按键之后读一次协奏决定按不按"带变奏"记账; assume_con: 不读屏直接按满协奏记。
        Returns: 是否真的切过去了。
        """
        if target is None:
            return False
        if target is self.cur:
            self.macro_mark(f'>{target.name[:3]}(already)')
            return True
        entry = time.time()
        time_out = self.SWITCH_TIME_OUT if time_out is None else time_out
        source = self.cur if self.cur is not None else self
        slot = target.index + 1
        self.switch_press_at = time.time()
        self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
        if assume_con:
            con_full = True
        elif read_con:
            # 不用 char.is_con_full(): 那层读到过一次满就一直缓存成满
            try:
                con_full = float(self.task.get_current_con()) >= 1.0
            except Exception:
                con_full = False
        else:
            con_full = False
        con_cost = time.time() - entry

        start = time.time()
        last = start
        next_click = 0.0
        trace = [] if self.TRACE_SWITCH else None
        team_size = len([c for c in self.task.chars if c is not None])
        untrusted_hits = 0
        clicks = 0
        while time.time() - start < time_out:
            now = time.time()
            if now - last >= self.SWITCH_KEY_INTERVAL:
                self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
                last = now
            if click_during and now >= next_click:
                self.click()
                clicks += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            hit = in_team and index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if trace is not None:
                trace.append(f'{time.time() - start:.2f}:'
                             f'{(index if trusted else f"?{index}") if in_team else "x"}')
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                self.handoff(source, target, con_full)
                self.macro_mark(f'>{target.name[:3]}{"^" if con_full else ""}'
                                f'({time.time() - entry:.2f}|con{con_cost:.2f}|A x{clicks})')
                if trace and time.time() - entry > 0.4:
                    self.logger.info(f'slow switch trace -> {target.name}: {" ".join(trace)}')
                return True
        # 一直是旧角色的 index = 游戏在拒绝切人; 带 ? 的都是目标 = count 判据挡住了; 全是 x = HUD 不在
        self.logger.warning(f'switch to {target.name} slot {slot} timed out '
                            f'after {time_out:.1f}s (stuck in an animation?)'
                            + (f' trace: {" ".join(trace)}' if trace else ''))
        self.macro_mark(f'>{target.name[:3]}FAIL')
        return False

    def handoff(self, from_char, to_char, con_full):
        """复刻 switch_next_char() 尾部那套交接记账。不补的话 get_current_char() 返回 None, 主循环当场崩。"""
        self.task.in_liberation = False
        from_char.switch_out(con_full=con_full)
        to_char.is_current_char = True
        to_char.has_intro = con_full
        to_char.has_sub_dps_intro = con_full and from_char.is_sub_dps
        to_char.last_switch_in_time = time.time()
        if con_full:
            now = time.time()
            self.task.add_freeze_duration(now, to_char.intro_motion_freeze_duration, -100)
            from_char.last_outro_time = now
        self.cur = to_char

    def switch_retry(self, target, tag, **kw):
        """quick_switch, 超时了先等 HUD 回来再切, 最多再试 SWITCH_RETRIES 次。只花时间。"""
        if self.quick_switch(target, **kw):
            return True
        for i in range(self.SWITCH_RETRIES):
            self.wait_hud_up(cap=2.0, tag=f'{tag}重切前HUD')
            self.macro_mark(f'{tag}切{target.name[:3]}重试#{i + 1}')
            kw2 = dict(kw)
            kw2['time_out'] = self.SWITCH_RETRY_TIME_OUT
            if self.quick_switch(target, **kw2):
                return True
        return False

    def wait_hud_back(self, tag='anim', time_out=None, min_gone=0.0, tail=0.0):
        """等演出结束(队伍 HUD 回来), 【期间一下都不点】。先确认消失过。

        min_gone: 从第一次读到消失起, 这么久之内读到的"回来"不认(演出中途 HUD 会闪一两帧)。
        回来要连读 HUD_BACK_CONFIRM 帧。
        """
        time_out = self.LIB_ANIM_TIME_OUT if time_out is None else time_out
        start = time.time()
        gone_at = None
        back_hits = 0
        back = False
        while time.time() - start < time_out:
            self.task.next_frame()
            if not self.hud_ok():
                if gone_at is None:
                    gone_at = time.time()
                back_hits = 0
            elif gone_at is not None:
                if time.time() - gone_at >= min_gone:
                    back_hits += 1
                    if back_hits >= self.HUD_BACK_CONFIRM:
                        back = True
                        break
            elif time.time() - start >= self.HUD_NO_ANIM_GRACE:
                back = True
                break
            self.macro_wait(0.01)
        if gone_at is not None:
            self.add_freeze_duration(gone_at, time.time() - gone_at)
        self.macro_mark(f'{tag}({"ok" if back else "timeout"},'
                        f'{"anim" if gone_at is not None else "NOANIM"},{time.time() - start:.2f}s)')
        self.macro_wait(tail)
        return back

    def wait_hud_up(self, cap=None, tag='HUD'):
        """等队伍 HUD 【现在】在场。按 R 之前用 —— HUD 本来就不在的时候判"演出开始了"是假成功。"""
        cap = self.HUD_UP_CAP if cap is None else cap
        start = time.time()
        while time.time() - start < cap:
            self.task.next_frame()
            if self.hud_ok():
                if time.time() - start > 0.05:
                    self.macro_mark(f'{tag}在场({time.time() - start:.2f}s)')
                return True
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}一直不在({cap:.1f}s)')
        return False

    def on_field_char(self, time_out=None):
        """现在场上是谁 —— 只在拿不到入口角色时才用(开局 HUD 渐入时 in_team() 会说谎, 要 count 达标)。"""
        time_out = self.FIELD_SETTLE_TIME_OUT if time_out is None else time_out
        expected = len([c for c in self.task.chars if c is not None])
        end = time.time() + time_out
        while True:
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            if in_team and count >= expected:
                for char in self.task.chars:
                    if char is not None and char.index == index:
                        return char
                return None
            if time.time() >= end:
                self.logger.warning(f'team HUD never settled in {time_out:.1f}s '
                                    f'(in_team={in_team} index={index} count={count} '
                                    f'expected={expected}), cannot tell who is on field')
                return None
            self.macro_wait(0.03)

    def mark_busy(self, busy):
        """F 键监视线程靠它区分"战斗中手动处决"和"重开副本"。"""
        self.task._ww_macro_busy = busy
        self.task._three_fire_macro_busy = busy

    def need(self, ok, what):
        if not ok:
            raise MacroBroken(what)

    def press_key_until_cd(self, send, available, cap, tag, ready_grace=0.15, poke=False):
        """一直按某个技能键到它进 CD。返回放出去了没有(本来就在 CD 上返回 False)。

        【先见过"亮"才认"暗"】: 刚切人那几帧技能栏还是上一个人的, 读到的是上一个人的 CD。
        """
        start = time.time()
        n = live = clicks = 0
        seen_ready = False
        next_click = 0.0
        while time.time() - start < cap:
            self.task.next_frame()
            hud = bool(self.hud_ok())
            if hud:
                if available():
                    seen_ready = True
                elif seen_ready and live > 0:
                    self.macro_mark(f'{tag}_ok(x{n},A x{clicks},{time.time() - start:.2f}s)')
                    return True
                elif not seen_ready and time.time() - start >= ready_grace:
                    self.macro_mark(f'{tag}_没见过亮(x{n},{time.time() - start:.2f}s)')
                    return False
            send()
            n += 1
            if hud:
                live += 1
            step_end = time.time() + self.E_RESEND_STEP
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + self.A_INTERVAL
                self.macro_wait(min(0.02, step_end - now))
        self.macro_mark(f'{tag}_CD?(x{n},seen{int(seen_ready)},{cap:.1f}s)')
        self.logger.info(f'{tag}: never read as on-cooldown after {n} presses (seen ready={seen_ready})')
        return False

    def fire_r(self, char, tag, window):
        """发大招到队伍 HUD【连续】消失 LIB_GONE_CONFIRM 帧。返回放出去没有。

        发键之前先等 HUD 在场(HUD 本来就不在会假成功)。确认期间继续按 R 没有副作用 —— 演出里的按键被丢掉。
        """
        self.wait_hud_up(tag=f'{tag}前HUD')
        start = time.time()
        self.lib_press_at = start
        n = gone = 0
        fired = False
        while time.time() - start < window:
            char.send_liberation_key()
            n += 1
            self.task.next_frame()
            if not self.hud_ok():
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    fired = True
                    break
            else:
                gone = 0
            self.macro_wait(self.LIB_KEY_INTERVAL)
        self.task.skip_combat_check = True
        if fired:
            char.record_liberation_use()
            self.macro_mark(f'{tag}_fired(x{n},{time.time() - start:.2f}s)')
            return True
        self.macro_mark(f'{tag}_NOFIRE(x{n})')
        try:
            lit = bool(char.liberation_available())
        except Exception:
            lit = 'err'
        # lit=True: 键被上一个动作吞了; lit=False: 能量不够
        self.logger.warning(f'{tag}: {char.name} liberation never started an animation '
                            f'after {n} presses (icon lit={lit})')
        return False

    def lib_ready_reads(self, char, frames):
        """HUD 在场时连续 frames 帧读到 char 的 R 可用。HUD 不在的帧不算, 最多读 frames*3 帧。"""
        hits = 0
        for _ in range(frames * 3):
            self.task.next_frame()
            if self.hud_ok():
                try:
                    ready = bool(char.liberation_available())
                except Exception:
                    ready = False
                if not ready:
                    return False
                hits += 1
                if hits >= frames:
                    return True
            self.macro_wait(0.02)
        return False

    def ensure_r(self, char, tag, window, cap, build):
        """R 一定要放出来。读 R 亮 -> 按; 亮着却没放出去就再按, 最多 R_TRIES 次;
        不亮 -> build(轮次) 攒一小段再读, 每 R_BLIND_EVERY 轮盲按一次防读数不准。上限 cap 只防打不到怪。
        """
        start = time.time()
        tries = rounds = 0
        while time.time() - start < cap:
            if self.lib_ready_reads(char, 2):
                tries += 1
                if self.fire_r(char, f'{tag}R' if tries == 1 else f'{tag}R重按#{tries - 1}', window):
                    if rounds:
                        self.logger.info(f'{tag}: {char.name} R 攒了 {time.time() - start:.1f}s 能量才放出去')
                    return True
                if tries >= self.R_TRIES:
                    break
                continue
            rounds += 1
            if rounds == 1:
                self.macro_mark(f'{tag}R没亮(攒能量)')
            build(rounds)
            if rounds % self.R_BLIND_EVERY == 0 and not self.lib_ready_reads(char, 2) and \
                    self.fire_r(char, f'{tag}R盲按#{rounds}', self.R_BLIND_WINDOW):
                return True
        self.logger.warning(f'{tag}: {char.name} 的 R 保底 {time.time() - start:.1f}s 还是没放出去 '
                            f'(亮了按 {tries} 次, 攒能量 {rounds} 轮), 不放了')
        return False

    def dodge(self, tag, forward=True):
        """闪避(右键)。forward: 按住 W 闪(手打每次都是 W + 闪)。"""
        if forward:
            self.task.send_key_down('w')
        try:
            self.task.mouse_down(key='right')
            try:
                self.macro_wait(self.CT_DODGE_HOLD)
            finally:
                self.task.mouse_up(key='right')
        finally:
            if forward:
                self.task.send_key_up('w')
        self.macro_mark(f'{tag}闪')

    def break_prompt(self):
        """怪身上有处决提示(屏幕中间那个 F, 排除拾取 F)。读当前帧。"""
        task = self.task
        try:
            hit = task.find_one('f_break', box=task.box_of_screen(0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True),
                                target_height=720, threshold=self.BREAK_CENTER_MIN)
            return bool(hit) and not task.is_pick_f()
        except Exception as e:
            self.logger.info(f'处决提示读失败 {e}')
            return False

    def do_break(self, tag):
        """只按 F(最多 BREAK_PRESSES 下, 提示没了就停), 从第一下起等满 BREAK_ANIM。返回花了多久。
        不走框架的 task.f_break(): 那个会连点左键、至少卡 0.5s。"""
        start = time.time()
        presses = 0
        while presses < self.BREAK_PRESSES:
            self.task.send_key('f', down_time=0.05)
            presses += 1
            self.macro_wait(0.10)
            self.task.next_frame()
            if not self.break_prompt():
                break
        try:
            self.task.can_break = False
        except Exception:
            pass
        self.macro_wait(max(0.0, start + self.BREAK_ANIM - time.time()))
        self.breaks += 1
        self.macro_mark(f'{tag}处决(F x{presses},{time.time() - start:.2f}s)')
        return time.time() - start

    def a_until(self, deadline, tag, stop=None, poll=0.20, watch_break=False):
        """连点普攻到 deadline。stop(): 每 poll 秒读一帧问一次, 成立就提前收手。
        watch_break: 顺手看处决提示, 看到了只记 break_seen_at 不按(连段打完 y3_break 再按, 见 Y3_PLUNGE_TO_BREAK)。
        返回 stop 成立了没有。"""
        n = 0
        next_read = time.time() + poll
        hit = False
        while time.time() < deadline:
            self.click()
            n += 1
            if time.time() >= next_read:
                next_read = time.time() + poll
                self.task.next_frame()
                if self.hud_ok():
                    if stop is not None and stop():
                        hit = True
                        break
                    if watch_break and self.BREAK and self.break_seen_at is None and self.break_prompt():
                        self.break_seen_at = time.time()
                        self.macro_mark(f'{tag}看到处决提示(连段打完再按)')
            self.macro_wait(min(max(0.0, self.A_INTERVAL - self.A_TAP), deadline - time.time()))
        self.macro_mark(f'{tag}(A x{n}{",提前" if hit else ""})')
        return hit

    # ==================== 卡提希娅 ====================

    def ct_small_now(self):
        self.task.next_frame()
        return bool(self.is_small())

    def ct_lib_big(self):
        return bool(self.is_lib_big_available())

    def ct_lib_big_reads(self, frames=2):
        """HUD 在场时连续 frames 帧读到决意满(R2 图标)。"""
        hits = 0
        for _ in range(frames * 3):
            self.task.next_frame()
            if self.hud_ok():
                if not self.ct_lib_big():
                    return False
                hits += 1
                if hits >= frames:
                    return True
            self.macro_wait(0.02)
        return False

    def ct_sword2(self):
        try:
            return bool(self.get_sword_buffs().get('sword2'))
        except Exception:
            return False

    def ct_midair(self):
        """跳跃键上的强化下落小图标亮着(小卡 + 场上有剑之影)。"""
        try:
            self.is_small()
            return bool(self.is_mid_air_attack_available())
        except Exception:
            return False

    def ct_e_ready(self):
        self.task.next_frame()
        if not self.hud_ok():
            return False
        try:
            return bool(self.resonance_available())
        except Exception:
            return False

    def ct_press_e(self, tag, cap=None):
        """按 E 到进 CD。返回放出去没有(本来在 CD 上返回 False)。"""
        cap = self.CT_E_CAP if cap is None else cap
        return self.press_key_until_cd(self.send_resonance_key, self.resonance_available, cap, tag,
                                       ready_grace=0.15)

    def ct_heavy(self, tag, hold=None):
        """按住重击 hold 秒。返回按下的时刻(后面的 E/跳/R 都从这里算)。"""
        hold = self.CT_HEAVY_HOLD if hold is None else hold
        self.attack_down()
        at = time.time()
        try:
            self.macro_wait(hold)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}重击({hold:.2f}s)')
        return at

    def break_pending(self):
        """连段里看到过处决提示, 或者现在就有。"""
        if not self.BREAK:
            return False
        if self.break_seen_at is not None:
            return True
        self.task.next_frame()
        return self.hud_ok() and self.break_prompt()

    def ct_a4_heavy(self, tag, heavy_at, watch_break=False):
        """连点 A 打到 A4, A4 一出手就按住重击(heavy_at = 估的 A4 起手, 见 CT_PRE_HOLD_QUIET)。返回重击按下的时刻。
        watch_break: 连段里看到处决提示就等 A4 起手后 Y3_A4_TO_BREAK 再按 F, 处决完空手起重击。"""
        self.a_until(heavy_at - self.CT_PRE_HOLD_QUIET, f'{tag}A', watch_break=watch_break)
        if watch_break and self.break_pending():
            self.a_until(heavy_at + self.Y3_A4_TO_BREAK, f'{tag}A4')
            self.y3_break(f'{tag}重击前', time.time())
        self.wait_until_time(heavy_at)
        return self.ct_heavy(tag)

    def target_locked(self):
        """敌人身上的锁定标记。只走框架 has_target 的前两个框: 它后面那条修熊声骸的分支会 sleep 1s 还会按 esc。
        读不了(框架改名)当锁上了, 不点中键。"""
        task = self.task
        try:
            has_name, no_name = task.get_target_names()
            for box in (task.get_box_by_name(has_name).scale(1.1), task.get_box_by_name('box_target_enemy_long')):
                best = task.find_best_match_in_box(box, [has_name, no_name], threshold=0.6)
                if best:
                    return best.name == has_name
        except Exception:
            return True
        return False

    def ct_e_on_cd(self):
        try:
            return bool(self.has_cd('resonance'))
        except Exception:
            return False

    def ct_fire_e(self, tag, presses=None, gap=None):
        """小卡 E: 亮着就按。返回按下的时刻; 本来在 CD 上返回 None, 一下都不按。

        【不等进 CD 再往下走】: 冷却数字要按下后 0.6~0.9s 才出来, 等它会把闪避和下落拖晚。
        见过亮、按了就照放出去往下打, 进没进 CD 由 ct_e_plunge 事后核对。
        """
        start = time.time()
        hits = 0
        while True:
            self.task.next_frame()
            ready = False
            if self.hud_ok():
                try:
                    ready = bool(self.resonance_available()) and not self.ct_e_on_cd()
                except Exception:
                    ready = False
            # 连读 2 帧: 技能栏渐显那几帧会单帧读成可用
            hits = hits + 1 if ready else 0
            if hits >= 2:
                break
            if time.time() - start >= self.CT_E_READY_GRACE:
                self.macro_mark(f'{tag}E在CD')
                return None
            self.macro_wait(0.02)
        at = time.time()
        self.ct_e_at = at
        presses = self.CT_E_PRESSES if presses is None else presses
        for i in range(presses):
            self.send_resonance_key()
            if i + 1 < presses:
                self.macro_wait(self.CT_E_PRESS_GAP if gap is None else gap)
        self.macro_mark(f'{tag}E')
        return at

    def ct_heavy_then_a(self, tag, press_at):
        """重击松手后点 A 到派生帧(这段时间按 E 会被吞)。之后的 E 用 CT_E_HEAVY_PRESSES 连按。"""
        self.a_until(press_at + self.CT_HEAVY_PRESS_TO_E, f'{tag}重击收招A')

    def ct_e_soon(self, tag, max_wait):
        """E 好着返回 True。在 CD 上但冷却数字读到还差 max_wait 秒以内: 边点 A 边等它好(上限多给 0.5s)。
        读不到秒数或差得多返回 False(调用方走跳下落)。"""
        if self.ct_e_up():
            return True
        try:
            rem = float(self.task.get_cd('resonance'))
        except Exception:
            rem = -1.0
        if not 0.0 < rem <= max_wait:
            self.macro_mark(f'{tag}E差{rem:.1f}s(不等)')
            return False

        def up():
            try:
                return bool(self.resonance_available()) and not self.ct_e_on_cd()
            except Exception:
                return False

        return self.a_until(time.time() + rem + 0.5, f'{tag}等E(差{rem:.1f}s)', stop=up, poll=0.05)

    def ct_e_up(self, frames=2):
        """小卡 E 好着(连读 frames 帧可用且没在 CD)。只读不按。"""
        hits = 0
        for _ in range(frames + 2):
            self.task.next_frame()
            ok = False
            if self.hud_ok():
                try:
                    ok = bool(self.resonance_available()) and not self.ct_e_on_cd()
                except Exception:
                    ok = False
            hits = hits + 1 if ok else 0
            if hits >= frames:
                return True
            self.macro_wait(0.02)
        return False

    def y3_wait_sword2(self, tag, arrived):
        """跳下落之前等神权剑亮(见 Y3_SWORD2_CAP)。边等边点 A。"""
        if self.ct_sword2():
            self.macro_mark(f'{tag}神权剑已亮(到场{time.time() - arrived:.2f}s)')
            return True
        until = arrived + self.Y3_SWORD2_CAP
        if until < time.time() + self.Y3_SWORD2_MORE:
            until = time.time() + self.Y3_SWORD2_MORE
        start = time.time()
        got = self.a_until(until, f'{tag}等神权剑', stop=self.ct_sword2, poll=0.05, watch_break=True)
        self.macro_mark(f'{tag}神权剑{"亮了" if got else "没亮(到点跳)"}(+{time.time() - start:.2f}s,'
                        f'到场{time.time() - arrived:.2f}s)')
        return got

    def y3_break(self, tag, not_before):
        """小卡连段打完再处决: 连段里看到过提示、或者现在有提示, 等到 not_before(下落落地)再按 F。返回按了 F 没有。"""
        seen = self.break_seen_at
        self.break_seen_at = None
        if not self.BREAK:
            return False
        if seen is None:
            self.task.next_frame()
            if not (self.hud_ok() and self.break_prompt()):
                return False
        self.macro_wait(max(0.0, not_before - time.time()))
        self.task.next_frame()
        if self.hud_ok() and self.break_prompt():
            if seen is not None:
                self.macro_mark(f'{tag}提示等了{time.time() - seen:.2f}s')
            self.do_break(tag)
            return True
        self.macro_mark(f'{tag}处决提示没了' + (f'(亮过{time.time() - seen:.2f}s前)' if seen is not None else ''))
        return False

    def ct_e_plunge(self, tag, until=None, watch=False, presses=None, gap=None):
        """E(地转空, 人权剑) -> 前闪 -> 点 A(空中第一下 = 下落)。E 在 CD 上返回 False, 什么都不做。

        until: 点 A 到这一刻; 没给就点到下落读到(watch)或 Y3_PLUNGE_CAP。
        watch: 读跳跃键小图标 亮 -> 灭 = 下落吸了剑(只有 Y3 那种正常小卡读得到)。
        【佐证】: 按下后 CT_E_CD_EVIDENCE 秒内要读到 E 进 CD。整段都没读到 = E 被吞了(人在地上),
        返回 False 让调用方补一个跳下落; 窗口没看完就到 until 的(重击后那个 E)只记日志。
        """
        e_at = self.ct_fire_e(tag, presses=presses, gap=gap)
        self.ct_e_skipped = e_at is None
        if e_at is None:
            return False
        ev = {'cd': None}

        def e_evidence():
            if ev['cd'] is None and self.ct_e_on_cd():
                ev['cd'] = time.time() - e_at
            return False

        while time.time() < e_at + self.CT_E_TO_DODGE:
            self.task.next_frame()
            if self.hud_ok():
                e_evidence()
            self.macro_wait(0.03)
        self.dodge(tag)
        self.macro_wait(self.CT_DODGE_TO_A)
        if until is None:
            until = e_at + self.Y3_PLUNGE_CAP
        if watch:
            state = {'seen': False, 'gone': 0}

            def plunged():
                e_evidence()
                lit = self.ct_midair()
                if lit:
                    state['seen'] = True
                    state['gone'] = 0
                elif state['seen']:
                    state['gone'] += 1
                return state['gone'] >= self.PLUNGE_GONE_CONFIRM

            hit = self.a_until(until, f'{tag}下落A', stop=plunged, poll=0.05)
            if not hit:
                self.macro_mark(f'{tag}下落没读到(见过亮{int(state["seen"])})')
        else:
            self.a_until(until, f'{tag}下落A', stop=e_evidence, poll=0.10)
        if ev['cd'] is not None:
            self.macro_mark(f'{tag}E进CD(+{ev["cd"]:.2f}s)')
            return True
        if time.time() - e_at < self.CT_E_CD_EVIDENCE:
            self.macro_mark(f'{tag}E进CD没来得及读')
            return True
        self.macro_mark(f'{tag}E没进CD(被吞了)')
        self.logger.info(f'{tag}: 小卡 E 按了 {self.CT_E_CD_EVIDENCE:.1f}s 都没读到进 CD, 当没放出去, 补跳下落')
        return False

    def ct_jump_plunge(self, tag, a_for, presses=1):
        """没 E 的下落: 跳(presses 下) -> 点 A 到第一下跳后 a_for 秒。返回第一下跳的时刻。"""
        j_at = time.time()
        self.task.jump(after_sleep=0)
        for _ in range(presses - 1):
            self.macro_wait(self.CT_JUMP_GAP)
            self.task.jump(after_sleep=0)
        self.macro_mark(f'{tag}跳' + (f'x{presses}' if presses > 1 else ''))
        self.macro_wait(self.CT_JUMP_TO_A)
        self.a_until(j_at + a_for, f'{tag}下落A')
        return j_at

    def ct_r_form(self, tag, want_small):
        """按 R 化身(芙 -> 小卡 want_small=True / 小卡 -> 芙)。读形态确认, 没翻隔 CT_R_RETRY_GAP 补按。

        芙那边每次按之前先看决意满没满: 满了这下 R 是 R2, 返回 'big' 不按。返回 True/False/'big'。
        补按之前先读形态: 第一下其实翻了只是读得慢, 再按一下(化身冷却 1.5s 过了)会翻回去。
        self.form_pressed_at = 翻过来的那一下 R 的时刻(后面的计时从这里算; 第一下被吞时是补按那一下)。
        """
        self.form_pressed_at = time.time()
        for i in range(self.CT_R_TRIES):
            self.task.next_frame()
            hud = self.hud_ok()
            if i > 0 and hud and self.is_small() == want_small:
                self.macro_mark(f'{tag}R化身{"卡提" if want_small else "芙"}(x{i},读得慢)')
                return True
            if want_small and hud and self.ct_lib_big():
                self.macro_mark(f'{tag}决意已满(不化身)')
                return 'big'
            self.send_liberation_key()
            pressed = time.time()
            self.form_pressed_at = pressed
            hits = 0
            while time.time() - pressed < self.CT_R_CONFIRM:
                self.macro_wait(0.03)
                self.task.next_frame()
                hits = hits + 1 if (self.hud_ok() and self.is_small() == want_small) else 0
                # 连读 2 帧: 下落那一刻形态读数会单帧跳一下(录屏 L8)
                if hits >= 2:
                    self.macro_mark(f'{tag}R化身{"卡提" if want_small else "芙"}(x{i + 1},'
                                    f'{time.time() - pressed:.2f}s)')
                    return True
            self.click()
            self.macro_wait(max(0.0, pressed + self.CT_R_CONFIRM + self.CT_R_RETRY_GAP - time.time()))
        self.macro_mark(f'{tag}R化身{"卡提" if want_small else "芙"}没翻(x{self.CT_R_TRIES})')
        return False

    def hud_settle(self, cap=1.0):
        """等 HUD 连续在场 HUD_SETTLE 秒(演出刚回来那几帧技能栏/协奏环还在渐显, 读数是假的)。"""
        start = time.time()
        since = None
        while time.time() - start < cap:
            self.task.next_frame()
            if self.hud_ok():
                since = time.time() if since is None else since
                if time.time() - since >= self.HUD_SETTLE:
                    return True
            else:
                since = None
            self.macro_wait(0.02)
        return False

    def con_now(self):
        try:
            return float(self.task.get_current_con())
        except Exception:
            return -1.0

    def seg_y1(self, ciac, tag):
        """R2 演完的小卡: [E] 切夏空(卡提协奏满 = 夏空变奏)。按不按 E 见 Y1_E_LOOPS。"""
        self.hud_settle()
        if self.loop_count > self.Y1_E_LOOPS:
            self.macro_mark(f'{tag}E留给Y3' if self.ct_e_ready() else f'{tag}E没好')
        elif self.ct_e_ready() and self.ct_e_ready():
            self.ct_press_e(f'{tag}E', cap=self.Y1_E_CAP)
        else:
            self.macro_mark(f'{tag}E没好')
        self.macro_mark(f'{tag}卡提协奏{self.con_now():.2f}')
        self.need(self.switch_retry(ciac, tag, read_con=True), f'{tag}: 切夏空失败')

    def seg_ct_build(self, tag, arrived, intro):
        """小卡: Q -> A 到 A4 -> E 下落(没 E 就跳下落) -> A -> 重击 -> [E 下落] -> R1 变身。

        intro: 夏空变奏进来(Y3); 启动轴/宏散过从这里起手时为 False, 连段从 A1 打。
        返回 R1 放出去没有。演出不在这里等: seg_x1 在演出里就开始按 E。
        """
        self.spam_key(self.send_echo_key, self.Y3_Q_WINDOW, tag=f'{tag}Q', presses=2)
        e_at = arrived + self.Y3_A_TO_E
        # 【佐证】变奏给异权剑: 到场 CT_INTRO_SWORD_CAP 秒内读到 sword1 = 吃到了变奏(只记日志)
        ev = {'s1': None}

        def stop():
            try:
                swords = self.get_sword_buffs()
            except Exception:
                return False
            if intro and ev['s1'] is None and swords.get('sword1') \
                    and time.time() - arrived <= self.CT_INTRO_SWORD_CAP:
                ev['s1'] = time.time() - arrived
            return bool(self.Y3_SWORD2_EARLY and swords.get('sword2'))

        self.break_seen_at = None
        self.a_until(e_at, f'{tag}A到A4', stop=stop, poll=0.20, watch_break=True)
        if intro:
            self.macro_mark(f'{tag}变奏(异权剑+{ev["s1"]:.2f}s)' if ev['s1'] is not None else f'{tag}没看到变奏异权剑')
        plunged = self.ct_e_plunge(f'{tag}', watch=True)
        if not plunged and self.ct_e_skipped and self.ct_e_soon(tag, self.Y3_E_WAIT):
            plunged = self.ct_e_plunge(f'{tag}', watch=True)
        if plunged:
            landed_at = time.time() + self.Y3_PLUNGE_TO_BREAK
            heavy_at = self.ct_e_at + self.Y3_E_TO_HEAVY
        else:
            self.y3_wait_sword2(tag, arrived)
            j_at = self.ct_jump_plunge(f'{tag}', self.CT_JUMP_TO_A + 0.80)
            landed_at = time.time()
            heavy_at = j_at + self.Y3_JUMP_TO_HEAVY
        # 下落完连段本来就从 A1 起, 这时处决不费连段
        if self.y3_break(f'{tag}下落后', landed_at):
            heavy_at = time.time() + self.Y3_BREAK_TO_HEAVY
        # 这段的 A4 给 R1 前那一下下落补神权剑(没那一下就留给 X4); 这里看到的提示等 A4 出手、重击之前再按
        press_at = self.ct_a4_heavy(tag, heavy_at, watch_break=True)
        # 重击后 E 下落只有 L1 打(手打也是): L2 起直接 R1 变身, E 和场上的神权剑/异权剑留给 X4 下落。
        # 10-28 v0.1.10 每圈 Y1 都按了 E, Y3 重击后 E 又好了, 每圈都多打一次下落
        if self.loop_count > self.Y1_E_LOOPS:
            pre_e = False
            if self.ct_e_ready():
                self.macro_mark(f'{tag}前E留给X4')
        else:
            pre_e = self.ct_e_ready()
        if pre_e:
            self.ct_heavy_then_a(f'{tag}前E', press_at)
            plunged = self.ct_e_plunge(f'{tag}前E', until=time.time() + self.Y3_PRE_R1_E_A,
                                       presses=self.CT_E_HEAVY_PRESSES, gap=self.CT_E_HEAVY_GAP)
            self.ct_swords_left = not plunged
        else:
            self.ct_swords_left = True
            self.wait_until_time(press_at + self.Y3_HEAVY_PRESS_TO_R)
        return self.ensure_r(self, f'{tag}R1', self.Y3_R1_WINDOW, self.Y3_R1_CAP,
                             build=lambda r: self.macro_spam(self.R_BUILD_SLICE, tag=f'{tag}攒R#{r}'))

    def fl_e2_started(self):
        """芙 E2 起手: E 图标进 CD 约 0.15s(手打录屏 2K/1080 都读得到; E1 期间不进 CD)。"""
        try:
            return bool(self.has_cd('resonance'))
        except Exception:
            return False

    def seg_x1(self, ciac, tag, a_tap=False):
        """R1 变身演出 -> 芙 E1 -> E2 -> 切夏空(芙还在空中)。调用前 R1 刚放出去(fire_r 记了 lib_press_at)。

        E 从演出里就开始连按: 10-28 实机三局都是等 HUD 回来才按, 芙演完原地站 ~0.5s 才回 HUD,
        回来后的 E 又被吞 ~0.85s, E1 出得太晚, 切人时芙刚离地, 夏空落地只能打地面 A。
        """
        r_at = self.lib_press_at
        start = time.time()
        gone_at = None
        back_hits = n = 0
        next_e = r_at + self.X1_E_FROM_R
        timeout = False
        while True:
            self.task.next_frame()
            now = time.time()
            if not self.hud_ok():
                if gone_at is None:
                    gone_at = now
                back_hits = 0
            elif gone_at is not None:
                if now - gone_at >= self.CT_R1_ANIM_MIN:
                    back_hits += 1
                    if back_hits >= self.HUD_BACK_CONFIRM:
                        break
            elif now - start >= self.HUD_NO_ANIM_GRACE:
                break
            if now - start >= self.LIB_ANIM_TIME_OUT:
                timeout = True
                break
            if now >= next_e:
                self.send_resonance_key()
                n += 1
                next_e = now + self.X1_E_EVERY
            self.macro_wait(0.01)
        hud_at = time.time()
        if gone_at is not None:
            self.add_freeze_duration(gone_at, hud_at - gone_at)
        self.macro_mark(f'{tag}R1演出({"timeout" if timeout else "ok"},E x{n},R后{hud_at - r_at:.2f}s)')
        e2 = False
        n = 0
        quiet_at = hud_at + self.X1_E2_CAP - self.X1_E_QUIET
        lock = {'n': 0, 'at': 0.0, 'ok': not self.X1_LOCK}
        while time.time() - hud_at < self.X1_E2_CAP:
            self.task.next_frame()
            now = time.time()
            if now - hud_at >= self.X1_E2_GUARD and self.hud_ok() and self.fl_e2_started():
                e2 = True
                break
            if not lock['ok'] and lock['n'] < self.X1_LOCK_TRIES and now - lock['at'] >= self.X1_LOCK_GAP \
                    and self.hud_ok():
                if self.target_locked():
                    lock['ok'] = True
                else:
                    self.task.middle_click()
                    lock['n'] += 1
                    lock['at'] = now
            if now >= next_e and now < quiet_at:
                self.send_resonance_key()
                n += 1
                next_e = now + self.X1_E_EVERY
            self.macro_wait(0.01)
        if lock['n']:
            self.macro_mark(f'{tag}锁怪(中键x{lock["n"]},{"锁上了" if lock["ok"] else "没确认"})')
        elif self.X1_LOCK and lock['ok']:
            self.macro_mark(f'{tag}锁怪(本来就锁着)')
        if e2:
            e2_at = time.time()
            if a_tap:
                self.tap()
                self.macro_mark(f'{tag}E2下劈点A')
            self.wait_until_time(e2_at + self.X1_E2_TO_SWITCH)
        self.macro_mark(f'{tag}E{"2" if e2 else "2没读到(到点切)"}(x{n},HUD后{time.time() - hud_at:.2f}s)')
        self.need(self.switch_retry(ciac, tag, read_con=True), f'{tag}: 切夏空失败')

    def seg_x3_x5(self, tag, arrived):
        """芙(夏空大招后进来): A -> R 化身卡提 -> 小卡段 -> R 化身芙 -> A 到决意满 -> R2 -> 演完。"""
        # X3: 决意满了这下 R 就是 R2, 小卡段整个跳过
        lock = {'n': 0, 'at': 0.0, 'ok': False}

        def stop():
            if not lock['ok'] and lock['n'] < self.X3_LOCK_TRIES and time.time() - lock['at'] >= self.X3_LOCK_GAP:
                if self.target_locked():
                    lock['ok'] = True
                else:
                    lock['n'] += 1
                    lock['at'] = time.time()
                    self.task.middle_click()
            return self.ct_lib_big()

        self.a_until(arrived + self.X3_A, f'{tag}芙A', stop=stop, poll=self.X3_LIB_POLL)
        if lock['n']:
            self.macro_mark(f'{tag}补锁怪(中键x{lock["n"]},{"锁上了" if lock["ok"] else "没确认"})')
        got = self.ct_r_form(f'{tag}', want_small=True)
        if got is True:
            self.seg_x4(f'{tag}', self.form_pressed_at)
        elif got is False:
            self.logger.info(f'{tag}: 芙 R 化身卡提希娅没翻过来, 跳过小卡段直接等 R2')
        return self.seg_x5(f'{tag}')

    def seg_x4(self, tag, r_at):
        """显化暂停的小卡: A 到 A4 -> 按住重击(A4 出手就按) -> E -> 闪 -> A(下落) -> R 化身芙。
        没 E: 重击 -> 跳 -> A 下落 -> R。Y3 留下的神权剑+异权剑还在: 直接 E 下落(见 X4_SKIP_BUILD)。"""
        if self.X4_SKIP_BUILD and self.ct_swords_left:
            self.ct_swords_left = False
            self.macro_mark(f'{tag}剑还在(直接E)')
            plunged = self.ct_e_plunge(tag, until=time.time() + self.X4_E_TO_R)
            if not plunged and self.ct_e_skipped and self.ct_e_soon(tag, self.X4_E_WAIT):
                plunged = self.ct_e_plunge(tag, until=time.time() + self.X4_E_TO_R)
            if plunged:
                self.wait_until_time(self.ct_e_at + self.X4_E_TO_R)
            else:
                self.ct_jump_plunge(tag, self.X4_JUMP_TO_R)
        else:
            press_at = self.ct_a4_heavy(f'{tag}小卡', r_at + self.X4_A)
            if self.ct_e_soon(tag, self.X4_E_WAIT):
                self.ct_heavy_then_a(tag, press_at)
                e_at = time.time()
                if self.ct_e_plunge(tag, until=e_at + self.X4_E_TO_R,
                                    presses=self.CT_E_HEAVY_PRESSES, gap=self.CT_E_HEAVY_GAP):
                    self.wait_until_time(e_at + self.X4_E_TO_R)
                else:
                    self.ct_jump_plunge(tag, self.X4_JUMP_TO_R)
            else:
                self.macro_mark(f'{tag}E在CD(重击接跳)')
                self.wait_until_time(press_at + self.CT_HEAVY_TO_JUMP)
                self.ct_jump_plunge(tag, self.X4_JUMP_TO_R, presses=self.CT_HEAVY_JUMPS)
        if self.ct_r_form(tag, want_small=False) is not True:
            self.logger.info(f'{tag}: 小卡 R 化身芙没翻过来(显化没了?)')

    def seg_x5(self, tag):
        """芙: A 到决意满 -> R2 -> 演完。读到变回小卡(显化结束)就不等了。返回 R2 放出去没有。"""
        start = time.time()
        state = {'small': 0}

        def ready():
            if self.ct_lib_big():
                return True
            state['small'] = state['small'] + 1 if self.is_small() else 0
            return state['small'] >= self.X5_SMALL_CONFIRM

        tries = 0
        while time.time() - start < self.X5_LIB_CAP:
            self.a_until(start + self.X5_LIB_CAP, f'{tag}芙A到决意满', stop=ready, poll=0.10)
            if state['small'] >= self.X5_SMALL_CONFIRM:
                self.macro_mark(f'{tag}变回小卡了(显化结束, 没 R2)')
                self.logger.info(f'{tag}: 决意没满显化就结束了, 这圈没有 R2')
                return False
            if not self.ct_lib_big_reads(2):
                continue
            tries += 1
            if self.fire_r(self, f'{tag}R2' if tries == 1 else f'{tag}R2重按#{tries - 1}', self.X5_R2_WINDOW):
                self.wait_hud_back(f'{tag}R2演出', min_gone=self.CT_R2_ANIM_MIN)
                return True
            if tries >= self.R_TRIES:
                break
        self.macro_mark(f'{tag}R2没放({time.time() - start:.1f}s)')
        self.logger.warning(f'{tag}: R2 {time.time() - start:.1f}s 没放出去(按了 {tries} 次)')
        return False

    # ==================== 夏空 ====================

    def ci_full(self, ciac):
        try:
            return bool(ciac.is_mouse_forte_full())
        except Exception:
            return False

    def seg_x2(self, ciac, cart, tag, arrived):
        """夏空: A -> [下落落地] -> E -> Q -> R(演绎) -> 演完 -> 连点切卡提。

        没接上下落的代价在下一次 Y2: 下落解锁的 A4-鼓 没了, Y2 回路只攒到 2 格(10-28 L2)。
        CI_X2_WAIT_LAND 开着时 E 等落地(见 CI_X2_LAND_RISE): 0.75s 内没读到落地就接着点 A 到 CI_X2_AIR_A,
        再不按键等到 CI_X2_LAND_CAP; 关着就 CI_ARRIVE_A 照按 E。
        回路已经满了(上一次 Y2 没用掉)就 E 后先打四拍重奏再 Q。走之前读一次回路留给 Y2 比变奏有没有 +1。
        """
        self.ci_level_left = -1.0
        if self.CI_X2_WAIT_LAND:
            st = {'base': None, 'blind': False}

            def landed():
                return self.ci_x2_landed(ciac, st)

            got = self.a_until(arrived + self.CI_ARRIVE_A, f'{tag}A', stop=landed, poll=0.05)
            if not got and not st['blind']:
                got = self.a_until(arrived + self.CI_X2_AIR_A, f'{tag}没落地补A', stop=landed, poll=0.05)
            while not got and not st['blind'] and time.time() < arrived + self.CI_X2_LAND_CAP:
                self.task.next_frame()
                if self.hud_ok():
                    got = landed()
                self.macro_wait(0.03)
            result = '回路快满(没法看)' if st['blind'] else '落地' if got else '没读到落地(到点E)'
            self.macro_mark(f'{tag}下落{result}(到场{time.time() - arrived:.2f}s,'
                            f'回路起{-1.0 if st["base"] is None else st["base"]:.2f})')
        else:
            self.a_until(arrived + self.CI_ARRIVE_A, f'{tag}A')
        self.macro_mark(f'{tag}回路{self.ci_level(ciac):.2f}')
        full = self.ci_full(ciac) and self.ci_full(ciac)
        ciac.send_resonance_key()
        if full:
            self.macro_mark(f'{tag}回路满了(先打四拍重奏)')
            self.ci_four_beat(ciac, tag)
        else:
            self.macro_wait(self.CI_E_TO_Q)
        ciac.send_echo_key(down_time=self.CI_Q_HOLD)
        self.macro_mark(f'{tag}EQ')
        fired = self.ensure_r(ciac, f'{tag}', self.CI_R_WINDOW, self.CI_R_CAP,
                              build=lambda r: self.macro_spam(self.R_BUILD_SLICE, tag=f'{tag}攒R#{r}'))
        if fired:
            self.wait_hud_back(f'{tag}R演出', time_out=self.CI_R_ANIM_CAP, min_gone=self.CI_R_ANIM_MIN)
        self.ci_level_left = self.ci_level(ciac)
        con = self.con_now()
        # 手打这里协奏不满(芙不吃变奏); 满了说明上一次 Y2 没把协奏用掉, 整圈错位了
        self.macro_mark(f'{tag}走时回路{self.ci_level_left:.2f}协奏{con:.2f}{"(满:错位)" if con >= 1.0 else ""}')
        self.need(self.switch_retry(cart, tag, click_during=True, read_con=True), f'{tag}: 切卡提失败')

    def ci_x2_landed(self, ciac, st):
        """X2 下落落地: 回路比到场以来的最低值涨了 CI_X2_LAND_RISE, 再隔 0.05s 连读到 CI_X2_LAND_CONFIRM 次
        (当场补读, 不跟点 A 的 0.12s 节奏, 省得确认晚 0.1s+)。调用前已读好帧、HUD 在场。
        回路本来就快满(涨不动)就记 st['blind'], 照旧点满 CI_ARRIVE_A 再 E。"""
        def read():
            try:
                return ciac.forte_level()
            except Exception:
                return None

        level = read()
        if level is None:
            return False
        if level >= 3.0 or (st['base'] is not None and st['base'] > 3.0 - self.CI_X2_LAND_RISE):
            st['blind'] = True
            return False
        st['base'] = level if st['base'] is None else min(st['base'], level)
        for _ in range(self.CI_X2_LAND_CONFIRM - 1):
            if level is None or level - st['base'] < self.CI_X2_LAND_RISE:
                return False
            self.macro_wait(0.05)
            self.task.next_frame()
            level = read() if self.hud_ok() else None
        return level is not None and level - st['base'] >= self.CI_X2_LAND_RISE

    def ci_four_beat(self, ciac, tag):
        """回路满、E 刚按过: 按住重击·四拍重奏到回路清空再松手。"""
        self.macro_wait(self.CI_E_TO_HOLD)
        self.attack_down()
        start = time.time()
        cleared = 0
        try:
            while time.time() - start < self.CI_HOLD_CAP:
                self.task.next_frame()
                if self.hud_ok():
                    if self.ci_full(ciac):
                        cleared = 0
                    else:
                        cleared += 1
                        if cleared >= self.CI_CLEAR_CONFIRM:
                            break
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}四拍重奏({"清空" if cleared >= self.CI_CLEAR_CONFIRM else "撞上限"},'
                        f'{time.time() - start:.2f}s)')

    def ci_level(self, ciac):
        self.task.next_frame()
        if not self.hud_ok():
            return -1.0
        try:
            level = ciac.forte_level()
        except Exception:
            level = None
        return -1.0 if level is None else float(level)

    def ci_con_full_wait(self, ciac, tag):
        """切卡提前等夏空协奏真满(连读 CI_CON_CONFIRM 帧 1.0), 边等边点 A(普攻也给协奏)。返回满了没有。"""
        state = {'hits': 0, 'last': -1.0}

        def con_full():
            con = self.con_now()
            state['last'] = con
            state['hits'] = state['hits'] + 1 if con >= 1.0 else 0
            return state['hits'] >= self.CI_CON_CONFIRM

        start = time.time()
        got = self.a_until(start + self.CI_CON_CAP, f'{tag}等协奏满', stop=con_full, poll=0.03)
        result = '满' if got else f'没满({state["last"]:.2f})'
        self.macro_mark(f'{tag}夏空协奏{result}({time.time() - start:.2f}s)')
        if not got:
            self.logger.info(f'{tag}: 夏空协奏 {self.CI_CON_CAP:.1f}s 没攒满(最后读数 {state["last"]:.2f}), 卡提这次没变奏')
        return got

    def seg_y2(self, ciac, cart, tag, arrived):
        """夏空(变奏): A 到回路满 -> E -> 按住重击·四拍重奏 -> 回路清空 -> 松手 -> 协奏满了切卡提。

        【佐证】: 到场 0.6s 读回路格数(变奏 +1 格, 没涨 = 卡提协奏没满没给变奏, A 到满的上限放宽);
        切走前协奏必须真满(不满卡提没变奏, 整圈错位, 见 CI_CON_CAP)。
        """
        state = {'hits': 0}

        def full():
            state['hits'] = state['hits'] + 1 if self.ci_full(ciac) else 0
            return state['hits'] >= self.CI_FULL_CONFIRM

        got = self.a_until(arrived + self.CI_INTRO_READ, f'{tag}A', stop=full, poll=0.05)
        cap = self.CI_FULL_CAP
        if not got:
            level = self.ci_level(ciac)
            before = self.ci_level_left
            # X2 走时留下的格数读到过就比增量, 没读到按绝对值
            intro = level >= (before + 0.6 if before >= 0 else self.CI_NO_INTRO_LEVEL)
            self.macro_mark(f'{tag}回路{before:.2f}->{level:.2f}({"变奏到了" if intro else "没吃到变奏"})')
            if not intro:
                cap = self.CI_FULL_CAP_NO_INTRO
            got = self.a_until(arrived + cap, f'{tag}A到回路满', stop=full, poll=0.05)
        ciac.send_resonance_key()
        self.macro_mark(f'{tag}E')
        if not got:
            state['hits'] = 0
            got = self.a_until(time.time() + self.CI_RETRY_FILL, f'{tag}补A到回路满', stop=full, poll=0.05)
        if got:
            self.ci_four_beat(ciac, tag)
        else:
            self.macro_mark(f'{tag}回路没满(不按重击)')
        self.ci_con_full_wait(ciac, tag)
        self.need(self.switch_retry(cart, tag, read_con=True), f'{tag}: 切卡提失败')

    # ==================== 一圈 ====================

    def op_wait_after_f(self, tag):
        """启动轴第一下补到离物理 F OP_AFTER_F 秒(插件「F 之后等待」设多少都一样)。"""
        pressed = getattr(self.task, '_f_last_press', -1)
        since = time.time() - pressed
        if pressed < 0 or since >= self.OP_AFTER_F_RECENT:
            return
        short = since < self.OP_AFTER_F
        if short:
            self.macro_wait(self.OP_AFTER_F - since)
        self.macro_mark(f'{tag}离F{since:.2f}s' + (f'(补到{self.OP_AFTER_F:.2f}s)' if short else ''))

    def run_cycle(self, ciac, opener, tag):
        """启动轴: 小卡 E -> R1 -> X1..X5。循环轴: Y1 -> Y2 -> Y3 -> X1..X5。返回时 R2 演完、小卡在场。"""
        marks = len(self.macro_marks)
        self.timeline_logged = False
        self.ct_swords_left = False
        start = self.cur
        if start is not self and start is not ciac:
            self.need(self.switch_retry(self, f'{tag}入场'), f'{tag}: 切卡提失败')
            start = self
        r1 = False
        if opener:
            self.op_wait_after_f(tag)
            self.need(self.cur is self or self.switch_retry(self, f'{tag}入场'), f'{tag}: 切卡提失败')
            if not self.ct_small_now():
                self.macro_mark(f'{tag}开局是芙')
                self.seg_x5(f'{tag}收芙')
            # 能量不够就别先按 E: E 后在空中, 攒能量段第一下 A 就成了只吸 1 把剑的下落(干跑抓到的)
            if self.lib_ready_reads(self, 2):
                e_at = time.time()
                self.ct_press_e(f'{tag}E')
                self.wait_until_time(e_at + self.OP_E_TO_R)
                r1 = self.fire_r(self, f'{tag}R1', self.Y3_R1_WINDOW)
            else:
                self.macro_mark(f'{tag}R1没亮(先攒能量)')
            if not r1:
                r1 = self.seg_ct_build(f'{tag}攒', time.time(), intro=False)
        else:
            if start is self and not self.ct_small_now():
                # 宏散在芙形态里: 先把这一段 R2 收掉
                self.macro_mark(f'{tag}入场是芙')
                self.seg_x5(f'{tag}收芙')
            if start is self:
                self.seg_y1(ciac, f'{tag}Y1')
            self.seg_y2(ciac, self, f'{tag}Y2', time.time())
            r1 = self.seg_ct_build(f'{tag}Y3', time.time(), intro=True)
        if r1:
            self.seg_x1(ciac, f'{tag}X1', a_tap=opener and self.OP_X1_A_TAP)
            self.seg_x2(ciac, self, f'{tag}X2', time.time())
            self.seg_x3_x5(f'{tag}X', time.time())
        else:
            self.logger.warning(f'{tag}: R1 没放出来, 这圈不变身, 交回框架下一圈重来')
        self.logger.info(f'{tag} cycle timeline: {self.macro_timeline(marks)}')
        self.timeline_logged = True

    def macro_enter(self, entry_char):
        ciac = self.teammate('Ciaccona')
        if ciac is None:
            return None
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        self.mark_busy(True)
        self.cur = entry_char or self.on_field_char() or self
        for char in self.task.chars:
            if char is not None:
                char.check_f_on_switch = False
        self.macro_start()
        self.timeline_logged = False
        self.hud_seen_at = time.time()
        self.hud_watch = True
        return ciac, previous

    def macro_exit(self, previous):
        # 长按跨了好几个方法, 中途抛异常的话鼠标会一直按着。这里是唯一保证松手的地方
        self.release_attack()
        # 中途被停(关自动战斗/切出窗口)也要把时间轴写下来
        if not self.timeline_logged and self.macro_marks:
            self.logger.info(f'kxy timeline (没跑完): {self.macro_timeline()}')
            self.timeline_logged = True
        self.hud_watch = False
        self.task.skip_combat_check = previous
        self.mark_busy(False)

    def perform_opener(self, entry_char=None):
        """启动轴: 小卡 E -> R1 变身 -> X 段 -> R2 演完。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        ciac, previous = got
        self.logger.info(f'kxy opener entry: {self.cur.name}')
        try:
            self.loop_count = 0
            self.run_cycle(ciac, opener=True, tag='op')
            self.logger.info(
                f'kxy opener total {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s, 处决 {self.breaks})')
        except MacroBroken as e:
            self.logger.warning(f'kxy opener broke ({e}) — timeline: {self.macro_timeline()}')
            self.timeline_logged = True
        finally:
            self.macro_exit(previous)
        return True

    def perform_loop(self, entry_char=None):
        """循环轴一圈(R2 演完的小卡起手)。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        ciac, previous = got
        try:
            self.loop_count += 1
            n = self.loop_count
            self.run_cycle(ciac, opener=False, tag=f'L{n}')
            self.logger.info(
                f'kxy loop #{n} {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s, 处决 {self.breaks})')
        except MacroBroken as e:
            self.logger.warning(f'kxy loop broke ({e}) — timeline: {self.macro_timeline()}')
            self.timeline_logged = True
        finally:
            self.macro_exit(previous)
        return True

    # ==================== 框架接口 ====================

    def drive(self, entry):
        """三个人的 do_perform 都走这里。entry = 框架这次调的是谁(= 场上是谁)。"""
        # 【HUD 不在就什么都不做】: 关卡结束/结算/过场时框架还会接着调进来(F 开始战斗那边撑着不脱战)
        if not self.wait_hud_up(cap=self.DRIVE_HUD_CAP, tag='drive'):
            if time.time() - self.drive_log_at > 10:
                self.drive_log_at = time.time()
                self.logger.info('kxy: 队伍 HUD 不在(结算/过场/窗口没了?), 宏不动')
            return None
        blocked = self.opener_blocked_by()
        if blocked is None:
            # 标记要在跑之前落: 中途抛异常(脱战/任务被停)也不能让启动轴重跑
            self.opener_armed = False
            self.last_opener = time.time()
            return self.perform_opener(entry)
        self.logger.info(f'kxy: opener not pending ({blocked}), running the loop')
        return self.perform_loop(entry)

    def do_perform(self):
        if not self.is_in_kxy:
            return super().do_perform()
        self.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时让框架把卡提切上来(启动轴第一格就是她的 E)。"""
        if self.is_in_kxy and self.opener_pending():
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        self.release_attack()
        return super().on_combat_end(chars)
