from src.char.BaseChar import SwitchPriority
from src.char.Youhu import Youhu as NativeYouhu


class Youhu(NativeYouhu):
    """卡夏双人轴(卡提希娅/夏空/釉瑚)里的凑数队友: 从不主动上场(两人队框架不加载自定义代码, 只能三人)。

    被游戏换上场(卡提/夏空倒了、开局站的是她)时转给卡提的 drive(), 宏会先切回卡提。
    """

    @property
    def is_in_kxy(self) -> bool:
        members = 0
        for char in self.task.chars:
            if char and char.name in {'Cartethyia', 'Ciaccona'}:
                members += 1
        return members == 2

    @property
    def is_healer(self):
        """内置定位是治疗; 「战斗前后切换到治疗」会在开战第一下把卡提切走。"""
        try:
            if self.is_in_kxy:
                return False
        except Exception:
            pass  # __init__ 里会先读一次, 那时队伍还没加载
        return super().is_healer

    def macro(self):
        """持宏的卡提。卡提那份自定义没启用时返回 None, 走原版。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'drive') and hasattr(char, 'quick_switch'):
                return char
        return None

    def reset_state(self):
        super().reset_state()
        self.check_f_on_switch = False

    def do_perform(self):
        if not self.is_in_kxy:
            return super().do_perform()
        macro = self.macro()
        if macro is None:
            return super().do_perform()
        macro.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self.is_in_kxy:
            return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)
