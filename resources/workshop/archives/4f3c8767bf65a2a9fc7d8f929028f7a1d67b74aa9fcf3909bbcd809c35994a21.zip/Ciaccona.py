import cv2
import numpy as np

from src.char.BaseChar import SwitchPriority
from src.char.Ciaccona import Ciaccona as NativeCiaccona


class Ciaccona(NativeCiaccona):
    """卡夏双人轴(卡提希娅/夏空/釉瑚)里的夏空。非本队时整套走原版。

    【她不驱动任何一段轴】: 宏体在同目录的 Cartethyia.py, 她一圈上场两次都是宏按数字键切进来的。
    框架调到她的 do_perform 说明宏散了(切人失败/脱战重进), 转给卡提的 drive(), 循环轴从她的 Y2 接上。
    原版的 is_mouse_forte_full() / send_liberation_key() 一行没动, 宏直接用。
    """

    @property
    def is_in_kxy(self) -> bool:
        members = 0
        for char in self.task.chars:
            if char and char.name in {'Cartethyia', 'Youhu'}:
                members += 1
        return members == 2

    def macro(self):
        """持宏的卡提。卡提那份自定义没启用时返回 None, 走原版。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'drive') and hasattr(char, 'quick_switch'):
                return char
        return None

    def forte_level(self):
        """回路条读成 0.0~3.0(三格, 每格按绿点占比算; 满了看原版 is_mouse_forte_full)。读不到返回 None。

        原版 judge_forte() 只认得出满(10-27 手打录屏 0 直接跳 3)。点阵: 亮绿 = 已充, 白灰 = 空。
        只认点阵那一行有、上方那一条没有的绿, 挡掉青色背景(X2 落在青色地面上时整条都偏青)。
        10-27 手打录屏 2K 和缩到 1080 读数一致: X2 结束 1.0, 变奏进场 1.48 -> 2.0, A4 后 2.56。
        """
        task = self.task
        try:
            if self.is_mouse_forte_full():
                return 3.0
            dots = task.box_of_screen_scaled(3840, 2160, 1612, 2000, 2188, 2012, name='ciac_forte_dots', hcenter=True)
            above = task.box_of_screen_scaled(3840, 2160, 1612, 1978, 2188, 1990, name='ciac_forte_above', hcenter=True)

            def green_cols(box):
                hsv = cv2.cvtColor(box.crop_frame(task.frame), cv2.COLOR_BGR2HSV).astype(np.int16)
                h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
                return ((h >= 70) & (h <= 100) & (s >= 90) & (v >= 120)).any(axis=0)

            a, b = green_cols(dots), green_cols(above)
            n = min(a.size, b.size)
            cols = a[:n] & ~b[:n]
        except Exception:
            return None
        level = 0.0
        for i in range(3):
            # 满格的列占比 0.87~0.96(点之间有缝)
            f = min(1.0, float(cols[n * i // 3:n * (i + 1) // 3].mean()) / self.FORTE_SEG_FULL)
            level += f
            if f < 0.9:
                break
        return round(level, 2)

    FORTE_SEG_FULL = 0.85

    def reset_state(self):
        super().reset_state()
        self.check_f_on_switch = False

    def do_perform(self):
        if not self.is_in_kxy:
            return super().do_perform()
        macro = self.macro()
        if macro is None:
            self.logger.warning('kxy: Cartethyia custom code is off, falling back to the native rotation')
            return super().do_perform()
        macro.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时让位给卡提。【要写在 super() 之前】: 原版有自己的切人锁(演绎中不让切)。"""
        if self.is_in_kxy:
            macro = self.macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)
