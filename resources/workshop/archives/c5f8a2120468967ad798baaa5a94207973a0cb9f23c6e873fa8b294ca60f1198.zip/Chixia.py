from src.char.BaseChar import BaseChar


class Chixia(BaseChar):
    def do_perform(self):
        self.click_echo()
        self.switch_next_char()
