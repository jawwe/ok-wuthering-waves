# -*- coding: utf-8 -*-
"""秧莫穗 — 秧秧·玄翎（主控 / 整条轴的持宏者）

队伍：秧秧·玄翎（主控） + 莫特斐（速切副C） + 穗穗（速切副C）
站位：1 穗穗 / 2 莫特斐 / 3 秧秧·玄翎。【开局规则】(用户 2026-10-11 最终版):
  · 穗穗开局 -> 不让场, 自己当入口跑启动宏(第一格"直接切莫特斐"从她身上起跑), 走 0 链轴
  · 莫特斐开局 -> 唯一要纠正的(perform_opener 里先切回秧秧), 之后按"秧秧开局"处理
  · 秧秧开局 -> 读一次苍重击图标: 亮(2链及以上)走 2 链轴, 不亮走 0 链轴
  优先级: 秧秧 MUST(待跑时) / 穗穗·莫特斐 NO。

================= 轴的出处 =================
B 站教程 BV125Yq6PEmX（启动轴 / 循环轴字幕） + 用户给的流程图。
引擎机制、参数、各格判据【全量移植】自 ok-ww 工坊「Chisa_Suisui_Yangyang_Xuanling」
（作者 楽山，v2.0.0，同机实机跑通）—— 那一份是千咲/穗穗/秧秧·玄翎，
本队把【千咲换成了莫特斐】，其余（秧秧的苍/羽、穗穗的回路/强化E、整套宏引擎）逐字对齐。
参考代码里跟千咲（电锯）和烟岚窗口有关的机械在本队不适用，清单见文末"没移植的部分"。

================= 一大轮的形状 =================
    启动宏(24 格) -> 循环宏(44 格) -> 循环宏 -> ...
两条宏末尾都停在秧秧身上，跑完交回框架，下一次 do_perform 还是她，接着跑下一条。
【四条宏的末尾都是 'F?'】(用户 2026-10-11 最终版): 有处决就按(等 YU_BREAK_ANIM 1.6s),
没有就等 YU_NO_BREAK_TAIL(0.5s)。这一格的本意是"没处决就等羽的后摇"——不让下一轮开头的
W/E 被吞(那个 E 是剑式切换, 吞了整轮奇偶就反)。代价: 交回框架的时刻会飘 0.5~1.6 秒。

启动轴(0链, 23 格)：切莫(1000) 莫R 莫e / 切秧 a1 a2 a3 e换羽 / 切莫 a4 / 切秧 a4 /
        EY强化E(换苍, 按完立即切人) / 切莫(1000) e q / 变奏秧(650)
        苍(1550) r e q 第2羽(4300 + 1200 缓冲) / 处决
启动轴(2链, 27 格)：秧a1 a2 / 切莫 / 切穗 / 穗R(RSUI!: 不打闸不点普攻) / 切秧 e换羽(750)
        A A / 切莫(950) 莫R 莫e / 切秧(10) AX(1200) / 切莫(950) 莫e 莫q / 变奏秧(800)
        2羽1苍 / 处决
循环轴(两条一样, 只在尾巴分叉)：
        共同开头：秧 走一步 e a / 延奏切穗 z / 秧 A A / 切莫 切穗 穗e 穗z / 秧 A A e换羽 /
                  切莫 切穗 下落 r 穗q 穗R / 延奏切秧 A A / 切莫 莫R 莫e / 秧 A A /
                  切莫 切秧 AX(600) / 切莫 莫e 莫q / 延奏切秧
        0 链尾巴：1羽(3000) EY0换苍 1苍 秧R 换羽 秧q 第2羽(4300+1200) / 处决  ← 一苍一羽
        2 链尾巴：2羽1苍(参考代码原样: EY0 1苍 Q R 换羽 1羽 点一下 第2羽) / 处决 ← 二羽一苍

【长按时长】(用户 2026-10-11 最终版):
  1苍 2300(启动轴 0 链那处 1550) —— 都按 YY_CANG_TRIM 提前松手, 后面的 Q/R 跟着提前;
  1羽 3000(0链循环)/ 4400(2链尾巴); 第2羽 4300; AX 长按 600(循环)/ 1200(2链启动轴)。
【按住超时会变成普攻】: 按住比招式长出来的那一段, 游戏会当成【持续普攻】—— 那几下普攻
会把流响打空, 于是后面那次"换苍"就变成强化E。所以按住别超过招式, 多出来的等 'F?'
(处决/等后摇)那格去消耗。
【尾巴后面的 1200 缓冲】: 给下一轮开头的 W/E 留时间 —— 人得先从招式里出来, W 才走得动、
后面那个 E 才按得下(2 链尾巴照参考代码放在 'F?' 之前, 由那一格承担)。
【1苍 的提前量是全局的】: 'AYC' 那一格按 YY_CANG_TRIM 提前松手, 各处 1苍 接大招的间隔一起缩。

================= 4r 单轴版: 只有一套轴(强制秧秧开局, 不读链数图标) =================
用户 2026-10-17: 0 链 2 链走同一套(OPENER_MACRO / LOOP_MACRO), 开局不再按苍重击图标
分流; 入口一律先切回秧秧(perform_opener 里强制)。下面这段判据/两套轴的说明只作历史备查。
  · 判据: is_mouse_forte_full()(框架的"重击就绪"找图; 参考代码 M_YU_TRACE 用的同一个,
    它的实机注释: "亮 = 苍翎 >= 1, 重击出手清空苍翎就灭")。只在【第一次出手之前】读一次,
    连读 YY_CHAIN_CONFIRM(3) 帧都亮才算 2 链; 之后记住结论。
  · 只在【入口是秧秧】时才读图标(穗穗开局直接走 0 链、不读; 莫特斐开局会先切回秧秧, 照读)。
    S2 启动轴第一格是秧a1, 假设场上就是秧秧; 读不到也按 0 链走。
  · 两套的差别只有两处: 2 链启动轴【多一个穗穗大招】('RSUI!': 不打闸不点普攻, 开完立马切人)
    且中段是 AX(1200) 长按; 两条循环轴从开头到"延奏切秧 -> 切莫 莫e 莫q -> 延奏切秧"完全一样,
    只在尾巴分叉(0链 一苍一羽 / 2链 二羽一苍)。
  · 轴源: 0 链 = B 站 BV125Yq6PEmX; 2 链及以上 = BV1Dtp764Ep4。

【苍翎账（两条尾巴各一套，改表前先数一遍）】:
  苍翎上限 2, 变奏入场 +1 / 共鸣解放 +1 / 剑式流转(流响耗尽时按 E) +1, 重击消耗全部。
  · 2 链尾巴(参考代码原样) = EY0 换苍(大招清空了流响, 按 E 就是剑式流转 +1) -> 1苍(消耗 2)
    -> R(+1) -> E羽(+1) -> 1羽(消耗 2, 进聆风祀声 12s) -> 点一下
    -> 第2羽(湮象风华, 【不吃苍翎】, 靠聆风祀声)
  · 0 链尾巴 = 1羽(靠前面攒下的 2 点) -> EY0 换苍(+1) -> 1苍(消耗) -> R(+1) -> E羽(+1)
    -> 第2羽(同上, 不吃苍翎)
  循环轴中段那个 羽1 用的是【第一次变奏秧秧】攒下的 1 点 + 前面两个 E 各给的 1 点
  (两个 E 都必须是强化E —— 也就是按下去的时候流响是空的; 这就是用户说的
  "不需要打空流响"的前提: 前面的普攻已经把流响打空了)。
  尾巴里那个 羽2 靠的是【中段 羽1 给的聆风祀声】(12 秒窗口), 所以中段那个羽1
  不能少 —— 少了尾巴的羽2 就没有聆风祀声可打。
【E 的奇偶】: 启动 3 个 E / 循环 4 个 E(开头换苍 / 中段换羽 / 尾巴换苍 / 尾巴换羽),
偶数, 一轮正好翻回原位。【宏表要是抄错一个 E, 这个奇偶就崩了】—— 所以 E 一律单发
(send_e_once), 补按只走 fix_yy_form(先核对图案、确认反了才补, 最多 YY_FORM_FIX 次)。

================= 2羽1苍 / 苍翎账 =================
秧秧·玄翎有【苍剑式】和【羽剑式】两种形态，按 E 切换；重击要【苍翎】满 2 点才放得出来，
而且两种形态的重击是两个不同技能、各自带一个 25 秒 CD 的暴伤 buff：
  · 重击·苍剑式 -> 巨大气旋，获得【绝息】，本次重击暴伤 +160%（长按 2300ms）
  · 重击·羽剑式 -> 命中后自动接空中攻击·释羽风落，获得【流岚】15 秒（招式约 2.0s），
    并进入【聆风祀声】12 秒 —— 这期间羽剑式普攻替换成普攻·湮象风华（3 段，算重击伤害）
苍翎上限 2：变奏入场 +1 / 共鸣解放 +1 / 剑式流转(流响耗尽时按 E) +1，重击消耗全部。
【第2羽不是可打可不打的收尾】: 重击·羽剑式给的【流岚】(160% 暴伤)要到
"普攻·湮象风华第3段结束"才移除 —— 少打这几下等于把 buff 剩下的部分扔了。

================= 输入方式（这一段别改） =================
  · ok-ww 的 mouse_down/mouse_up 是往窗口投 PostMessage，【长按重击游戏不认】——
    参考代码为长按专门改用 SendInput（系统输入流，跟前台的手按一样）。
    本实现照做：前台 -> SendInput，后台 -> 退回 PostMessage（YY_TAIL_SENDINPUT）。
  · 框架的 task.click() 强制 down_time=0.01，在这条轴上"等于没点"——
    所有"点一下"都走 tap()（mouse_down -> 真按住 A_TAP=0.06s -> mouse_up）。
    本类里 self.click() 也被重写成 tap()，引擎里那些"顺手点"一并生效。
  · 技能键走 char.send_*_key()（键位感知），不硬编码 'E'/'R'/'Q'。
  · SendInput 按下的必须 SendInput 松开（release_attack），否则宏异常退出时
    整台电脑的左键会一直按着。

================= 保底的边界（加保底之前先读这一节） =================
【宏表本身是验证过的, 保底的职责是"别让打断把整轮废掉", 不是"纠正宏"】。
分界线只有一条: **这个保底会不会改变游戏状态**。
  · 只花时间的 -> 安全, 默认开:
    切人确认(补按数字键)、等入场、等收招、大招连发(R 在 CD/演出里按是空操作)、
    纯读屏的判据(等图标灭)、协奏闸(等的时候点普攻, 攒的正是这一格要的资源)。
  · 会改状态的 -> 默认关, 出问题时再按需打开:
    补按 E（秧秧每按一次 E 就翻一次剑式!）、额外点普攻（耗流响/推连段）、
    多放一次技能（吃 CD、吃资源）。
【踩过的那次】: 给 1苍 加了"没打出来就再走一轮 E+长按"的重试 —— 可秧秧的剑式是有
奇偶性的（每条宏里她的 E 个数算好了），多按那一次 E 直接把形态翻掉，于是后面那个
"1羽"打出来的其实是【苍剑式重击】，绝息/流岚全错位。**少打一发, 远好过打错一发。**

================= 每一格的判据和兜底 =================
总开关 SAFETY 关掉 = 全部退化成纯照宏打, 下面这些判据一个都不跑。
  格子                判据                          没成立怎么办
  切人                in_team() 读到目标 index      补按数字键, 最多多等 SWITCH_EXTRA;
                                                    累计 MACRO_ABORT_DESYNC 次【放弃整轮】
  变奏切人 (^)        协奏真满(1.0)                 没满就接着点普攻, 上限 CON_GATE_WAIT
                                                    (交给秧秧那格 CON_GATE_WAIT_INTRO)
  穗穗 R (RSUI)       suisui_forte3 (芳菲信 600)    没满就接着点普攻攒, 到 FORTE3_WAIT 照放
  任何大招            队伍 HUD 消失 = 演出开始       连发到出手, 还不出再补救一轮
  穗穗 E (E#)         按到技能进 CD(先见过亮才认暗)  到上限照走, 读屏 trace 进日志
  穗穗强化E (E1)      suisui_e1 图标亮              没亮就先点普攻攒回路; 攒不满【干脆不按】
                                                    (按下去是普通E, 白吃 CD 还进不了濯雨时)
  秧秧 E苍/E羽        剑式图案核对                  反了才补一次 E(YY_FORM_FIX), 读不准不动手
  秧秧强化E (EY/EY0)  E 图标红环(流响打空了)        没亮就点普攻打空; 'EY0' 只读不点
  秧秧 R (RY)         队伍 HUD 消失 = 演出开始       连发到出手; 演完 + 落地 + M_R_TO_E 收招才按 E
  秧秧 1苍/1羽        不读判据, 按表里的时长          M_YU_TRACE 把重击就绪图标读数打进日志
  处决 (F?)           f_break 提示                   没提示就等 YU_NO_BREAK_TAIL, 期间提示亮了照按
【切人之后紧跟着长按的格子要额外等一下】: 见 HOLD_AFTER_SWITCH / settle_before_hold。
【别把返回点挪进任何演出里】—— 演出期间读不到目标, 框架会判脱战、重进战斗、重跑启动轴。
处决那格是等 HUD 回来才返回的（try_f_break），满足这一条。

================= 启动轴的三个"重新武装"触发源 =================
玩家手动开关自动战斗 / 按物理 F / 距上次启动超过 OPENER_MIN_GAP。
手动停任务是【任务停止把战斗循环打断】, 异常一路往上抛, combat_end() 整个跳过 ->
on_combat_end() 不执行 -> opener_armed 会跨局留在 False; 重开时角色对象又常常被
粘性复用, reset_state() 根本轮不到跑。所以用一个 daemon 线程盯 task.enabled 的
False->True 跳变（start_enable_watch），另一个盯物理 F 键（start_f_watch）。

================= 没移植的部分（只有千咲的电锯线，本队没有这个人） =================
参考代码 89 个方法里移植了 78 个（逐字）。剩下 11 个全是【千咲电锯】专用，本队不适用:
  · chi_e_stable_lit / chi_e_glyph / chi_e_lit / e_icon_white / chi_e_quick_lit /
    chi_saw_state / chi_con_e2 / confirm_saw_mode / fill_saw_resonance /
    cast_enhanced_e / CHI_GLYPHS / CHI_E_* / CHI_SAW_* / TIGHT_CHI_* / CHI_FILL_*
    —— 全是"锯环残响满没满、进没进电锯模式、齿轨轮回还是解弦之眼"的判据，
    对应的格子是 'E*'（千咲强化E）和 'A~'（电锯长按）。
    莫特斐没有这套资源; 他的对应机制（大招能量闸）由 fill_liberation 覆盖, 已移植,
    'RMO' 那一格走的就是它。
  · is_in_yangqiansui 改名成 is_in_yangmosui（队伍构成不同）。
【烟岚窗口那一整套照原样移植了】（WIN 标记 / win_* / close_yanlan_window /
YANLAN_* / fire_r_tight / TIGHT_*）—— 它是【穗穗自己的机制】(飞仙翾舞1),
不是千咲的, 所以本队也用得上。但本队的轴里没有 'WIN' 标记, 所以那一段目前是惰性的:
翾舞1 那一刻场上是谁会打进日志（`烟岚窗口(x.xxs,翾舞1时场上:XX)`）, 要真正管理这个
窗口, 在穗穗大招那一格后面加一个 ('WIN', 0, 0, '烟岚窗口') 就行。

================= 移植版跟参考代码的差别（三处，都是队伍构成决定的） =================
  1. is_in_yangqiansui -> is_in_yangmosui, teammate('Chisa') -> teammate('Mortefi')。
  2. 参考代码把 'R!'/'R3' 两种格子写在 macro_key 里; 这里拆成 cast_mo_lib（'RMO'）
     和 cast_sui_lib（'RSUI'）两个方法, 逻辑逐条相同 —— 因为莫特斐跟千咲的大招
     收招处理不一样（MO_R_TO_E = 0, 用户实测不用等）。
  3. 多了一个 'AZ' 格子（重击长按, 本队三人都用）。普攻一律用参考代码的 'A'(一格一下),
     多下就多写几格 —— 之前那套 'A4'/'A23' 代号已经删掉。
  4. tap() 走 PostMessage（跟参考逐字一致）; 只有 1苍/1羽/第2羽 那几段长按走 SendInput。
  5. Suisui.py 里 is_healer 覆盖成 False（用户要求, 见那份文件的注释）。
"""

import base64
import ctypes
import hashlib
import math
import os
import threading
import time

import cv2
import numpy as np

from src.Labels import Labels
from src.char.BaseChar import SwitchPriority, forte_white_color
from src.char.YangYangSp import YangYangSp as NativeYangYangSp

# ==================== 物理 F 键监视 ====================
# 跟参考代码（Chisa_Suisui_Yangyang_Xuanling/YangYangSp.py）里那份逐字相同, 说明见那边。
# 几个队伍文件都能启动这个线程, 但每个 task 只启一次(_f_watch_started) —— 所以宏在跑时
# 两个标志都要置上, 不管是哪个文件先启的线程都认得出"这是手动处决, 不是重开副本"。
F_VK = 0x46              # 'F'
F_POLL_INTERVAL = 0.05   # 一次按键按住的时间远大于这个, 不会漏采
F_LOG_DEBOUNCE = 1.0     # 按住不放时别刷日志
# 界面上那张设置卡片, 在 ok_tasks/FStartCombatTask.py。放 ok_tasks/ 是因为选项必须由
# 代码声明(json 里多出来的键会被 verify_config 丢掉), 而 config.py/src 每次更新都会被
# 盖回官方版。ok_tasks/ 不在仓库里, 更新不碰。
F_TASK_NAME = 'FStartCombatTask'


def f_settings(task):
    """读界面上的(开关, F 之后等待秒数)。

    【没装那张卡片就返回默认值(开, 0 秒)】—— 把队伍导给别人时对方没有 ok_tasks/
    里的那个任务, 功能照常, 只是他那边没有界面可调。
    """
    executor = getattr(task, 'executor', None)
    for group in ('trigger_tasks', 'onetime_tasks'):
        for other in getattr(executor, group, None) or ():
            if type(other).__name__ == F_TASK_NAME:
                try:
                    return bool(other.enabled), float(getattr(other, 'f_start_delay', 0) or 0)
                except Exception:
                    return True, 0.0
    return True, 0.0


# ==================== 自动战斗开关监视 ====================
# 【玩家手动开关自动战斗, 必须从启动轴重跑】(用户明确要求:
# "以后做的轴, 都要确保不管什么时候开关自动战斗, 都要从一开始启动")。
#
# 为什么不会自己重跑: 手动停任务是【任务停止把战斗循环打断】, 异常一路往上抛,
# `AutoCombatTask` 的 combat_end() 整个跳过 -> `on_combat_end()` 不执行 ->
# 角色实例上的标记全部留着, 其中就有 `opener_armed=False`。重开时【队伍识别没变化的话
# load_chars() 也不会跑】(角色对象被粘性复用), 于是 reset_state() 里那句
# `opener_armed = True` 根本轮不到执行 —— 直接跳到循环轴。
#
# 【为什么用线程而不是在 do_perform 里判】: do_perform 只在任务【已经启用】时才会被调到,
# 站在里面永远看不到"刚才关过"。只有独立线程能观察到 enabled 的 True->False->True。
# 判据跟物理 F 键那条路完全一致: 记一个时间戳, 调用方比 `> last_opener` 就放行。
ENABLE_POLL_INTERVAL = 0.2


def start_enable_watch(task, logger=None):
    """盯 task.enabled 的 False->True 跳变, 把时刻记到 task._ww_task_restarted_at。

    daemon 线程, 跟着进程退出。每个 task 只启一次。
    """
    if getattr(task, '_ww_enable_watch_started', False):
        return
    task._ww_enable_watch_started = True
    if not hasattr(task, '_ww_task_restarted_at'):
        # -1 = "从没重启过", 跟 last_opener 的"没跑过"对齐
        task._ww_task_restarted_at = -1

    def watch():
        was_on = None
        while True:
            try:
                now_on = bool(getattr(task, 'enabled', False))
                if was_on is False and now_on:
                    task._ww_task_restarted_at = time.time()
                    if logger:
                        logger.info('auto combat re-enabled -> opener re-armed')
                was_on = now_on
                time.sleep(ENABLE_POLL_INTERVAL)
            except Exception:
                return          # 进程收尾时安静退出

    threading.Thread(target=watch, name='ok_ww_enable_watch', daemon=True).start()


def start_f_watch(task, logger=None):
    """把【物理】F 键按下的墙钟时间记到 task._f_last_press。每个 task 只启一次。

    线程是 daemon, 跟着进程退出, 不用管回收。
    """
    if getattr(task, '_f_watch_started', False):
        return
    task._f_watch_started = True
    if not hasattr(task, '_f_last_press'):
        # 【初值取 -1 而不是 0】: 读取方是 `if f_press > self.last_opener`, 而
        # last_opener 的"没跑过"也是 -1。给 0 的话开局第一次判定就恒成立(0 > -1),
        # 会连 use_liberation 那道检查一起跳过 —— 两边都用 -1 表示"从没发生过"才对得上
        task._f_last_press = -1

    def watch():
        try:
            user32 = ctypes.windll.user32
            user32.GetAsyncKeyState.restype = ctypes.c_short
        except Exception as e:
            task._f_watch_started = False
            if logger:
                logger.error(f'f watch: GetAsyncKeyState unavailable ({e}), '
                             f'the "press F to re-arm the opener" shortcut stays off')
            return
        last_log = 0
        was_down = False
        while True:
            try:
                down = bool(user32.GetAsyncKeyState(F_VK) & 0x8000)
                if down and not was_down and f_settings(task)[0]:
                    # 【上升沿才算一次按下】。原来是"只要按着就每轮记一次",
                    # 对 _f_last_press(取最新时刻)无所谓, 但下面 _f_pressed_at 是
                    # 给框架消费的, 按住不放时反复刷新会让它永远"刚刚才按"
                    now = time.time()
                    # 【宏正在跑 = 正在战斗, 这下 F 是玩家手动处决, 不是重开副本】:
                    # 手动处决的那一下 F 会打出 "opener re-armed" —— 下一次进战斗就会
                    # 从头跑启动轴。只在宏空闲时才把 F 当成"重开了一局"
                    if (getattr(task, '_three_fire_macro_busy', False)
                            or getattr(task, '_ww_macro_busy', False)):
                        if logger and now - last_log >= F_LOG_DEBOUNCE:
                            last_log = now
                            logger.info('physical F pressed while the macro is running '
                                        '(manual execution) - opener NOT re-armed')
                        was_down = down
                        time.sleep(F_POLL_INTERVAL)
                        continue
                    task._f_last_press = now
                    # 【这里是本线程和框架的唯一交接点】: 框架 CombatCheck.note_f_key()
                    # 原本自己调 GetAsyncKeyState, 判据是【低位】—— 那一位的语义是
                    # "距上次调用之间被按过", 【读一次就清, 而且整个进程共享】。
                    # 本线程 20 毫秒轮询一次, 每次调用都会把低位清掉, 框架那边就永远
                    # 读到 0 —— 结果是 watcher 一直在打日志, 而"按 F 直接进战斗"从不触发。
                    # 现在改成【一个读者】: 本线程读键, 顺手把框架要的时间戳也写了。
                    task._f_pressed_at = now
                    if logger and now - last_log >= F_LOG_DEBOUNCE:
                        last_log = now
                        logger.info('physical F pressed, opener re-armed')
                was_down = down
                time.sleep(F_POLL_INTERVAL)
            except Exception:
                return          # 进程收尾时 ctypes/解释器可能已经拆掉了, 安静退出

    threading.Thread(target=watch, name='ok_ww_f_watch', daemon=True).start()


# ==================== SendInput 左键(秧秧 1苍/1羽/第2羽 那一段用) ====================
# 框架的 mouse_down/mouse_up 在前台也是往游戏窗口投 WM_LBUTTONDOWN/UP(PostMessage);
# 参考代码的宏走的是系统输入流, 跟手按一样。为什么这一段要换, 见 YY_TAIL_SENDINPUT。
_INPUT_MOUSE = 0
_MOUSEEVENTF_LEFTDOWN = 0x0002
_MOUSEEVENTF_LEFTUP = 0x0004


class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [('wVk', ctypes.c_ushort), ('wScan', ctypes.c_ushort), ('dwFlags', ctypes.c_ulong),
                ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [('dx', ctypes.c_long), ('dy', ctypes.c_long), ('mouseData', ctypes.c_ulong),
                ('dwFlags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class _HARDWAREINPUT(ctypes.Structure):
    _fields_ = [('uMsg', ctypes.c_ulong), ('wParamH', ctypes.c_ushort), ('wParamL', ctypes.c_ushort)]


class _INPUTUNION(ctypes.Union):
    _fields_ = [('ki', _KEYBDINPUT), ('mi', _MOUSEINPUT), ('hi', _HARDWAREINPUT)]


class _INPUT(ctypes.Structure):
    _fields_ = [('type', ctypes.c_ulong), ('u', _INPUTUNION)]


def send_input_left(up):
    """系统级左键按下/抬起。返回是否发出去了(发不出去调用方退回 PostMessage)。"""
    try:
        inp = _INPUT(type=_INPUT_MOUSE)
        inp.u.mi = _MOUSEINPUT(0, 0, 0, _MOUSEEVENTF_LEFTUP if up else _MOUSEEVENTF_LEFTDOWN, 0, 0)
        return ctypes.windll.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT)) == 1
    except Exception:
        return False


class YangYangSp(NativeYangYangSp):
    """秧秧·玄翎。秧莫穗(莫特斐/穗穗/秧秧·玄翎)里她兼任【整条轴的持宏者】。

    引擎逐字移植自 ok-ww 工坊「Chisa_Suisui_Yangyang_Xuanling」（作者 楽山，v2.0.0）,
    本队的轴（BV125Yq6PEmX 教程）写在类底部的 OPENER_MACRO / LOOP_MACRO。
    轴本身的结构（哪一格接哪一格）是用户的, 每一格的【实现】用的是参考代码里
    同一类格子的实现 —— 也就是说: 表里写的是"秧e", 跑的就是参考代码那套
    "按 E -> 核对剑式图案 -> 反了才补一次"。
    """

    # ==================== 全局节奏 ====================
    A_INTERVAL = 0.12            # 0.12 是实测的地板, 更密会让空中角色打出下落攻击
    KEY_INTERVAL = 0.10
    # 【普攻必须真的按住几十毫秒才打得出来】: task.click() 那条路按不住 ——
    # BaseWWTask.click 会把不带坐标的调用的 down_time 【无条件覆盖成 0.01】, 底层
    # genshin.do_click 又是"按下-立刻抬起-再睡 down_time"。所以这个文件里所有的"点一下"
    # 都走 tap(), 那是 mouse_down -> 等 -> mouse_up
    A_TAP = 0.06

    # ---- 切人 ----
    SWITCH_TIME_OUT = 2.5
    SWITCH_KEY_DOWN_TIME = 0.02
    SWITCH_KEY_INTERVAL = 0.0
    SWITCH_SETTLE = 0.0
    UNTRUSTED_CONFIRM = 3
    TRACE_SWITCH = True

    # ---- 大招 ----
    LIB_FIRE_WINDOW = 1.20
    LIB_KEY_INTERVAL = 0.03
    LIB_READ_EVERY = 2
    LIB_ANIM_TIME_OUT = 8.0
    LIB_ANIM_TAIL = 0.15
    HUD_NO_ANIM_GRACE = 0.35
    LIB_GONE_CONFIRM = 3         # HUD 连续这么多帧不在 = 演出真的开始了
    HUD_UP_CAP = 1.0             # 按 R 之前等 HUD 在场的上限(防 fire_lib 假成功)
    # ---- 大招前的能量闸(所有 R 那类格子共用) ----
    # 【大招是能量门控不是 CD 门控】: 判据用 liberation_available()(读图标亮不亮),
    # 不是 has_cd。能量靠普攻/技能命中攒, 【干等等不来, 必须动手点】——
    # 跟穗穗的回路闸是同一类"攒的正是这一格要用的资源", 安全。
    # 【3.0 是两头的折中】: 上限一到就"照按", 后面 fire_r 那两轮连发是纯粹的空转 ——
    # 能量没满按多少下都不出手。而闸门本身等得越久, 角色站桩就越久。
    LIB_FILL = 3.00              # 图标不亮时点普攻攒能量的上限(秒), 0 = 关掉
    LIB_FILL_INTERVAL = 0.12
    R_EXTRA_CAP = 2.00           # 大招没出手时补救的上限

    # ---- 协奏 ----
    CON_WAIT_TIME_OUT = 2.0
    CON_POLL_INTERVAL = 0.05
    CON_FULL_LEVEL = 1.0
    CON_SAMPLE_MAX = 24
    # ---- 变奏那一格的协奏闸 ----
    # 【用户实机: "强化E之后攻击也有可能被打断, 要确保持续攻击到协奏满变奏秧秧"】。
    # 表里带 '^' 的格子, 协奏到底满没满根本没人看过 —— 那几下但凡被怪打断, 协奏就是
    # 不满的, '>YY^' 于是变成一次【普通平切】:
    #   · 秧秧拿不到变奏入场, 羽挟苍空那 +1 苍翎没有 —— 末尾第一步 1苍 直接打空
    #   · 框架那边却按变奏记了账(has_intro / 变奏冻结), 后面一路错下去
    # 【等的时候必须接着点普攻】: 协奏是打中涨的, 干等等不来(wait_con_at_least 自带)。
    # 【门槛必须是 1.0 不能是 0.99】: get_current_con 只有环真闭合才返回 1, 面积够了
    # 但环没闭合会被钳成 0.99 —— 0.99 正是"还差一点"的哨兵值, 拿它当门槛等于没等。
    # 【等不到也照切】: 但这时 con_full 传 False, 让框架按平切记账 —— 宁可记成没变奏,
    # 也好过骗它一次(记错了下游全歪, 而少记一次最多是这一轮保守一点)
    CON_GATE_BEFORE_INTRO = True
    CON_GATE_WAIT = 3.5          # 等协奏满的上限(秒), 0 或关掉 = 退回老行为
    # 【交给秧秧那一格单独给一个更长的上限】。它是整条轴最不能丢的一次变奏:
    # 秧秧靠变奏技能·羽挟苍空拿 +1 苍翎, 丢了就只剩 E 给的那 1 点, 【凑不满 2 点,
    # 末尾的 1苍 必定打空】, 而重击就绪图标在 1 点时就亮着, 判据完全看不出来。
    CON_GATE_WAIT_INTRO = 5.0
    # 【变奏那格的协奏提前读】: 上一格的空等快结束时先读一次, 已经满了就直接切,
    # 不在按切人键之前再花一次读屏。纯读屏, 不改状态; 协奏只涨不掉, 早 0.1 秒读到满,
    # 切的那一刻一定还是满的
    CON_PEEK_LEAD = 0.10

    FIELD_SETTLE_TIME_OUT = 1.5
    E_RESEND_STEP = 0.06
    SKILL_BAR_SETTLE = 0.40

    # ==================== 防重入 ====================
    OPENER_MIN_GAP = 60.0

    # ==================== 保底 ====================
    # 总开关。关掉 = 两条宏纯照表回放(切人不确认、大招不补按), 跟人按宏一模一样
    SAFETY = True
    # 【切人一格错, 后面每一格都发在错的人身上】—— 这是整条轴最该有的一道保底。
    # 剩下的 gap 照等, 时序一点不变; 被游戏拒绝(上一个动作/入场动画没演完)就一直补按,
    # 最多再等 SWITCH_EXTRA(游戏的换人 CD 约 1 秒)
    SWITCH_EXTRA = 1.50
    SWITCH_REPRESS = 0.05        # 没到场时补按数字键的间隔
    # 连续读到目标 index 这么多帧才算到场(特效会盖住槽位)。
    # 【这道确认是有代价的】: 宏表给切人格的 gap 多数只有 50ms, 而"按下 -> 游戏换人 ->
    # 连读两帧确认"比这长, 所以每个切人格都会晚一点。嫌慢有三条路, 按代价从小到大:
    # 压成 1(特效误判的概率上去一点) / MACRO_SPEED 调到 0.93 左右把整条表按比例缩回去 /
    # 直接关 SAFETY 纯照宏打
    SWITCH_CONFIRM = 2
    # 【变奏那一格的 gap 从"到场"算, 不从"按键"算】(用户实机: 有时候循环轴变奏切秧秧后,
    # 秧秧的 E 没接上苍)。表里 '>YY^' 的 800 是羽挟苍空的入场动作, 默认秧秧按键后 0.1s
    # 就到场。可实机两轮游戏拖了 0.69 / 0.57s 才让她上来, E 照样在"按键后 0.85s"发出去
    # = 到场后才 0.2~0.3s, 落在入场动作里被吞: 剑式没切、没 +1 苍翎, 1苍 打空,
    # 后面 1羽 也跟着变成苍剑式。正常轮是到场后 0.75~0.80s 按的 E。
    # 现在 = max(按键 + 按住 + gap, 到场 + 按住 + gap - SWITCH_NORMAL_LATENCY):
    # 正常到场(0.1s)时跟宏表一模一样, 游戏拖慢了才往后推。只管带 '^' 的格子 ——
    # 普通切人格的 gap 只有 50ms, 不是动作锁
    INTRO_GAP_FROM_ARRIVAL = True
    SWITCH_NORMAL_LATENCY = 0.10     # 实机日志: 切人键到确认到场 0.09~0.11s
    # 切人确认慢于这个秒数就把逐帧读数打进日志: 一串旧 index = 游戏在拒绝切人
    # (上一个动作没演完), 一串 x = HUD 被特效/时停盖住读不到
    SWITCH_TRACE_SLOW = 0.30
    # 【切人没确认就别假装切过去了】: 累计这么多次就放弃这一轮宏交回框架 ——
    # 乱着打完一整轮不如早点重来
    MACRO_ABORT_DESYNC = 2
    E_CD_CAP = 1.60              # 'E#'(按到进 CD)那类格子的上限
    # 'E#' 的"先见亮才认暗"那道门等多久。【默认的 0.15 太短】: 切人后技能栏要过几帧
    # 才换成新角色, 那几帧读到的是【上一个人】的 CD —— 0.15 秒内没见过"可用"就会被
    # 当成"本来就在 CD 上"直接跳过, E 一次都不发。而穗穗的 E 恰好紧跟在切人后 100ms。
    # 干跑里复现过: SuE_没见过亮(x5,0.45s)
    E_READY_GRACE = 0.40
    E_SPAM_INTERVAL = 0.06
    # ---- 切人之后紧跟着的长按, 要多等一下 ----
    # 【用户实机: "切千咲的时候会愣一下再打"】。
    # macro_switch 确认的是"in_team() 读到目标 index"= 人已经在场了, 但【在场 != 能出招】:
    # 入场动作还要演几百毫秒。宏表里切人格的 gap 只有 50ms, 紧跟着的长按,
    # 【按下沿正好落在入场动作里被丢掉】 —— 而长按又不能补按(PostMessage 重发会把
    # 已经按住的状态打断, 见 tap/A_TAP 那段), 所以只能等游戏先把入场演完再按下去。
    # 只对"上一格是切人 + 这一格按住时间 >= HOLD_SETTLE_MIN"的格子生效, 短按不受影响。
    # 【从确认到场那一刻算, 只补差额】: 切人格自己的 gap 已经等过的部分不再重复等
    # (循环宏穗穗那下 650 长按前面隔着 1000ms, 原来照样再等 0.2s)。
    HOLD_AFTER_SWITCH = 0.20     # 等多久(秒)
    HOLD_SETTLE_MIN = 0.30       # 按住多久才算"长按", 短于这个的不等

    # ==================== 烟岚窗口 ====================
    # 【这一段是参考代码里整条轴最卡时间的机制, 本队的轴目前没用它(表里没有 'WIN'),
    #   整段是惰性的 —— 但它是穗穗自己的机制(不是千咲的), 所以照原样移植过来,
    #   要用的时候在表里加一个 'WIN' 标记就活了】
    #
    # 穗穗芳菲信 600 满档延奏 -> 飞仙翾舞1 给【当时的前台角色】挂烟岚前置 ->
    # 持有者【满协奏切人】时, 变奏出场的那个人拿到【烟岚】(攻击最高 +50%, 14 秒,
    # 离场即移除)。翾舞1 在【穗穗大招后切秧秧那一下】之后约 6.06s(游戏时间),
    # 所以那一刻场上必须是想吃烟岚的那个人, 他还得在那之后打满协奏、变奏交出去。
    # 早切走白给, 晚了翾舞1 落在别人身上。
    # 表里 'WIN' 那一格之后的第一个切人起算, 到 '>YY^' 按下为止, 游戏时间(扣掉大招
    # 演出的时停)要在这个秒数以内。【超了只报警告, 不改流程】
    YANLAN_WINDOW = 6.0
    # 【翾舞1 那一刻】(帧数据表穗穗块): 秧秧变奏入场第 1F 触发穗穗延奏, 延奏动作
    # 79F(1.32s)演完生成飞仙, 飞仙第 273F(4.55s)翾舞1 —— 算上切人键到入场约 0.1s,
    # 是切人键后 5.97s(游戏时间, 大招的时停不算)。
    # 【5.97 -> 6.06, 6.05 -> 6.15】(录屏对血条上方那个烟岚图标): 启动轮 6.31s、
    # 循环#1 6.20s、循环#2 6.02s 都吃到了; 作者实录 6.11/6.13s 也吃到了。
    # 所以翾舞1 落在 6.02 ~ 6.11s 之间(按帧算的 5.97 偏早一点), 取中 6.06;
    # 持有者至少站到 6.15s 再走
    YANLAN_XUANWU = 6.06
    YANLAN_MIN = 6.15
    # 下面三个是窗口里那几格的快速版, 【只在 'WIN' 和 '>YY^' 之间生效】。
    # 切人后紧跟长按的格子不额外等入场: 切人确认本身就要 0.09~0.11s, 按下沿落下的
    # 时刻已经跟宏表一样(切人键后 100ms 按左键)。
    # 实机要是又出现"切进去愣一下再打", 往上加 —— 每 0.1 秒吃掉窗口 0.2 秒(两格)
    TIGHT_HOLD_AFTER_SWITCH = 0.0
    # 大招: 【先直接连发 R】这么久(不先读能量、不先点 A, 跟宏一样 Q 后马上按),
    # 没进才边点边攒能量, 攒能量的上限压短。
    # 实机日志: 攒得满的多是 0.10~0.35s(偶尔 1.4~1.9s), 攒不满的点满 3 秒照样 NOFIRE
    # —— 上限给长只是在窗口里白站
    TIGHT_R_FIRST_WINDOW = 0.40
    TIGHT_LIB_FILL = 1.00

    # ==================== 宏末尾那段(1苍/1羽/第2羽) ====================
    M_R_WINDOW = 2.00            # 秧秧大招连发的窗口(传给 fire_lib)
    # 【1苍 那下长按提前这么多松手, 后面的 Q、R 跟着提前】。
    # 帧数据表: 苍重击最后一段判定在第 56F, 派生帧 80F(0.4s 后, 声骸要到这里才按得出来)。
    # 参考代码当时只给到 0.10, 因为【Q 紧跟在 R 后面】—— 秧秧·玄翎的声骸输入缓存只有
    # 0.1s, 比派生帧早 0.1s 以上按的 Q 直接丢, 而且 R(表里紧跟 0.1s)会贴上来,
    # 大招优先级 10 能把刚出手的声骸打断(它的注释: "不给到 0.15")。
    # 【0.10 -> 0.30】(用户 2026-10-11: "全局中苍重接大招中间的间隔缩0.2s"):
    # 这条轴把 Q 挪到 R 之后、换羽剑式那一格了(苍 r e q 羽12), 所以卡着上限的不再是
    # 声骸那 0.1s, 而是【大招自己的 0.3s 输入缓存】。
    # 【0.30 -> 0.35】(用户 2026-10-11: "再缩0.05s"): 已到大招缓存的上限,
    # 再往上加就是白丢(按了不进缓存) —— 要再快只能动表里的按住时长。
    # 作用范围是【全局】: 每一格 'AYC'(1苍)都走这个提前量, 启动轴和循环轴一起变。
    # R 演完会读一次声骸 CD, 日志里出现 `Q没出` 就往回调
    # 【0.10 -> 0.35】(用户 2026-10-11: "苍重接大招中间的间隔缩 0.2s / 再缩 0.05s",
    # 并实测确认"苍重重击后面有莫名的平a"): 参考代码给 0.10 是因为它那边 Q 紧跟在 R 后面;
    # 这条轴的大招就在 1苍 后面, 而且重击的伤害(56F≈0.93s)和派生帧(80F≈1.33s)远早于
    # 2200ms 就结束了 —— 【按住比招式长出来的那一段, 游戏会当成持续普攻】, 用户看到的
    # "苍重后面莫名的平a"就是它。0.35 让按住收在 1950ms, 大招紧跟着上去。
    # 【参考代码原值 0.10】(用户 2026-10-11 要求回退): 1苍 实际按住 2200ms。
    # 注意: 按住比招式长出来的那一段, 游戏会当成持续普攻(用户实测"苍重后面有莫名的平a"
    # 就是这个)。四条宏的末尾现在都有 'F?' 那格(0.5~1.6 秒), 溢出在它里面消化掉。
    YY_CANG_TRIM = 0.10
    # 【R 演出结束到按 E 的间隔 —— 这一格丢了整个 R 之后就全错】。
    # HUD 回来 != 能出招, 收招还在演, E 按在这段里会被整个吃掉; E 又不像 R 那样会重试,
    # 剑式没切成羽, 后面那一路长按打出来的就是苍剑式的普攻。
    # 0.80 三处来源对上: 判据驱动旧版实机标定的 LIB_TO_E = 0.8; 实录逐帧 0.8s;
    # 宏 R 那格 5000 = 演出约 4.2s + 收招, 实录 HUD 回来到按 E 隔 0.75s
    M_R_TO_E = 0.80
    # 【等落地再按 E】: 大招收尾人可能还在空中, 重击·羽剑式的条件里明写着"处于地面时"
    M_WAIT_DOWN_BEFORE_E = True
    # 按 E 的按下时长(秒)。【别用框架默认的 0.01】: 收招那一下可能吃不到
    M_E_KEY_DOWN = 0.05
    # 秧秧那三下长按期间每隔一会儿读一次重击就绪图标, 【只打日志不打断】。这一段完全按
    # 时长走, 实机要是打歪了, trace 是唯一能看出"重击什么时候出手"的东西
    # (实机读数: 亮 = 苍翎 >= 1, 重击出手清空苍翎就灭; 湮象风华换了图案也读成灭)
    M_YU_TRACE = True
    M_YU_TRACE_EVERY = 0.30
    # 【这一段的左键走 SendInput】(实机: 有时候打不出第二个羽)。
    # 框架的 mouse_down 在前台也是 PostMessage 投 WM_LBUTTONDOWN —— 按下那一下要是落在
    # 动作里(E 的剑式切换 / 1羽 的落地)被游戏丢掉, 后面一直按着也不算数, 这一整段长按就白按了。
    # 参考代码的宏是系统级输入, 游戏读得到"现在按着", 不怕这个。
    # 只在游戏窗口在前台时走(SendInput 发给前台), 不在前台自动退回 PostMessage; 关掉 = 全退回
    YY_TAIL_SENDINPUT = True
    # 【没处决就等羽的后摇演完再往下走】(用户给的数: 0.5s)。
    # 处决的作用就是取消后摇 —— 没打成的话后摇还在, 直接进下一条宏, 第一格的 W/E 会被吞。
    # 【等的期间照样探处决】: 提示晚几帧才亮的话照按, 按了就不用等完。
    # 【不点普攻】: 后摇期间的点击被丢掉, 后摇一完那一下又会起一段普攻, 挡在 W/E 前面
    YU_NO_BREAK_TAIL = 0.50
    YU_BREAK_POLL = 0.03
    # 【打了处决也要等一下收招, 再交回去跑下一条宏】。
    # 处决那格是等 HUD 回来才返回的, 可 HUD 回来时秧秧还在处决的收招里, 循环宏开头那下
    # W/E 会被吞 —— 而那个 E 是剑式切换, 吞了剑式就反了: 后面 1苍/1羽 全错位。
    # 【0.50 -> 0】处决改成从第一下 F 起等满 YU_BREAK_ANIM, 不再是"HUD 回来 + 这么久"
    YU_AFTER_BREAK_SETTLE = 0.0

    # ==================== 秧秧的强化E(剑式流转)闸: 'EY' / 'EY0' ====================
    # 【帧数据表秧秧块"特殊能量"】: 流响上限 100、开局 100, 普攻【打中】才扣, 大招清空;
    # 流响为 0 时 E 才是强化E(剑式流转: 回 100 流响 + 1 点苍翎), 不为 0 按出来的是
    # 普通E —— 只换剑式, 【不给苍翎】。苍翎满 2 才放得出苍剑/羽剑重击。
    # 循环宏中段那个"换羽剑式"的 E 按设计是强化E(实录里那一下图标带 "^^")。
    # 它给的那 1 点苍翎, 加上穗穗大招后变奏入场的 1 点, 让后面那下长按打出羽剑重击 ——
    # 羽剑重击命中后接羽强化空中攻击, 解锁 12 秒羽强化A, 这个解锁一直带进 1苍/1羽/第2羽,
    # 【第二个羽就是靠它】。
    # 宏是按时间走的, 打没打中它不知道, 所以这里加一道闸: 按 E 前先看图标,
    # 流响没打空就接着点普攻打空, 再按 E。
    # 判据: E 图标强化态外面有一圈粉/暗红的环、图案右下角有 "^^"。逐帧量的
    # (以 box_resonance 中心为圆心, 半径按框高算):
    #   环在 0.64 倍框高处, 真环覆盖 0.73~1.00, 环外(0.9 倍)0~0.04; 普通E 全是 0;
    #   切人瞬间背景整片染红时环里环外一起红(0.25~0.46) —— 所以要求"环外不红";
    #   但强化E 也碰上了染红时, 那种靠 "^^" 认(真 0.17~0.41, 普通 0)
    YY_EX_GATE = True
    YY_EX_SETTLE = 0.15          # 刚切进来技能栏还没换过来, 先只读不点这么久(秒)
    # 没亮就点普攻打流响的上限(秒), 到了照按一次 E(剑式奇偶不能乱)。
    # 【2.0 -> 3.5】实机两局: 这一格起手流响还剩 65~70%, 点满 2 秒分别打掉了约
    # 55% / 65% —— 到上限那一刻图标刚亮, 差一帧确认就按了普通E。打空一般要 2~2.5 秒
    YY_EX_FILL = 3.50
    YY_EX_FILL_INTERVAL = 0.12
    YY_EX_CONFIRM = 2            # 连读这么多帧都成立才认
    # 【羽强化A 不扣流响】(帧数据表"核心回收"列: 苍A1 -12、羽A3 -26 ……
    # 羽强化A1/A2/A3 那几行是空的)。切人前那下 600ms 长按打出羽剑重击 ->
    # 羽强化空中攻击 -> 解锁 12 秒羽强化A, 这段时间里点左键打出来的都是羽强化A:
    # 【一滴流响都扣不掉】, 而且第三段会把解锁用掉 —— 第二个羽靠的正是它。
    # 所以:
    #   · 【流响剩得多才在长按之前打】('AX'): 那时还是羽A, 打中就扣
    #   · 【变奏后那个 E 不点普攻】('EY0'): 只读图标, 亮就按强化E, 不亮也只能按普通E
    YY_DRAIN_CAP = 1.50          # 长按前点普攻打流响的上限(秒)
    # 【'AX' 只在流响条还剩超过这个比例时才点普攻, 而且只打到这条线为止】。
    # 原来那版是"不亮就打到空", 实机 20 轮账: 进这一格时流响条剩 0.11~0.29,
    # 【轮轮都要点 5~12 下】, 花 0.85~1.64s; 更贵的是后面 —— 只要这里点过普攻,
    # 最后那格等协奏就从中位 0.8s 变成 2.4s。合计每轮多 2.5~3 秒。
    # 【0.35 -> 0.03】: 秧秧前面没 A 到怪, 流响没耗完, 该放苍的时候发呆/放成羽。
    # 现在只要还剩一点、E 图标也没亮(亮 = 流响已空)就打空; 正常轮进来就是 0, 一下不点
    YY_DRAIN_ABOVE = 0.03
    # 【点了这么久流响一点没降 = 打不到怪, 别再点】。
    # 【别给短了】: 正常打流响头 0.7 秒条也只掉 0.04(条有动画), 所以是 1 秒内
    # 一点(0.02)都没掉才算打不到
    YY_DRAIN_NO_PROGRESS = 1.00
    # 流响条在画面上的位置(相对整帧): 条从左往右涨, 空了整条换成蓝羽毛
    LX_BAR_X = (0.4245, 0.5678)
    LX_BAR_Y = (0.897, 0.9245)
    YY_EX_READ_ONLY = 0.15       # 'EY0' 只读不点时读多久(秒)
    # 【变奏后流响没空 -> 这一轮的苍放弃, 不按 E、不长按, 直接 Q R】(用户实机:
    # 前面秧秧没 A 到怪流响没耗完, 该放苍的时候发呆或者干脆放了羽)。两轮截图: 变奏后
    # E 图标是【灰暗的斜剑】—— 羽剑式下普通 E(常态切换剑式)按不出来(帧数据表: 中断
    # 优先级只有 1), 补按也没用; 这时点左键是羽强化A, 不扣流响还吃掉第二个羽;
    # 1苍 那下长按在羽剑式、苍翎只有 1 点, 打出来的是羽强化A(看到的"放了羽"),
    # 人飞在空中 -> R 按了 36~38 下才出、Q 没出, R 后那下 E 又把剑式翻成苍 -> 1羽 打成苍。
    # 放弃这一个苍之后账是齐的: 苍翎 = 变奏 1 + 大招 1 = 2, 剑式还是羽, R 清空流响;
    # R 后那格 'E羽' 读到已经是羽就不按(见 already_form), 1羽 / 第2羽 照常出。
    # 长按那 2.2 秒换成等 YY_SKIP_CANG_WAIT(让变奏入场动作演完, Q 不被吞)
    YY_SKIP_CANG = True
    YY_SKIP_CANG_WAIT = 0.40
    # 【秧秧按 E 之前把流响读数打进日志】(诊断, 只读不改流程)。看的是"这一下 E 会是
    # 普通E 还是强化E" —— 流响空(<= YY_DRAIN_ABOVE)才是强化E。用的是 already_form
    # 刚刷过的那张帧, 不额外读屏。排查完可以关掉。
    YY_LX_TRACE = True
    YY_EX_RING_K = (0.60, 0.64, 0.68)
    YY_EX_OUT_K = (0.87, 0.93)
    YY_EX_RING_MIN = 0.50
    YY_EX_OUT_MAX = 0.15
    YY_EX_RING_MIN_FLOOD = 0.60  # 背景染红时: 环够红 + "^^" 亮也算
    YY_EX_CHEV_MIN = 0.15
    # 【排查用, 定稿就关】'EY' 每一次判定(亮/第一下没亮/到上限)和按完 E 0.2 秒后, 把
    # E 图标和流响条那一小块存成 png 到 logs/yy_ex/(每张一两百 KB)。判据在实机上认没
    # 认对、E 按没按出去, 靠它对照。按完那一下还会读一次图标: 强化E 真出去了环会灭、
    # 流响回满。【定稿分享, 关掉】排查时改回 True
    YY_EX_SNAPSHOT = False

    # ==================== 秧秧剑式核对('E苍' / 'E羽' / 'EY' / 'EY0') ====================
    # 【按完 E 认一下剑式, 反了补一次 E】(用户: 偶然在苍之前放出羽 / 该放苍放成羽)。
    # 截图对出来 5 轮剑式反了, 都是【那一下 E 没生效】:
    #   · 中段那个(换羽, 点普攻打流响后紧接着按): 按完还是钩子(E 没出去);
    #     或者钩子没了, 图案却是月牙剑(还在苍剑式)
    #   · 变奏后那格(换苍): 按完还是斜剑(还在羽剑式)
    # 这 5 轮末尾都是 `Q没出` —— 1苍 那格打成了羽重击, 人在空中放不出声骸。
    # 认法: E 图标中间的图案有四种 —— 月牙剑(苍, 普通) / 钩子(苍, 强化) /
    # 斜剑(羽, 普通) / 羽翼(羽, 强化)。模板是截图里挑的, 16x16 灰度,
    # 取相关系数最大的一类: 102 张判对 102 张, 苍/羽 两边分差最小 0.063。
    # 分差不够 YY_FORM_MARGIN / 读不到 就当不知道, 不补。
    # 【补错一下剑式就真反了】, 所以: 按完 YY_FORM_WRONG_AFTER 以后(秧秧 E 的输入缓存
    # 0.3s, 被缓存住的那一下这时也该出来了)连着两次读到反才补, 只补 YY_FORM_FIX 次,
    # 补完还不对只报不按
    YY_FORM_CHECK = True
    YY_FORM_MARGIN = 0.08
    YY_FORM_MIN_SCORE = 0.60
    YY_FORM_WRONG_AFTER = 0.45
    YY_FORM_WINDOW = 0.80        # 按完之后最多看这么久(秒), 补按之后重新计
    YY_FORM_FIX = 1
    # 8 张 16x16 灰度模板(uint8, base64): 月牙剑 x2, 钩子 x2, 斜剑 x2, 羽翼 x2
    YY_GLYPHS = (
        'AAAAAAACBwgKCQUAAAAAAAAAAAIKEhISEhITDgoAAAAAAAQRGyw9JBMRESQ6CwAAAAIXPVRTHRETFBNGORIHAAAR'
        'SVhUMREQExY0QCAjDwEDP1dANxMSKENEUBsSKRMHGFRWJRMSESc+N04kEhwcDSJITRYSExIpPjM/MREVHAwoNSwS'
        'EhQYPis6KSASGBkNHCsfEhIUJig/GBMTEhgSDA8lHRQTJi82JBISESMeEQgAHRYeFzwlNRMTEhU5FBABAAwjHDYn'
        'QiAfJjgqExQLAAAAFjE2NS08RkYpFBQRAQAAAAAbMTwWFBQUExINAQAAAAAAAAMTHhIXFhACAAAAAAAAAAAAAwkJ'
        'DAoGAAAAAAAAAAACDBQWFhUVFxEKAAAAAAAFFR0vQSkXFRUoPg0AAAACG0JXVyMXFhYXST4ZCQAAE01hWDIWGxsY'
        'O0glKBYBBEVdQzoXFCpIR1MeFS0aChpXWysYFhkrQj1SJxYgIBEjTlEbFxQVKEA4RDYWGSAPKjktFRUVGUEuPy0k'
        'FhwcEBwsIhYWFygrQhsVFRUcFg4PJR4WFyoxNygWFBQnIhQKAB0YIRo+JzcVFRUYPBYSAQAMIx04KUMhHyk7KxQU'
        'CwAAABYyNzUtPUdHKxYUEwEAAAAAGzE7FxQUFhQUDQEAAAAAAAADEx4TFRgTAgAAAAAAAAAAAA84Nkc6IQEAAAAA'
        'AAAADEp5fXt5eX5dIQAAAAAAGHJ6dnRxb25ubnc5AAAAC2mLhm94gHppZ2hocCoAAD1tr5psZWh+qraEZGRfBApe'
        'lNG8emBfXmCM369nYiglYGLJk2BfXV1cXZ7zp2BFJF1l0J5cXFxbW1qT4eiAPytZZc+xV1dXWGBvou70lEYiV1/R'
        '04qKdHZxmsT+4Zk6E1ZW2Mjkr4R9mr7f+9Z0KwE7VMa36IiZo9PMiaKkSwYAFFJ85uOxyPTNoci3VCoAAAAjULH9'
        '3//9npxwiVQDAAAAABpLuuH9+8KNx00DAAAAAAAAAiF2pWxEcwwAAAAAAAAAAAAKJiYxKBcBAAAAAAAAAAk3V1xf'
        'X2FjSRoAAAAAABNWXl5eXl1fXlthKwAAAAlVa2teaW9pXFtbWlwgAAA0YJWKX1hfc5yhd1paUAMKVoO9s3FUVlZb'
        'h8aZYVwkJFxexotSTlJSVFWV1oVfQiRYXs+ZU1BPUFFSjs+zckEsV1/OsVZST1lcaqHkw4BKIlNW0NKKjXJ3cJzH'
        '98J/PxRUUdbG5K+GgZ/A3++tai8BO1TGuumPnqXTzImYklIHABVYgufkssn0zaDFo10uAAAAKly1/eD//Z6ebHZN'
        'AwAAAAAeVbvc9/G7gJNDAwAAAAAAAAMlcJVtR00JAAAAAAAAAAAABBEQFBAKAAAAAAAAAAAEFCQoIyQmKBoJAAAA'
        'AAAIJCYlIiEjISEgJBIAAAAKRygqLCgkISMhICMpDQAANmdPKzMnJiMkKiMiIR4BBC9eaE8pJig1QzojIyIkDhEr'
        'M2BmTSkjL0Y7LiIjIhgOLyowX2dIIyYkIScrJiIYDSMhITJgZ0UlIyQjJSYlHBEkICMpNF5lSSUiICIiIhUHIiIu'
        'LygxYGREMiMiICARABQfST0iIi5fYk0iHR0cAgAIKEY3IB4gUU04JRkZDgAAABEfMR8eHj8kN08fEAEAAAAACh8f'
        'HB8gIB4yHAEAAAAAAAABCRMTGBYQAgAAAAAAAAAAAAUSExgYDQAAAAAAAAAABBorLS8uNTUkDAAAAAAACCguLSwt'
        'Ky4qKC4UAAAAC0wwMTcwKywqKissMBAAADptVS82KywuLTAsKigmAQU1Y21SKy0uOklCKicnKBASLjZka1IuLDhP'
        'QzMoJyceEDgxOGVsTy0yKystMCgjGRQwLy03Y2lPKicmJyclIx4SLS8sKDRfZUUmJikpKCgbCi0sMS0kL1xlSjoo'
        'JycnFAAdKE5BISA0Y2lXKyUmJAMACzNMOyIjLWFVPS0kJhYAAAAWJDQoJydFKDtZKxoBAAAAAAwnLSonKSkmOCQB'
        'AAAAAAAAAQ8cHCEbFAMAAAAAAAAAAAAJHyApIxkBAAAAAAAAAAcsRUdFRkpUQh0AAAAAAA4/PTg2NDQ4P0dXMgAA'
        'AAY5NS4sJycoKC42UnMmAAAjMycgIB8fICE2kcBeTAMGMSgfHB0fMzmZ6fWIOEcgJ1hQUVZegXrQ1f/OKy5AOEW2'
        'qIB9p2ul1N/OSR4nNjIxUjY9wz44t7tyURwdJDM2DyAcsWYbYtt/HxwZGiQyLgggL8knQMHXWyobGhgiMyMAFjCb'
        'Jqhppy4yGFcfJjQFAAcmdYFfKYEZP3i2nTMfAAAAJWNWHFQjI0mAR2hAAgAAAAAbGCMgGlNhYK47AgAAAAAAAAEL'
        'FB9gNWMKAAAAAAAAAAAACicnNisVAQAAAAAAAAAHKkJDQkRMWkYbAAAAAAANOzkyLi0vNDxFVS4AAAAGNi8oIiAf'
        'IiQrNFFxIQAAIC0jHhoaGRscMY6/WUQCBisiGxkZGi00l+j0hjRGHSdXTk1TWn93ztT/ziYrPjVFtad/e6ZppNTe'
        'zUccJDYyMFAyO8I8N7a6cVEYGiEyNw4fGq9jGmLbfR0bGBohMi4IHzHJKEDB11sqGRcaITIjABYwmianZ6ctMhdV'
        'ICYxBQAIJHCBYSmBGT94uJ40IAAAACZlVx1WIiRJg0xrQgIAAAAAHBolIhhTY2ewPgIAAAAAAAABDBYgXzNjCgAA'
        'AAA='
    )

    # ==================== 穗穗大招前的回路闸 ====================
    # 【用户实机报的】: "穗穗在启动轴里没有打满回路就开R了"。
    # 宏是照表按时间走的, 表里给穗穗攒回路的那几下 A 够不够, 取决于打没打中、有没有被
    # 怪打断 —— 宏本身给不了任何保证。满不满读 suisui_forte3 这张图(芳菲信 600 那一档),
    # 阈值和确认帧数都是从判据驱动旧版搬过来的。
    # 【等的时候必须点普攻】: 回路就是普攻攒出来的, 干等永远等不满。
    # 【这一格会把后面整条宏往后推】—— 等多久推多久, 跟切人确认是一个性质
    FORTE3_GATE = True
    # 【3.0 -> 6.0】(用户: 穗穗有时候被打断太久, 三段回路没满也开大了)。
    # 实机循环轮里 4 次 `三段回路 3.0s 没攒满(点了 23 下 A)`。三段回路 = 芳菲信 600,
    # 没满就放大招, 这一轮的第3次翾舞一定没有。这一格在烟岚窗口之前(参考那边),
    # 多等不挤窗口, 只是整轮往后推
    FORTE3_WAIT = 6.0            # 等的上限(秒), 超了照放不误: 少一档好过把整轮宏卡死
    FORTE3_THRESHOLD = 0.75      # 旧版标定的值, 注释写着"原来 0.6 太松会误判"
    FORTE3_CONFIRM = 2           # 连读这么多帧都命中才认, 单帧误判不算
    # 一下普攻都没点就读到"满", 而且快于这个秒数 -> 记一笔(只报不拦)。
    # 【循环轮里这是常态, 不是误判】: 穗穗前两段上场已经攒满了
    FORTE3_SUSPECT = 0.30

    # ---- 穗穗的强化E(醒春潮) ----
    # 【用户实机: "启动轴里穗穗的强化E 有时候回路条没有满, 就会放个普通E"】。
    # 表里那一格原来是 'E#'(按到技能进 CD), 而【普通E 一样会进 CD】—— 那个判据根本
    # 分不出放出去的是哪一个: 按完就走, 冷却却是实打实吃掉了, 这一轮穗穗进不了濯雨时。
    # 后果不止少一次强化E: 她没进濯雨时, 资源条显示的就还是【水云息】而不是【芳菲信】,
    # 后面 R 那一格的 wait_forte3 读的是错的那条, 会误判成"回路满"直接放大招。
    # 【判据换成 suisui_e1】: 那张图是 E 图标的强化态图案(标注框就在技能栏那个位置),
    # 亮着 = 醒春潮就绪。原生 Suisui.try_e() 用的就是它, 而且是【按到它消失为止】——
    # 消失才等于强化E 真的放出去了。
    # 【没亮就先点普攻攒回路】: 回路是普攻攒出来的, 干等等不来。
    SUI_E1_GATE = True
    SUI_E1_FILL = 2.50           # 图标不亮时点普攻攒回路的上限(秒), 0 = 关掉
    SUI_E1_FILL_INTERVAL = 0.12
    # 【上限到了还不亮就干脆不按】(跟千咲那边"照按一次"相反, 因为诉求正好相反):
    # 用户要的就是"别放普通E"。而且这时候按不按结果差不多 —— 两种都进不了濯雨时,
    # 不按至少把 CD 留着, 穗穗后面还会上场。翻成 False 就退回"照按一次"
    SUI_E1_SKIP_IF_NOT_READY = True
    SUI_E1_CAST_CAP = 1.50       # 按到图标消失的上限(秒)
    SUI_E1_KEY_INTERVAL = 0.05
    SUI_E1_THRESHOLD = 0.80      # find_one 的默认值, 原生 try_e 也没改过

    # 处决。【只在两条宏的最后一格按】('F?')—— 处决带全局时停、动画期间 HUD 整个不在,
    # 按在别处会骗过大招/重击的 HUD 判据
    F_BREAK = True
    F_BREAK_ANIM = 5.00          # 按完等 HUD 回来的上限(处决动画时长因角色而异)
    # 【处决不走框架的 f_break()】(用户: 循环轴里最后一个羽打完衔接下一轮总是有点慢)。
    # f_break() 是"按 F + 点左键"每 0.2s 一轮, 至少 0.5s、提示还在就一直按,
    # 后面再等 HUD + 收招 —— 第2羽 打完到下一轮第一格要 2.3~2.6s; 那一路左键还会让
    # 秧秧在处决后多砍几刀。帧数据表秧秧的谐度破坏是 90F(1.5s)。
    # 现在: 只按 F(提示没了就停, 最多 F_BREAK_PRESSES 下), 从第一下 F 起等满 YU_BREAK_ANIM。
    # 等短了循环宏开头那个 E 会被吞 —— 那一格有剑式核对(见 YY_FORM_CHECK), 吞了会补
    F_BREAK_PRESSES = 3
    YU_BREAK_ANIM = 1.60
    # 【尾巴中段那一格('F!')等提示出现的窗口】。'F?'(宏最后一格)只在 YU_NO_BREAK_TAIL(0.5s)
    # 里探 —— 那一格的本意是"没处决就等后摇"; 而尾巴中段(羽2 -> 换苍 -> 处决)是要真按出
    # 处决的, 提示可能要到换苍那一格才亮起来。有提示就立刻按, 这个窗口只在没提示时花时间。
    F_BREAK_WAIT = 1.20

    MACRO_SPEED = 1.00           # 整条宏的速度系数, 1.0 = 照表

    # ==================== 链数判定(4r 单轴版已停用, 函数保留备查) ====================
    # 【用户 2026-10-17】: 4r 只有一套轴 —— 不读苍重击图标、不分 0/2 链, 入口强制先切回秧秧。
    # 下面 detect_yy_chains() 与判据常量保留备用(参考代码的原始判据, 见历史注释)。
    # 读的就是 is_mouse_forte_full()(框架的"重击就绪"找图, 模板 'mouse_forte');
    # 参考代码 M_YU_TRACE 用的是同一个, 它的实机注释: "亮 = 苍翎 >= 1, 重击出手清空苍翎就灭"。
    # 【只在开局读一次】: 战斗中这个图标是动态的(重击出手就灭、湮象风华换了图案也读成灭),
    # 所以判据只取第一次出手之前那一次读数, 之后记住结论。
    YY_CHAIN_CHECK = True
    YY_CHAIN_CONFIRM = 3         # 连读这么多帧都亮才算 2 链(挡 HUD 渐入/单帧噪声)
    YY_CHAIN_GAP = 0.05          # 每帧之间等这么久
    # 【排查/兜底用: 强制指定链数】None = 自动按图标判; 0 = 强制 0 链轴; 2 = 强制 2 链轴。
    # 自动判据要是认错了, 先把它设成 0 或 2 顶着用。
    YY_FORCE_CHAIN = None
    # 【"亮"到底看哪个读数】(用户实机: "0 链秧秧开局被认成 2 链" —— 判据选错了):
    # 血条右边那一小块(屏幕约 60%, 92%)有三套读法, 含义完全不同:
    #   · find_mouse_forte()   = 模板匹配, 问的是【图标本身在不在】—— 它一直在, 所以
    #                            0 链也能匹配上, 拿它当"亮"必然误判;
    #   · is_forte_full()      = 量那一块的【白色占比】—— 图标"填满/变白"才是真的亮了,
    #                            框架自己的门限是 > 0.08;
    #   · find_e_forte()       = 同位置的另一个模板(E 型角色的版本), 只打进日志备查。
    # 所以判据用白色占比。三个读数每帧都打日志, 认错了直接看日志里的数。
    # 【真正的判据: 普攻图标外那圈紫环】(用户 2026-10-11 截图对比):
    #   左边(2链及以上)普攻格【有紫圈】, 右边(0链)是【灰的】—— 两张截图量出来:
    #   2链紫环像素 1319 个、0链 0 个, 干净利落。
    #   环心 = E 框(box_resonance)中心【往左两格】(步长 = (box_liberation - box_resonance)/2):
    #   用户截图上算出来 (0.747, 0.895), 实测环心 (0.7455, 0.8929), 误差 0.002;
    #   环半径 = 0.76 × E 框高(截图上量的)。
    #   用框架自己的框算, 所以换 UI 缩放/分辨率都不怕。
    YY_CHAIN_RING = True
    YY_CHAIN_RING_K = (0.68, 0.72, 0.76, 0.80)   # 环的采样半径(× E 框高)
    YY_CHAIN_RING_OUT_K = (0.95, 1.00)           # 环外的采样半径(用来排除"背景整片发紫")
    YY_CHAIN_RING_MIN = 0.25                     # 环覆盖率过这条线 = 有紫环
                                                 # (用户截图上实测: 2链 0.458 / 0链 0.000)
    YY_CHAIN_RING_OUT_MAX = 0.20                 # 环外覆盖率要低于这条线
    YY_CHAIN_RING_STEP = 2                       # 普攻在 E 左边第几格
    # ==================== 莫特斐: 按 Q 之前把协奏打满('Q^') ====================
    # 【用户 2026-10-11】: "莫特斐加个机制, 按q(声骸)前若协奏未满, 则平a和e都连点直至
    # 协奏满了再按q切秧秧"。下面紧跟着的就是变奏切秧秧, 协奏不满就拿不到变奏入场
    # (秧秧的羽挟苍空 +1 苍翎就没了) —— 所以先"平a + E 连点"把协奏推上去, 满了再按 Q。
    # 【E 也连点】: 共鸣技能的协奏收益比普攻高得多, 而且在莫特斐自己的回合里, 不影响别人;
    # E 在 CD 里按是空操作, 连点没有副作用。
    # ==================== 宏开头等敌人回来(转火/轮次切换) ====================
    # 【用户 2026-10-15 实机】: 转火(杀了一只又出新一只)那 1~2 秒里【游戏不收输入】——
    # 日志实证: 切人键连按 1.6~1.8s 都没确认("游戏在拒绝切人"), E 连补两次都不亮,
    # 而且那段时间【角色看着就是站着不动的】(所以"派生只有 0.5s、1.5s 够了"这个判断
    # 不成立 —— 锁的不是派生, 是轮次切换那一段)。W/E/A 这种单发键丢在里面就没了
    # (游戏输入缓存只有 0.1~0.3s, 不排队), 这就是"走一步ea 打不出来"。
    # 对策: 开表之前先等【场上重新有敌人】(框架自己的 has_target), 到了再跑第一格。
    # 正常打桩/敌人一直在场时这一等是 0(一次读屏就过), 只有转火那一下才真的等。
    MACRO_WAIT_ENEMY = 3.0       # 等敌人的上限(秒), 到点照跑, 不把宏卡死
    MACRO_WAIT_ENEMY_POLL = 0.10 # 探测间隔
    MACRO_WAIT_ENEMY_SETTLE = 0.30  # 真等过之后再多等这么点(刷怪动作/轮次横幅收尾)

    Q_GATE = True
    Q_GATE_SETTLE = 0.10         # 【满协奏后垫一下再按 Q】(用户 2026-10-16): 闸门最后那几下
                                 # 普攻刚点完, 立刻按 Q 容易被吞 —— 等 0.1s 再进 gap
    Q_GATE_WAIT = 3.0            # 等的上限(秒), 超了照按 Q, 不把轴卡死
    Q_GATE_KEY_INTERVAL = 0.40   # 连点 E 的间隔(读协奏不便宜, 别太密)
    Q_GATE_POKE = True           # 一边等一边点普攻

    # ==================== 秧秧长按(AY): 重击出手了就提前松手(用户 2026-10-11 "仅做1") ====================
    # 【为什么】: 重击出手之后(图标灭), 还按着的那一段每一毫秒都会变成【溢出普攻】——
    # 就是"羽重打完后还在 a"。连读两帧确认灭就松手, 把这一段省掉。
    # 【为什么必须连读两帧】: 单帧误读就提前松手 = 把正在蓄的重击打断(参考代码实机
    # 12 轮栽 10 轮), 代价比多按一会儿大得多。
    # 【为什么"至少按了 HOLD_EARLY_AFTER 才允许松"】: 重击出手本身要约 1 秒
    # (参考代码实机: "1羽 在按下后 0.97s 打出来"), 在那之前读到灭多半是误读。
    # 【为什么留 HOLD_EARLY_MIN_LEFT】: 一次读屏几十毫秒, 太靠近标称时长反而把松手推迟。
    # 【为什么必须见过"亮→灭"的跳变】: 本格从没读到亮(图标被特效盖住 / 进来时苍翎就是 0)
    # 就不许松 —— 那时"灭"不是出手信号, 松了会打断正在蓄的重击。
    # 【只用在 AY 上】: 'AZ'(穗z/秧z) 那些短长按不走这条; 判据("亮 = 苍翎 >= 1,
    # 重击出手清空苍翎就灭")是秧秧标定的。
    # 【已知的坑】: 参考代码记过"湮象风华换了图案也读成灭" —— 第2羽(湮象风华)那格的
    # 图标在重击出手后本来就是灭的, 如果发现第2羽被打断/伤害掉了, 就把这个开关关掉,
    # 或把 HOLD_EARLY_AFTER 调到 1.5 以上(那时 1羽/第2羽 都过了重击出手点, 也就都不提前松)。
    HOLD_EARLY_RELEASE = True
    HOLD_READ_EVERY = 0.15        # 按住期间读图标的间隔(读屏不打断按住, 只花 CPU)
    HOLD_EARLY_CONFIRM = 2        # 连读这么多次"灭"才松手
    HOLD_EARLY_AFTER = 0.80       # 至少按了这么久才允许提前松(重击出手要 ~1s)
    HOLD_EARLY_MIN_LEFT = 0.30    # 离标称时长只剩这么多就不动了

    # ==================== 苍重/羽重图标: 读【普攻按钮】那一格 ====================
    # 【用户 2026-10-15】: 提前松手要看的图标不在框架 mouse_forte 的位置(那是血条左边
    # 的电池表, 0.600w), 而在【普攻按钮】上 —— 就是链数检测用的那一格(0.747w/0.895h,
    # 2*E框中心 - R框中心)。苍翎>=1 时按钮上是【亮的白色大图标】(苍重=剑 / 羽重=燕),
    # 重击出手清空苍翎后变回灰的普攻图标(漩涡): 用户三张截图实测白占比 0.18 -> 0.00。
    # 【换分辨率不会误判】: 中心靠框架框推、半径按 E 框高取倍数, 全是相对量 —— 4K 一样用。
    # ==================== 重击蓄力光圈(紫圈): 松手/补按的真判据 ====================
    # 【用户 2026-10-15 视频 202610152113.mp4 实测】: 重击按住期间按钮上的【白图标会反复
    # 闪灭】—— 0.5~3.0s 里白占比在 0.00 <-> 0.25 之间来回跳(图标被染成品红在呼吸),
    # 而【品红光圈一直在】(环覆盖率 0.33~0.79); 3.30s 光圈消失(0.00)才是重击真的打完。
    # 所以白占比不能当"出手"判据(实机日志 21:12:33 `Ya左键4.30 ... 提前松手 1.02s`
    # 就是这么误松的, 把羽重掐掉了), 真判据是【光圈】:
    #   环覆盖率(HALO_K 半径取最大) >= HALO_MIN  = 还在蓄/派生 -> 继续按
    #   连读 HALO_CONFIRM 次 < HALO_MIN          = 打完 -> 可以松
    # 【2链账号】: 2链那张截图在同一半径也有紫环, 分不出是链环装饰还是蓄力光圈 ——
    # 所以这套默认只对 0 链账号生效(HALO_ONLY_0CHAIN); 2链那边维持原样。
    HALO_RELEASE = True           # AY 的提前松手: 改成"光圈没了才松"
    HALO_ONLY_0CHAIN = True       # 只对 0 链账号用光圈判据(2链同半径有链环, 分不清)
    HALO_MIN = 0.20               # 环覆盖率过这条线 = 光圈还在
    # (光圈不再当松手判据 —— 用户 2026-10-16: AY 松手只看形态, 见 YY_GLYPH_*)
    HALO_K = (0.60, 0.68, 0.72)   # 采样半径(× E 框高) —— 视频剖面的峰在这三个上

    # ==================== 图标形态: 剑锋(蓄力) -> 月牙剑(打完) ====================
    # 【用户 2026-10-15 两张截图】: 蓄力态 = 品红光圈 + 里面那把【剑锋(X 形剑刃)】;
    # 打完态 = 无光圈 + 【月牙剑】图标。松手就发生在【从剑锋变成月牙剑】这一刻 ——
    # 只看"光圈没了"会在光圈闪灭的空档上误判, 加上形态确认才稳。
    # 模板从【实机录像】里抠(取按钮中心 0.50×E框高 的一块、5 帧平均、缩到 64x64 做
    # 零均值/单位方差), 以 base64 PNG 内嵌, 运行时解码 —— 不需要外部文件。
    # 【别再用手抠截图当模板】: 之前那版从截图抠、抠图范围超出截图被边缘填充污染
    # (把紫环也带进去了), 判别分差只有 ~0.15, 会把"月牙剑"读成"剑锋" -> 松不掉手。
    # 现版录像实测: 剑锋段 A≈0.99/B≈0.01, 月牙剑段 B≈1.00/A≈0.00, 分差 ~1.0。
    YY_BUILD = '1.0.0-4r'            # 构建号(跟 team.json 的 version 对齐) —— 启动自检会打出来
    YY_GLYPH_GATE = True          # AY 松手【只看形态】(用户 2026-10-16)
    YY_GLYPH_MARGIN = 0.12        # B 分 - A 分 >= 这么多才算"变成月牙剑了"
    # 【为什么是 0.12 不是 0.05】(用户 2026-10-16 视频 提取图片(1).mp4): 蓄力中途有
    # 0.1~0.3s 的假 B 闪(3.8~3.9s 那次 B-A=0.08, 8.3~8.5s 那次 0.06), 0.05 的门槛
    # 会把它当打完; 真打完(9.8~10.1s)那段的 B-A=0.16。0.12 正好把假闪挡掉。
    YY_GLYPH_CONFIRM = 2          # 连读这么多次"月牙剑"才松手(0.30s, 要短于月牙剑窗口)
    YY_HOLD_EXTEND = 0.5          # 【标称只是最短】(用户 2026-10-16): 形态判据的权限高于
                                  # 计时器 —— 剑锋还在蓄就继续按, 最多按到 标称+这么多秒
                                  # (用户 2026-10-16 改成 0.5: 只留半秒宽限, 超了就按标称收手)。
    YY_GLYPH_R = 0.50             # 取按钮多大一块做匹配(半径, × E 框高) —— 0.50 在
                                  # 光圈(0.60~0.72)内侧, 模板也是按这个半径抠的
    YY_GLYPH_A_B64 = (
        'iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAAAAACPAi4CAAAIa0lEQVRYCXXB226d6UHG8f/zfmvjXZadxM7ETmJPmiHTTEsZUSo6qpBGvQNuAttDBUftUXvAHSBx2p604ipAQqJFQnAABbUMk85k2oljO96s/ebbvO/Dt+zYmdHQ308/qlJRJdnGzIma+X0sgRRaLVFVSD+oUkzYgKmJmvm9jBBSlrUzV6X018nGYF4zV0xNXDFzQoiw0JKrSt9LgLlgQGCumTkZmdeEQK1GI6PUXxrMJQMCc80IC3NFpiZAjdBoZUkfgMHii8znmSsyl6SM0GoG7fNFMnOWec3UhBGWmZMChOai9kGAZUTNyKAkc80gaiYohlJZsIJJhKytfZAgCgkMFhgLjMznCFJKLbR4o7Wg4XBaEVraB4UAQWYuS1VEyfy/QrO6c381S1VR5rNuL1fQXshCFrK1IDGXxbLKp0UpQBaYC6LWunX3ThbzWVlVEc26/YT2mjfbhMaS7LIoS+TkqowRO4GRBTg1TGd9/VaWium0iCnGIA/OEvqLjdtNQghxnBd5WTInZJJtDAic3Lpx687tRQ8GZao5RlIYniDtP2kkJEbn4wQYc81cMmFxdWdzIR8Oi0YVU7KdUtLgBOn7fzyeCU+PplECMyfMNSW1O5tvdcYnQ4JTUUQk4cTgFPQ3T4YzuXrZLzMSBsQX2Kmz8+jh88PSQTE/KYsqW1xcwtHDXkA/We3nUDzLzTVxTa6Wd57cHT515mLS600DNTXvdKrkwanQT2/0ZpA/jZgr4lrG2p/eGb+cJvJRf1xGC4wbtzZclMM+6O9vnk4g/19jc0WYS613t7LZeObZoF/OSiMwdmNpJ42nkwnoZ1uHI8g/SthcEUaGxq3H9/N+XuWT8+mMZCwwdpa9XQ6mswLr777W7ZUqn3eDzStiztnSxvbm5GxWFcP+0CBshDGN7O3eMC+j0Q/f9+koefKREq+IOYXOve1O98TT8Wicc8FcsNrthwfjMhr0g+92eqc51bNxhTBzAtxe3bnfeBm7+fm4ilwyl9Ra3fjdNNmW/nbzYTo+S+HlQSEwcwLCynsbvdPKz09LC4ER5oK9eC8eFaamf/z3b94dvjhrpo+HEQzCSFnrz4ujcRo9n2EMwlxzWLl/0q8Mln483r63NH5x0hy/6MdAFaJq2dZ3D0azcbdbJb7MWv7KhzEBln74jd7mTjY67Jajk34ihRTMjYfvDLqj3nCSY/Fljc7SCxuw9L1vN7ONN9Loeb/sno9KhBtrD7Z5OegOZimC+JKw1OnNbMDSB5vfDNndduoe98aD82HMYO3NezocnQ1zk0BckbnUWFk8AgNGH6TvbLfaK+jsqD/qnk0UOtub4aR/MowJDIhXhJGB5iJ9UTNo32vvPl6W8PjodHh+Pmo9fpCOeqd5Za6JOQGm1mrOogwYtIe23v0qoFSeH3T9ITebMR8USka8Ir4ghAoZMGgPtPXu48wgz44/m346SAFbidfEhRAcDcIIjIy0i9x68K2NlpBTOfv4qNubGTAGmTkxp86t6iCCDOIV7SLUvvNHX2kwl4bdwxdnk5Qw5jVRayyvb/5qGI1lUTPSLgiaW994swXIzvtnx0f9URIYZF4RuNHZXn92OAHEnJF2QUDYemdnJQjsmPeODo+HlZkzV2QIi+81fvu7kRBzRtoFBJTrX390swlGrsanhwdnswQYzCUZzPr7/M8nM0CAkXZlQEQW//CdtRY14Wp08PHJuLLkZBvJIhBReu9r/V9+nBCmJu1yIeTNB8vtu08aUiUhx97xsxfTdmc6KquoVkTUlPL779/76BcDKTEn7crMFWubw/Nw6zs7BGHAZdH99Olg7a3Dk1nCc6ER1PiTJ53+r/+1skBG2uVCqN7uDorY6Kx/e70JwnKqZqPPnk7W7i0c/sapjK2NR2+F1GmF6tk/jDNbCLTLBd2fDguT1Lj74OFGQ8EypDTtvTydttZWi5dH07L91p81Uubk43/51LJAaFcG1O50K4NNduPO1ubtZQMypEnvbJiWOu2irFh9kFnJ7v/y31JAgLRnwGEprzA1Qehsbt5dbwphwHn/fLq4erMVQIDt4a9/7oBB0p4Bq1nwOdny3T94Y6mVCQNJzAbF6lIm5ux0/h//pYRB0i41A8LMGYSr9tfvra+2AxhLiYw5A07x4J9fhohB0i4XzAUjU0uBuLD11UdLEpbBIVmBmu38k38aZRiQtIuCk2wHbF4xNbG4862tJIS5YGopuTz9zw8NQkG7OFtb91PZBjFnzAU1l2/vPFrNwNQM2DE5Fee/+nSWNLeLQ3th+WF5ejyJRiBsg4FULWar6zvbawFMzTjFFGNKx//9ckawtAuC1lZnlXG/24+psdCsJpWZS6nR3Li3/cYNLAOGlGJMVUyTz552U0DaA+Pkm/c3OmHSnwxyNxdaRZFXhsZKu3PrjU4rMxhbSTHFFMu8mM0+PK6EtGcwCWed7Qfrner0bBBv36GYzhK0N5Y7CLAwyYrOnVIxHExmCwenOUh7Bmy5trL9+PZqltKsWFjJMNeMMCYWw4Ht4fHpue+PxiVIe5iaa4HE8vtbnQwhPs+AiVVx9otD5hxCZhukPcBgG0NsFgsbjx5vgAWISwaMJ7/5+UgSICspCGXax9SSMWBZWXNhaf3NzeWAqAljVKbxJ789O3eGQKAkyVrUPqZmGzA1y2FpZXlhYbWz0gmZlGJVds+7026/jMESCGQFhayjfUzNxoCZM8EKzaWF9oKaQa6qajydltEgI4EQCqG50NY+GIzB1AxYJBlBUiaRkkFGoiYJCRSy9nLSPhgMpmbAGBFs5iyuCQRCQqBGs9Uq9YFsAwZTs5mzzKVgXpEUZGoJS1m7HaqZ/qoEDKZmMOaSARkJg4yCwOaCQrPZDDEv/g9tvDQ6cyLbCwAAAABJRU5ErkJggg==')
    YY_GLYPH_B_B64 = (
        'iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAAAAACPAi4CAAAK1klEQVRYCVXBR3Bc92EG8O/7v/f2bcGiEGUBohIEQIggVKlmSaFka8axY58944MPlC3TySGHXHJ0zrllUpzJ0UlmMhlPHI9syRnT6oUSCctgARtAgugLbMUutrz3/l92wRLl9+NfQFJkjSAAROh4ic7+zNEYm9nbd2uWtAAECIfSZ4YRhpWhnzclCOKfw1oJhIQWfu1IyjPG8bC1tFkNKRFCi9Ai8Pn54lJxdG7r9xIgiD+RFSAARDIzluqLOUZAsLK02wAh4T4BVoS+O7bxh/z0c1cuGBCQ+GNIgACmMwNH+n2iLch9stMkKQj3CbCSvO/1lW7VJnp/f48EAfFNSGiJDQ4O97gOiBa7/8eroQAKDwiAJG/o24moaFP5txsCSYA/AgTQPzrX7xP3qbb60QHxFUKb2PvsDBDVK7n3QxGGBH+IFvpjpzuNQLQQwebFzZAgHhHalJx6xZHK2/XuhXWQNATfgCH8sW/gPhmIxaUvDxwAxCMCEHnHX01aU/7szviZ4D+qIA3JNyD2z814AARGUQwMlxd2IlcA8YgARMPPTFLhhRuV5NTLm++XIxhDngUzj035aFPzIO1Qu1euhzIWIP6fnpMn44hufbkXMfXU/BfLpZAOeRa9Jyc7ZAAqKJcmDKpL1wsCJRBfxVOP9xhU3l1vUObIt/D53ToN+UZibqYbIETtbPeOmPDGUjYUIICEiI50h9vcqg6nZkZdBp9drwGQM/XczuImjOGbM6d6HUAUqjf2nuuJ1he3GhAggo6X7Pa7k7GYspuz6e6Egp13akSLnDOZa0sNkn/98oAnQATuXtHr/tYftuuCAJGmY7g/0+EeVJHuXE3HfTcqfnErMgQEjp7ev7ol8udTMQKQUbhwffDr+x9vBpLQIhMb/xNWu+vlapQa3iik+1Lh5js1GNz3Uub2IsDPDYkWRpULa8efWfjSkQRAgPHGX75577VOI2v54dOu5wVbv2Ik4tDRJ6ufNcUFiZQM8fFyrLO0ixYBkCP0z/S8pRdH4Hez+a99LwygsvxhSBBtcp8fuH5DXICiyLhA+MFd6wQBIEBokclMeh81ep3xE30H793sfHXMs7kLK2gTJTNzvPyJuICgwbgBNz7NChAAARAE9hwfeAcvVoZGtXMB3Y8PmEYpfCuwQpucvpPx/xEXUIoSccJeuFkBIAoQILT4E/MLldeViOXXO2LxnpjKO70fbYVCm3UTc33viJeibb/bhQl/vRMAEiFAgAixd0bObEL5le2RVKbD2INtU/m8BgiAnNhjmfMhL5Zy3UeMTOOXBQtBgAAIbXI6hqcHY42Vq8XK2LODgKnkut4qQwIgxzuR+ajOi8tuXweIjfcqFgIECG1CC92n52N7y6uV6tNPpXLqtUH033lBAARvauCLOt+7NdTnwgnPrwWQAAgtwiH6w68kw3tr+T33+37jMh/3Ffxi11IAJWeif7HBfyse73Vsc/13gIQ2oUVoYXr2VBIrK1ul+Hf6eeWKnT0Z43/mrCxASGMDVxv857XTw064937OQMIh4b5kT//gpK5f2wsTk6+4qF26rp7nRn65GQECKTPRuxDx7+69NMrS0qIlBOE+AWBXItY/H698sFfH0AsDNX/xxp4d+DNzfrMptAjm+MCn4k+Lr41EG5/vEYAgPJJwnd6pY8GtlYNqem5WC0f3dqr+yMi11XIoiADM9MCH4l/a10crty6FOCS0CS3xKDU1bcp3mrnw2Hxy+3cD/a5cN3sjiAQBBN2pvg/Fc+abI9tX7ggtAoSHrD8xmSwWg4NsZm6wfOEmBvqT4e6GhQgBFJOjyQXwHL85eudSUQIgQHjIDpxI5kNTX0vOTwR3zkNoEfFQ5PSnK1nwHF8fXb5YhQAIgNAmwJmPN2G5VXhmKr7xYQ6A8FXiBFcteA5fG7tzMaTQJgDCoWMpz4Yqbs880blz+QbRIgiPKDHeWHbAczg9du9SZIQ2EYIAOMkRj2rk896f9tWuL1aJQ4LwADNOuSLwTR6bzV20hEABECTQ6erzicpezb42xlvXdiQ8IAgQQW+gUQwA/sR2PdG8FAltAgSAsc6upKmVS1Vn/Iy/dmWtQeEhQWhRd6JasQT/6sDMe0sHFocEwBi/szuVCNZ36ubIi8O1SysVS+EhASBTUapxEFgD/jQXTHRmt0W0CYDnpXr7O9IrtwrqmnmG1xbzFhAeEWiSs9zcbUgU/3az3tGH1YgACAHwYrHBJzsK7+6F/sTz6f23s5aA8JAAkxp9JfHb5ToI8R/WymFfz2rDEMYghBMBQ0+Mh7/daJqRJ8b0m9WQAIQHrFx5k6/F7Pm1agSAf1/YqydSYd5QiVhQA4Xuudlo5zch++ZO2L1fhUKbcJ9gY9NP9zo3PilZgeI/1bfL1k/lQNMbK1Yh48+dSObP75r44ycT+fNZgWgTDilyx+bHUf51IQII8GfNXL5hvIaMm/H29gEef2ygcuWyOHVqcP+PlyOKgAhAICD1PDEdr350W5AA8GdRPVuygExPb7RbgT3y9Eh0dzHPI6fHwrsLeQMRAiG0WTJ9atreXmgQEgD+o1DYrQEyw50Hu1WYp04k1y9vhu6TjyXXL6+FBIQWCi2Cnw7TGXM7Dwht/JcGG/mcVeSOJPdzNYy+1FW6ej0wg690la4t1QlAaCEAGjeViW3tMVazAIQW/mKL3M/uK/RGnWLRxr/dH11bKtr460d17WpBAIQ2kjE/3jU6vnirELIFgADw0+t1hMV1G7nDYaHmDX/Lub24Ja//O+7K1Y2AEA7JOByeGk2Z7fN5S1iRgABw4Wo5JKprNaevUXX7v+tUPrjndB75ulP6+F6TAkA4Xmp2tNsRiMa/lwwggYBx2AQvVu7uE82DNXk26jk9GX1yp8rkyKvG5hsiQBhjXMd3DYH65qV1ORAEgq4TNclL9l6uKWvLuSaSx077Ny9U1DE0UOk65gsEQJBEi2xhZaVQJyEIMI6vRkheZHGrJMmWiuHw/FDt7ax1x+eS21czPd3dKYM2EaKtba1uFq1AQAKYdMOaJf9riLvZA1gT7XsTE8Gtjy0zc9PByrtuR3d3V5cXNwjo+41qobyRbcgSBNQS7whroci/eamrkd0JAXiDA87WB0Wbmp9NZN/bNSDifYlOR4HXGdvf264EEtoICeh1KgcA+eMXJxPl7TytMkMd+zcW65iZ7y9dWQQECEaM4h2m0oC1AogHnMRAsRwQ5A+SZya88s06k5Pdwe7KTtF/aTS4/XHdEyDKWsfSMDKwgACihWB8fD9XE2H4A6fn2WlWvkxOpU12tSZvpttdvlCIHAkCIECAgUABQptM51B0JwRAw7Pg0KlJ5m93jTa3S4iOjrq5pRthJKFNOERBaGPkwKR6O6PlukDC8CzkZ05MY3cjZat148+mGhtrpaDabFiBEP6PAMFx/VQ6EWYLEUiCPAvAz8wetzuFehD6g2PRzk4lss2o2miEiiS0EG0CDTviKd9t7uUs2ALyDQGI9Z2aYDZfVddEorS2bwWpWW80G7XIAiRBEI7jxtx0zGMtXzhw2AbwhxIkc+TZo06p0EyPhet7AWEjRWEYHFRDwHUchyQQi7kx17dBo1gIAwckAfBHsgJsmHphPF3fCzLN1QMQsKo3m83Q0mEy7nu4zwpeUM5VrUQDAiDflJWEyHWnZwfd2p1SwAgOBcoKIIkHKBKIsvm6CJAEAfwvM5j+fV3HbuoAAAAASUVORK5CYII=')

    YY_CANG_ICON = True
    YY_CANG_ICON_K = 0.45         # 采样半径(× E 框高): 只量按钮中间, 避开外圈那圈紫环
    YY_CANG_ICON_WHITE = 190      # 单通道都大于它才算"白"
    YY_CANG_ICON_MIN = 0.06       # 白占比过线 = 图标亮着(重击还能按), 灭了 = 重击已出手

    YY_CHAIN_WHITE = 0.08
    YY_CHAIN_CONF = 0.80        # 模板匹配那条只进日志(>= 这个值算"图标在"), 不参与判定

    # ==================== 莫特斐 ====================
    # 【R 之后接 E 不用等】(用户 2026-10-10)。参考代码里秧秧的 R 演完要等 M_R_TO_E(0.80)
    # 再按 E(那个 E 是单发的剑式切换, 被收招吞了整个 R 之后就全错); 莫特斐的 R 之后
    # 紧跟的是他自己的 E(可以补按、不吃剑式奇偶), 而且实机跑下来不需要那段等待。
    MO_R_TO_E = 0.0
    # 【莫特斐没有千咲那套"强化E/电锯模式"】: 参考代码里 'E*' 那一格(等收招 -> 看 E 图标
    # -> 按一次强化E)和 'A~' 那一格(电锯长按前补一发 E)在本队没有对应物。
    # 他唯一需要的"资源闸"是大招能量, 由 fill_liberation 覆盖('RMO' 那一格)。
    # 【E 的输入缓存短】: 莫特斐的 E 在 R 之后紧跟(表里 gap 0.25), 走 send_resonance_key
    # 单发 + record_resonance_use 记账, 不做任何补按(补按会多吃一次 CD)。

    # ==================== 两条宏(用户 2026-10-10 版, 结构不动) ====================
    # 每行 = (动作, 按住ms, 松开后等ms, 注释)。动作:
    #   'A'       左键【点一下】普攻(A_TAP = 0.06s)。要打几下就写几格(参考代码就是这么写的):
    #             a23 写成 ('A',50,300,'秧a2') + ('A',50,350,'秧a3') —— 段间那 300ms
    #             是给上一段的后摇留时间(更密下一段会被吞)
    #   'AZ'      重击(长按 hold 毫秒)。切人后紧跟的长按会先等入场(settle_before_hold)
    #   'AYC'     秧秧 1苍(重击·苍剑式): 同 'AY', 只用在 1苍 那一格 —— 提前
    #             YY_CANG_TRIM 松手(后面的 Q、R 跟着提前);
    #             【这一格不做"出手就提前松"】: 后面紧跟 Q, 松早了 Q 会落在派生帧之前被丢
    #   'AY'      秧秧那几下长按(1苍/1羽/第2羽): 按满时长; 【重击一出手(图标灭)就
    #             提前松手】, 省掉溢出普攻, 见 HOLD_EARLY_RELEASE。
    #             前台时走 SendInput; 长按期间把重击就绪图标读数打进日志(只读不打断)
    #   'AYP'     同 'AY', 但【不等到场】(预输入重击): 切人那格 gap 给 0, 按下沿落在
    #             入场动作里靠游戏的输入缓存接上 —— 本队最终版没用到, 保留备用
    #   'W'       向前走一下(循环宏第一格, 调位置用)
    #   'E'/'R'/'Q'   共鸣技能 / 共鸣解放 / 声骸技能, 【发给当时在场的那个人】。
    #             秧秧的 E【一律单发】: 每按一次翻一次剑式, 多一下奇偶就错
    #   'RMO'     莫特斐大招: 先攒能量(图标不亮就点普攻), 再【连发到 HUD 消失为止】,
    #             演出结束就走(不补足 gap —— 表里那个 gap 写的就是演出时长)
    #   'RSUI'    穗穗大招: 先等三段回路满(没满就接着点普攻), 再走 'RMO' 那一套
    #   'RSUI!'   穗穗大招【不打闸不点普攻】: 跳过回路/能量闸, 连发到出手 + 等演出, 马上切人
    #   'RY'      秧秧大招: 连发到出手, 演完 + 等落地 + 等 M_R_TO_E 收招 ——
    #             后面那个 E 是单发, 丢不起
    #   'E#'      按到这个技能进 CD 为止(穗穗循环轮那个 E, 紧跟切人会被入场吞)。
    #             【先见过"亮"才认"暗"】: 刚切进来那几帧技能栏还是上一个人的
    #   'E1'      穗穗的强化E(醒春潮): 回路没满就先点普攻攒, 满了按到 suisui_e1 熄灭;
    #             【攒不满就不按】—— 按下去是普通E, 见 SUI_E1_GATE
    #   'E苍'/'E羽'  秧秧的普通 E, 按完核对剑式是不是换到了苍/羽, 没换过去补一次
    #             (见 YY_FORM_CHECK)。已经是那个形态就不按(再按反而翻走)
    #   'EY'/'EY0'   秧秧的强化E(剑式流转, +1 苍翎)【换苍剑式】, 两个都期望苍:
    #             'EY'  没亮(流响没空)就先点普攻攒, 按完【不等核对, 立即返回】
    #                   —— 后面紧跟着切人的格子用它
    #             'EY0' 只读不点(这时点出来的是羽强化A, 不扣流响还吃掉第二个羽),
    #                   按完核对剑式(参考代码原样)
    #   'Q^'      声骸 + 【按之前若协奏没满就平a+E连点把它打满】, 再按 Q(莫特斐那格用,
    #             见 Q_GATE)
    #   'AX'      秧秧那下长按(循环轴 600 / 2链启动轴 1200): 按住之前先看一眼流响条,
    #             剩得比 YY_DRAIN_ABOVE(0.03) 多才先点普攻打空, 打到这条线就停
    #   'E+'      强化E1: 在同样长的一格里连发, 盖过变奏入场的 QTE 锁(保留备用)
    #   'SPACE'   跳(走框架配置的跳跃键)
    #   'F?'      处决: 有提示就按; 没有就等 YU_NO_BREAK_TAIL(羽的后摇), 期间提示亮了照按
    #   'F!'      同 'F?', 但等提示出现的窗口是 F_BREAK_WAIT(1.2s) —— 用在"要真按出
    #             处决"的格子(本队最终版没用到, 保留备用), 见 break_or_wait_tail
    #   'WIN'     不按键, 只是标记: 下一个切人起算烟岚窗口(本队的轴没有用它, 见 YANLAN_WINDOW)
    #   '>SUI'/'>MO'/'>YY'   切人; 结尾带 '^' = 这一下是变奏入场, 切之前先把协奏打满
    OPENER_MACRO = (
        # 【4r 轴: 强制秧秧开局】(用户 2026-10-16) —— 不管谁在场, perform_opener 都会先切回
        # 秧秧, 所以这张表第一格直接就是秧秧的 A; 单轴版, 0 链 2 链都是这一套。
        ('A',      50,  50, '秧A'),
        ('E羽',     50,  0, '秧E(换羽剑式), 按完核对剑式'),
        ('Q',       50,   0, '秧q(声骸)'),
        ('RY',      50, 5000, '秧r(共鸣解放): gap = 参考代码的 5000(演出约4.2s+收招0.8s), 实际由 cast_yy_lib 管时间'),
        ('E羽',     50,   50, '秧e(换剑式->羽; R 清空了流响, 这一下就是强化E +1 苍翎)'),
        ('EY0',    50,  50, '秧强化E(换苍剑式, +1 苍翎凑满 2): 只读不点, 见 YY_DRAIN_CAP'),
        ('AYC',  1700,   50, '秧长按: 1苍(重击·苍剑式), 提前 YY_CANG_TRIM 松手'),
        ('>SUI',    50,   250, '切穗穗'),
        ('A',      50,  250, '穗A1'),
        ('A',      50,  600, '穗A2'),
        ('A',      50,  200, '穗A3'),
        ('E1',     50,  1000, '穗强化E(醒春潮): 等回路满再按, 按到图标灭'),
        ('E#',      50,  250, '穗e(按到进CD, 紧跟切人会被入场吞)'),
        ('AZ',     800,   80, '穗z(重击)'),
        ('>YY',    50,   50, '切秧秧'),
        ('A',      50,  200, '秧A'),
        ('A',     50,  150, '秧A'),
        ('>MO',     50,   50, '切莫特斐'),
        ('>YY',    50,   50, '切秧秧'),
        ('A',       50,  400, '秧A'),
        ('A',       50,  250, '秧A'),
        ('EY',     50,  250, '秧强化E(换羽剑式, +1 苍翎): 流响没打空就先点普攻打空, 见 YY_EX_GATE'),
        ('>SUI',   50,   500, '切穗穗'),
        ('A',      50,  250, '穗A'),
        ('A',      50,  300, '穗A'),
        ('Q',      25,    0, '穗声骸'),
        ('RSUI',    50,    0, '穗r(先等三段回路满, 再连发到出手)'),
        ('WIN',     0,    0, '烟岚窗口: 从下面这个切人起, 游戏时间 6s 内要变奏切回秧秧'),
        ('>YY^',    50,  750, '延奏切秧秧(750 = 羽挟苍空的入场动作)'),
        ('A',      50,  250, '秧A'),
        ('A',      50,  200, '秧A'),
        ('>MO',     50,    0, '切莫特斐'),
        ('RMO',     50,    0, '莫大招'),
        ('E',       50,   50, '莫e'),
        ('>YY',     50,   10, '切秧秧'),
        ('A',      50,  400, '秧A'),
        ('A',      50,  450, '秧A'),
        ('>MO',     50,   50, '切莫特斐'),
        ('>YY',     50,   0, '切秧秧'),
        ('AX',    600,  700, '秧长按A(流响剩得多才先打, 见 YY_DRAIN_ABOVE)'),
        ('>MO',     50,  200, '切莫特斐'),
        ('E#',      50,  150, '莫e'),
        ('Q^',      50,  200, '莫q(按前先把协奏打满: 平a+E连点, 见 Q_GATE)'),
        ('>YY^',    50,   0, '延奏切秧秧'),
        # ---- 2羽1苍 ----
        ('AY',   3000,  800, '秧长按: 1羽'),
        ('F!',     50,    0, '处决(没有就等羽的后摇)'),
        ('EY0',    50,  50, '秧强化E(换苍剑式, +1 苍翎凑满 2): 只读不点, 见 YY_DRAIN_CAP'),
        ('AYC',  2300,   50, '秧长按: 1苍(重击·苍剑式), 提前 YY_CANG_TRIM 松手'),
        ('Q',      50,    0, '秧声骸'),
        ('RY',     50, 5000, '秧大招(+1 苍翎), 演完等收招'),
        ('E羽',    50,    50, '秧E(换羽剑式, +1 苍翎凑满 2), 按完核对剑式'),
        ('AY',   4300, 900, '秧长按: 第2羽(湮象风华)'),
        ('F!',     50,    0, '处决(没有就等羽的后摇)'),
    )

    LOOP_MACRO = (
        # 开头三格还在秧秧身上: 上一条宏刚打完羽重, 人还是她(跟参考代码循环宏逐格相同)
        ('W',      50,    0, '向前走一步(必须真走出去: 走出这一步普通E 才亮, 后面那下换苍才按得出来)'),
        ('E苍',     50,  150, '秧E(换苍剑式), 按完核对剑式'),
        ('A',       50,  100, '秧a2'),
        ('>SUI^',   50, 1000, '延奏切穗穗(1000 = 参考代码循环开头那格的 gap)'),
        ('AZ',     650,   80, '穗z(重击)'),
        ('>YY',     50,   50, '切秧秧'),
        ('A',       50,  400, '秧A'),
        ('A',       50,  450, '秧A'),
        ('>MO',     50,  100, '切莫特斐'),
        ('>SUI',    50,   50, '切穗穗'),
        ('E#',      50,  250, '穗e(按到进CD, 紧跟切人会被入场吞)'),
        ('AZ',     650,   80, '穗z(重击)'),
        ('>YY',     50,   50, '切秧秧'),
        ('A',       50,  400, '秧A'),
        ('A',       50,  250, '秧A'),
        ('EY',     50,  100, '秧e(换剑式)'),
        ('>MO',     50,   50, '切莫特斐'),
        ('>SUI',    50,  500, '切穗穗'),
        ('A',       50,  600, '穗下落攻击(等出伤再R)'),
        ('Q',       50,    0, '穗穗声骸'),
        ('RSUI',    50,    0, '穗r(先等三段回路满, 再连发到出手)'),
        ('WIN',     0,    0, '烟岚窗口: 从下面这个切人起, 游戏时间 6s 内要变奏切回秧秧'),
        ('>YY^',    50,  750, '延奏切秧秧(750 = 羽挟苍空的入场动作)'),
        ('A',      50,  250, '秧A'),
        ('A',      50,  200, '秧A'),
        ('>MO',     50,    0, '切莫特斐'),
        ('RMO',     50,    0, '莫大招'),
        ('E',       50,   50, '莫e'),
        ('>YY',     50,   10, '切秧秧'),
        ('A',      50,  400, '秧A'),
        ('A',      50,  450, '秧A'),
        ('>MO',     50,   50, '切莫特斐'),
        ('>YY',     50,   0, '切秧秧'),
        ('AX',    600,  700, '秧长按A(流响剩得多才先打, 见 YY_DRAIN_ABOVE)'),
        ('>MO',     50,  200, '切莫特斐'),
        ('E#',      50,  150, '莫e'),
        ('Q^',      50,  200, '莫q(按前先把协奏打满: 平a+E连点, 见 Q_GATE)'),
        ('>YY^',    50,   0, '延奏切秧秧'),
        # ---- 2羽1苍 ----
        ('AY',   3000,  900, '秧长按: 1羽'),
        ('F?',     50,    0, '处决(没有就等羽的后摇)'),
        ('EY0',    50,  50, '秧强化E(换苍剑式, +1 苍翎凑满 2): 只读不点, 见 YY_DRAIN_CAP'),
        ('AYC',  2300,   50, '秧长按: 1苍(重击·苍剑式), 提前 YY_CANG_TRIM 松手'),
        ('Q',      50,    0, '秧声骸'),
        ('RY',     50, 5000, '秧大招(+1 苍翎), 演完等收招'),
        ('E羽',    50,    50, '秧E(换羽剑式, +1 苍翎凑满 2), 按完核对剑式'),
        ('AY',   4300, 900, '秧长按: 第2羽(湮象风华)'),
        ('F!',     50,    0, '处决(没有就等羽的后摇)'),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.opener_armed = True
        self.last_opener = -1
        self.macro_t0 = 0.0
        self.macro_marks = []
        self.cur = None
        self.holding_attack = False
        self.si_holding = False        # 左键是不是 SendInput 按下去的(松开也得走 SendInput)
        self.yy_ex_verify_pending = None  # 'EY' 按完 E 还没回头检查(挪到紧跟的长按里做)
        self.hold_credit = 0.0         # 上一格核对剑式超出宏表的时间, 由紧跟的长按扣回来
        self.skip_cang = False         # 变奏后流响没空, 这一轮不放苍(见 YY_SKIP_CANG)
        self.yy_s2 = False             # 开局读苍重击图标的结果: True = 2链, 用 S2 那套轴
        self.win_log = []              # 烟岚窗口里每次切人: (切给谁, 按键时的窗口游戏时间)
        self.poking = False
        self.switch_press_at = 0.0
        self.lib_press_at = 0.0
        self.loop_count = 0
        self.macro_desync = 0
        self.last_was_switch = False
        self.switch_key_at = 0.0       # 最近一次宏里切人键按下的时刻
        self.switch_arrived_at = 0.0   # 最近一次宏里切人确认到场的时刻
        self.tight = False             # 在不在烟岚窗口里('WIN' 到 '>YY^')
        self.win_armed = False         # 'WIN' 之后还没碰到切人(窗口起点待定)
        self.win_t0 = 0.0              # 烟岚窗口起点(穗穗大招后切秧秧那一下的按键时刻)
        self._ym_fg_warned = False
        # 【这里也要启一次】: reset_state() 只在 load_chars() 时跑, 而角色对象会被
        # 粘性复用 —— 开关自动战斗时很可能一次都不跑到
        try:
            start_enable_watch(self.task, self.logger)
            start_f_watch(self.task, self.logger)
        except Exception:
            pass

    def reset_state(self):
        super().reset_state()
        self.opener_armed = True
        start_f_watch(self.task, self.logger)
        start_enable_watch(self.task, self.logger)

    # ==================== 队伍判定 ====================

    @property
    def is_in_yangmosui(self) -> bool:
        """本队 = 莫特斐 + 穗穗 + 秧秧·玄翎。【按类名判】。"""
        team_members = 0
        for char in self.task.chars:
            if char and char.name in {'Mortefi', 'Suisui'}:
                team_members += 1
        return team_members == 2

    def teammate(self, name):
        for char in self.task.chars:
            if char is not None and char.name == name:
                return char
        return None

    def opener_pending(self):
        return self.opener_blocked_by() is None

    def opener_blocked_by(self):
        """启动轴不跑的原因; 返回 None 表示该跑。

        【这里不查任何"某个技能可用"】: 场下角色的可用性读的是上次在场时 OCR 到的 CD 残值,
        拿它当门会开场愣一下。防重入靠 opener_armed + OPENER_MIN_GAP。
        """
        if not self.is_in_yangmosui:
            return 'team is not mortefi/suisui/yangyangsp'
        if not self.opener_armed:
            # 【玩家开关过自动战斗就放行】。手动停任务不走 combat_end(), 这个标记会跨局
            # 留在 False; 重开时角色对象又常常被粘性复用, reset_state() 根本不跑。
            restarted = getattr(self.task, '_ww_task_restarted_at', -1)
            if restarted > self.last_opener:
                self.logger.info('auto combat 重开过 — 启动轴重新武装, 从头跑')
                self.opener_armed = True
                return None
            return 'already armed-down (ran once this combat)'
        # 玩家按过 F = 真的重开了一局, 直接放行(战斗判定抖动不会有人按 F)
        f_press = getattr(self.task, '_f_last_press', -1)
        if f_press > self.last_opener:
            waited = time.time() - f_press
            delay = f_settings(self.task)[1]
            if waited < delay:
                return f'F pressed {waited:.2f}s ago, waiting {delay:.2f}s for the mobs'
            return None
        if self.last_opener >= 0 and time.time() - self.last_opener < self.OPENER_MIN_GAP:
            return f'ran {time.time() - self.last_opener:.1f}s ago (< {self.OPENER_MIN_GAP:.0f}s)'
        if not self.task.use_liberation:
            return 'task.use_liberation is off'
        return None

    # ==================== 宏原语(引擎) ====================
    # 逐字移植自参考代码(它那份又源自 Changli__Jinhsi__Verina/Changli.py,
    # 【注释里的实机数据是那条轴的标定记录, 不是秧莫穗的】)。
    # 这里是整套引擎, 所以有几个这条轴当前没用上的备件(pass_intro / lib_ready_now /
    # poke_until_hud_back / press_e_then_switch / press_echo_until_cd / send_echo_now /
    # switch_out_while_key / watch_hud_gone) —— 调轴时要"等协奏满再切走""能量不满就跳过
    # 大招"这类保底, 直接拿来用, 不用再从别的队伍抄一遍
    def macro_wait(self, sec):
        """精确等待, 【不点击】。

        不走 executor.sleep —— 它每 0.4 秒无条件插一次 next_frame 截图, 插入位置
        不可控, 而这条轴的容错在 ±0.1 秒级。切成 0.1 秒一片, 片间检查任务是否被停用。
        """
        if sec <= 0:
            self.task.executor.check_enabled(check_pause=False)
            return
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)

    def macro_gap(self, sec, tag=None):
        """间隙。【持续普攻打开时自动变成连点】—— 这就是"我没说停就一直A"。"""
        if sec <= 0:
            return 0
        if not self.poking:
            self.macro_wait(sec)
            return 0
        return self.macro_spam(sec, self.A_INTERVAL, tag=tag or 'gapA')

    def macro_start(self):
        self.macro_t0 = time.time()
        self.macro_marks = []

    def macro_mark(self, name):
        self.macro_marks.append(f'{name}@{time.time() - self.macro_t0:.2f}')

    def macro_timeline(self, since=0):
        return ' '.join(self.macro_marks[since:])

    def macro_spam(self, window, interval=None, tag='A', sample=None, sample_every=2,
                   max_clicks=None):
        """连点一个窗口。

        打出几段由 window 决定, 不由单次点击的时机决定 —— 动画期间的点击会被丢掉,
        连点保证总有一下落在动画刚结束的瞬间。时间轴上记首尾和点了几下, 对着录像
        能反推一段动画多长: 窗口里打出 n 段, 一段就约等于 window/n。
        """
        interval = self.A_INTERVAL if interval is None else interval
        start = time.time()
        n = 0
        # 次数上限: 光靠时间兜底的话, interval 被调成 0 或者机器卡一下就会瞬间
        # 灌进去几千次点击
        cap = int(window / max(interval, 0.01)) + 2
        # 【可以再封一层】: 用在【空中】那几格 —— 多余的点击会变成下落攻击,
        # 落地会打断/改变后面的动作。封顶【不缩短窗口】, 所以不花时间
        max_clicks = cap if max_clicks is None else min(cap, max_clicks)
        self.macro_mark(f'{tag}_start')
        self.spam_samples = []
        while time.time() - start < window and n < max_clicks:
            self.click()
            n += 1
            if sample is not None and n % sample_every == 0:
                self.spam_samples.append(f'{time.time() - start:.2f}:{1 if sample() else 0}')
            # 最后一段等待按剩余时间裁剪, 别整个 interval 等下去 —— 那是白送的延迟
            remaining = window - (time.time() - start)
            if remaining <= 0:
                break
            # 【减掉 A_TAP】: click 现在自己按住 A_TAP 秒, 不扣的话这段连点的周期
            # 从 interval 变成 interval + A_TAP, 一个窗口里少点三分之一下
            self.macro_wait(min(max(0.0, interval - self.A_TAP), remaining))
        self.macro_mark(f'{tag}_end(x{n})')
        return n

    def spam_key(self, send, window, interval=None, tag='key', poke=None, presses=None,
                 click_interval=None, stop_when=None):
        """在一个窗口里反复发同一个技能键, 用来盖住动画那一段。

        动画期间的按键是被丢掉的、不排队, 所以单发必丢 —— 这个形状在别的轴上
        踩到过六次, 症状统一是"那一步慢了"(要等整个动画演完才有第二次机会)。

        【必须在这个角色自己的回合里跑完, 不要跟切人并行】: 切人期间发出去的键会被
        游戏带过换人边界落在新角色身上。

        Args:
            poke: 发键期间要不要照常点普攻。默认跟随全局的持续普攻开关。
            click_interval: 点普攻的间隔, 默认 A_INTERVAL。
            stop_when: 每发一次键之后调一次, 返回 True 就停。用在【多按一下会
                烧掉后面要用的充能】的地方 —— 一旦读到技能已经不可用就立刻收手。
                【会读屏, 别配太密的 interval】。
            presses: 只发这么多次, 均匀铺在窗口里。用在"连续点按两次E"那种
                【次数本身有意义】的地方 —— 连发会把两发挤成一发。
                【给了 presses 就由它说了算, window 只用来推间隔】。
        """
        interval = self.KEY_INTERVAL if interval is None else interval
        poke = self.poking if poke is None else poke
        click_interval = self.A_INTERVAL if click_interval is None else click_interval
        if presses is not None and presses > 0:
            interval = max(interval, window / presses)
        start = time.time()
        n = 0
        clicks = 0
        next_click = 0.0
        while True:
            send()
            n += 1
            if stop_when is not None and stop_when():
                break
            if presses is not None:
                if n >= presses:
                    break
                left = interval
            else:
                left = window - (time.time() - start)
                if left <= 0:
                    break
            step_end = time.time() + min(interval, left)
            # 发键的节奏和点击的节奏各走各的 —— 挂在一起的话点击会被技能键的
            # 间隔卡住
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + click_interval
                self.macro_wait(min(0.02, step_end - time.time()))
        # 【点击数也要打进去】: x{n} 只数了技能键, 看不出这段时间有没有在持续普攻。
        # A x0 就是真的没点(poke=False 的那几格)
        self.macro_mark(f'{tag}(x{n},A x{clicks})')
        return n

    def release_attack(self):
        # 【SendInput 按下的必须 SendInput 松开】: PostMessage 的 mouse_up 只进游戏窗口的
        # 消息队列, 系统里那个左键会一直按着 —— 宏异常退出时整台电脑的左键都是按住的
        if self.si_holding:
            if not send_input_left(True):
                self.logger.warning('SendInput 左键松开没发出去 — 如果左键卡住, 手动点一下')
            self.si_holding = False
            self.holding_attack = False
        elif self.holding_attack:
            self.task.mouse_up()
            self.holding_attack = False

    def game_foreground(self):
        try:
            return bool(self.task.executor.interaction.hwnd_window.is_foreground())
        except Exception:
            return False

    def warn_foreground_once(self):
        """游戏不在前台时提示一次(这会让长按/普攻退回失效的 PostMessage)。"""
        if not self._ym_fg_warned:
            self._ym_fg_warned = True
            self.logger.warning('秧莫穗: 游戏窗口不在前台 —— 长按/普攻会退回 PostMessage, '
                                '游戏很可能不认(表现为重击打不出、流响不掉)。'
                                '请点一下游戏窗口让它保持前台。')

    def attack_down(self, direct):
        """按下左键。direct = 走 SendInput(失败自动退回 PostMessage)。返回实际走没走 SendInput。"""
        if direct and send_input_left(False):
            self.si_holding = True
        else:
            direct = False
            if not self.game_foreground():
                self.warn_foreground_once()
            self.task.mouse_down()
        self.holding_attack = True
        return direct

    def tap(self, hold=None):
        """点一下普攻, 【真的按住 hold 秒】。为什么不能用 task.click 见 A_TAP 的注释。

        【走 PostMessage, 不走 SendInput】—— 跟参考代码逐字一致: 框架的 mouse_down/up
        往游戏窗口投 WM_LBUTTONDOWN/UP, 只要【真按住几十毫秒】游戏就认(1苍/1羽 那几段
        之所以要换 SendInput, 是因为那里按下沿落在动作里会被丢, 见 YY_TAIL_SENDINPUT);
        而且 PostMessage 不要求游戏在前台, 比 SendInput 稳。
        """
        hold = self.A_TAP if hold is None else hold
        self.task.mouse_down()
        self.holding_attack = True
        try:
            self.macro_wait(hold)
        finally:
            self.task.mouse_up()
            self.holding_attack = False

    def click(self, *args, **kwargs):
        """本类里所有的 self.click() 都改成按住 A_TAP —— 引擎里那些"顺手点"也一样。

        BaseChar.click 强制 down_time=0.01, 在这条轴上等于没点。参数照收不用:
        这条轴的点击【一律点屏幕中心】, 没有带坐标的调用。
        """
        self.tap()

    def quick_switch(self, target, click=False, click_during=None, settle=None, time_out=None,
                     read_con=False, assume_con=False, click_interval=None,
                     click_first=False):
        """按数字键直切给指定角色。

        不走 switch_next_char(): 那个要先跑 _choose_switch_target 选人, 顺序是框架
        说了算; 而且它每次发数字键都跟一次左键, 想不要那下 A 就没法不要。

        Args:
            click: 到场之后补一下普攻(复刻框架 BaseCombatTask.py:644 的行为)。
                这条轴上一般不用 —— 持续普攻本身就在点, 再补就是多推一段连段。
            click_during: 等换人生效的这段时间里继续点。默认跟随持续普攻开关。
            read_con: 按键之前读一次协奏, 决定要不要按"带变奏"记账。
                【不便宜】(能量环连通域分析), 只有真的要变奏的那两三处才传 True。
            assume_con: 不读屏, 直接按满协奏记。用在【刚放完大招】之后 ——
                那时协奏必满, 而演出期间能量环读数不可信。

        Returns: 是否真的切过去了。
        """
        if target is None:
            return False
        if target is self.cur:
            # 目标已经在场。【这里必须早退】: 不早退的话到场判据立刻成立,
            # 整步 50 毫秒走完, 后面那些"给他的"按键其实发在了别人身上
            self.macro_mark(f'>{target.name[:3]}(already)')
            return True
        entry = time.time()
        time_out = self.SWITCH_TIME_OUT if time_out is None else time_out
        settle = self.SWITCH_SETTLE if settle is None else settle
        click_during = self.poking if click_during is None else click_during
        click_interval = self.A_INTERVAL if click_interval is None else click_interval
        source = self.cur if self.cur is not None else self
        # 【第一个数字键要抢在读协奏之前发】: 读协奏是能量环的连通域分析, 少则
        # 二三十毫秒、睡完之后的第一次读屏能到 0.86 秒 —— 夹在"上一个动作"和
        # "数字键"之间就是白白的延迟。切人本身要 0.06~0.11 才落地, 来得及读完
        slot = target.index + 1
        # 【记下第一个数字键的时刻】: 有几格是靠它当锚点的
        self.switch_press_at = time.time()
        # 【先点几下再发第一个数字键】(click_first = 点几下)。用在"边打A边不停切人"
        # 的格子上: 游戏在角色动作期间会拒绝切人 —— 这正是那种写法不会掐掉 A 的原因。
        # 但如果这一刻场上角色【刚到场、还没起手】, 切人键就没有东西挡着, 会当场生效,
        # 她一下都不打就走。【一下不够】: 那一下要是没被接受就白给了, 所以可以指定点几下
        for i in range(int(click_first)):
            self.click()
            if i + 1 < int(click_first):
                self.macro_wait(click_interval)
        self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
        if assume_con:
            con_full = True
        elif read_con:
            con_full = bool(source.is_con_full())
        else:
            con_full = False
        con_cost = time.time() - entry

        start = time.time()
        last = start   # 第一个数字键已经在上面发过了
        next_click = 0.0
        trace = [] if self.TRACE_SWITCH else None
        team_size = len([c for c in self.task.chars if c is not None])
        untrusted_hits = 0
        clicks = 0
        while time.time() - start < time_out:
            now = time.time()
            if now - last >= self.SWITCH_KEY_INTERVAL:
                self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
                last = now
            # 点击的节奏跟切人键解耦: 切人键 0.03 秒一发, 点击照旧 A_INTERVAL,
            # 否则这段时间会以 0.03 的密度灌点击, 远低于安全下限
            if click_during and now >= next_click:
                self.click()
                clicks += 1
                next_click = now + click_interval
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            # 【count 不达标的 index 打折扣, 但不能一票否决】: in_team() 在只找到
            # 一个槽位文本时照样返回 True 和一个 index(那是渲染顺序的产物);
            # 但一票否决会造成假失败 —— 有槽位被特效盖住时 count 就是不达标,
            # 切人明明成功了也判不出来, 卡满超时, 整条轴从这里崩
            hit = in_team and index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if trace is not None:
                trace.append(f'{time.time() - start:.2f}:'
                             f'{(index if trusted else f"?{index}") if in_team else "x"}')
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                self.handoff(source, target, con_full)
                self.macro_mark(f'>{target.name[:3]}{"^" if con_full else ""}'
                                f'({time.time() - entry:.2f}|con{con_cost:.2f}|A x{clicks})')
                if trace:
                    self.logger.info(f'switch trace -> {target.name}: {" ".join(trace)}')
                if click:
                    self.click()
                    self.macro_mark(f'{target.name[:3]}A')
                self.macro_gap(settle)
                return True
        # 【失败时更要打 trace】:
        #   一直是旧角色的 index  -> 游戏真的在拒绝切人(上一个动作还没演完)
        #   带 ? 的都是目标 index -> 切过去了, 是 count 判据把它挡住了
        #   全是 x               -> HUD 整个不在(演出/时停里)
        self.logger.warning(f'switch to {target.name} slot {slot} timed out '
                            f'after {time_out:.1f}s (stuck in an animation?)'
                            + (f' trace: {" ".join(trace)}' if trace else ''))
        self.macro_mark(f'>{target.name[:3]}FAIL')
        return False

    def handoff(self, from_char, to_char, con_full):
        """复刻 switch_next_char() 尾部那套交接记账 (BaseCombatTask.py:663-672)。

        直接按数字键绕开了框架逻辑, 不补的话没人的 is_current_char 是 True,
        get_current_char() 返回 None, AutoCombatTask 主循环当场崩。
        """
        self.task.in_liberation = False
        from_char.switch_out(con_full=con_full)
        to_char.is_current_char = True
        to_char.has_intro = con_full
        to_char.has_sub_dps_intro = con_full and from_char.is_sub_dps
        to_char.last_switch_in_time = time.time()
        if con_full:
            now = time.time()
            self.task.add_freeze_duration(now, to_char.intro_motion_freeze_duration, -100)
            from_char.last_outro_time = now
        self.cur = to_char

    def switch_out_while_key(self, target, source, key_send, click=True,
                             read_con=False, time_out=None, tag=None):
        """一边切人, 一边给【离场角色】补技能键 —— 键只在 HUD 还读得到他时才发。

        【为什么要那道门】: 切人期间发出去的技能键会被游戏【带过换人边界, 落在新上场
        的角色身上】—— 真同时发的话那发 E 很可能变成新角色放的, 白烧她一层充能。
        所以判据是【HUD 还显示离场角色在场 = 这一发还会落在他身上】, 一从 HUD 上
        消失就立刻停发。

        点击不受这道门约束 —— 点击落错人无所谓(顶多多推一段连段)。
        """
        if target is None:
            return False
        if target is self.cur:
            self.macro_mark(f'>{target.name[:3]}(already)')
            return True
        entry = time.time()
        time_out = self.SWITCH_TIME_OUT if time_out is None else time_out
        src = source if source is not None else (self.cur or self)
        slot = target.index + 1
        self.switch_press_at = entry
        # 【第一个数字键要抢在读协奏之前发】: 读协奏是能量环的连通域分析, 睡完之后的
        # 第一次读屏实测能到 0.86 秒。夹在"上一个动作"和"数字键"之间就是纯延迟,
        # 而切人本身要 0.06~0.11 才落地, 完全来得及在换人之前读完
        self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
        con_full = bool(src.is_con_full()) if read_con else False
        team_size = len([c for c in self.task.chars if c is not None])
        n_key = n_click = 0
        untrusted_hits = 0
        arrived = False
        next_click = 0.0
        while time.time() - entry < time_out:
            now = time.time()
            self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            # 只要 HUD 还认为离场角色在场, 这一发技能键就还落在他身上
            if in_team and index == src.index:
                key_send()
                n_key += 1
            if click and now >= next_click:
                self.click()
                n_click += 1
                next_click = now + self.A_INTERVAL
            hit = in_team and index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                arrived = True
                break
        label = tag or f'>{target.name[:3]}+key'
        if arrived:
            self.handoff(src, target, con_full)
            self.macro_mark(f'{label}{"^" if con_full else ""}'
                            f'({time.time() - entry:.2f}|key x{n_key},A x{n_click})')
        else:
            self.logger.warning(f'switch_out_while_key: {target.name} never came in '
                                f'({n_key} keys, {n_click} clicks)')
            self.macro_mark(f'{label}FAIL(x{n_key})')
        return arrived

    def fire_lib(self, char, tag='R', window=None):
        """把大招发出去。判据是【队伍 HUD 掉下去 = 演出开始】。

        不用 click_liberation(): 它一路阻塞到演出结束才返回, 而这条轴上好几处要在
        演出【期间】继续做事(预输入普攻 / 连发 E / 疯狂切人)。

        【发键之前不读屏确认可放】: 那次读屏是纯延迟, 夹在"上一个动作"和"R键"之间;
        而且它并不能替我们做决定 —— 读到不可用我们照样要发(读数会抖, "没放出来"
        的代价远大于"多按一下")。可用性只在失败分支里读一次, 用来分辨
        "能量不够" 和 "键被动画吞了"。

        【窗口给短】: 正常一两发就进去了。给长的话万一 HUD 判据失灵, 这里会一直
        按 R —— 把后面轮到的那一发大招白按掉。宁可这一次没放出来, 也不要乱放。
        """
        window = self.LIB_FIRE_WINDOW if window is None else window
        start = time.time()
        # 【记下按 R 的时刻】: 后面几格拿它当锚点, 不拿"HUD 回来"。
        # 按键时刻是我们自己发的、精确; HUD 要读屏, 每轮抖几十毫秒。
        self.lib_press_at = start
        n = 0
        while time.time() - start < window:
            # 【先发键再读屏】。原来是"读一帧 -> 判HUD -> 才发R", 于是【每次放大招前都
            # 白读一次屏】—— 实机那 0.10 秒全是这次读屏。而第一轮那次判断本来就没意义:
            # 刚按完 Q, 不可能已经在演出里。多发的那一下不会有副作用 ——
            # 演出期间的按键被丢掉、不排队
            char.send_liberation_key()
            n += 1
            # 【发键的节奏和读屏的节奏各走各的】: 读屏要 0.04, 挂在一起就等于把重试
            # 周期翻倍, 而 R 被接受的时刻只跟【按键什么时候落下】有关
            if n % self.LIB_READ_EVERY == 0:
                self.task.next_frame()
                if not self.task.in_team()[0]:
                    char.record_liberation_use()
                    self.macro_mark(f'{tag}_fired(x{n})')
                    return True
            self.sleep(self.LIB_KEY_INTERVAL, check_combat=False)
        # 最后再确认一次: 键刚发出去、演出还差一帧才开始的情况很常见
        self.task.next_frame()
        if not self.task.in_team()[0]:
            char.record_liberation_use()
            self.macro_mark(f'{tag}_fired(x{n})')
            return True
        self.macro_mark(f'{tag}_NOFIRE(x{n})')
        # 失败了才去读一次能量环: lit=False 是"能量不够/大招还没转好",
        # lit=True 是"键被上一个动作的动画吞了" —— 两种要改的地方完全不同
        try:
            lit = bool(char.liberation_available())
        except Exception:
            lit = 'err'
        self.logger.warning(f'{tag}: {char.name} liberation never started an animation '
                            f'after {n} presses (icon lit={lit})')
        return False

    def poke_until_hud_back(self, tag='anim', time_out=None, tail=None):
        """演出期间一直点普攻, 等队伍 HUD 回来(演出结束)再往下走。

        【为什么点】: 演出结束的第一帧就要有输入落进去, 而演出期间的点击是被丢掉的、
        不排队 —— 连点免疫被吞, 单发要么埋在演出里要么等太久。
        【为什么还要 tail】: HUD 回来那一刻角色多半还在收招里, 那几下照样被吞。

        【"HUD 回来"要先确认它消失过】: 进来的这一刻画面还在渐变, 读一帧很可能
        读回 True, 那就是"演出刚开头就判成结束"。
        """
        time_out = self.LIB_ANIM_TIME_OUT if time_out is None else time_out
        tail = self.LIB_ANIM_TAIL if tail is None else tail
        start = time.time()
        n = 0
        gone_seen = False
        back = False
        next_click = 0.0
        while time.time() - start < time_out:
            now = time.time()
            if now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone_seen = True
            elif gone_seen or time.time() - start >= self.HUD_NO_ANIM_GRACE:
                back = True
                break
            self.macro_wait(0.01)
        # 演出这一段计入 freeze, 否则框架的各种 time_elapsed_accounting_for_freeze
        # 会把它算成"这个角色磨蹭了 5 秒"
        self.add_freeze_duration(start, time.time() - start)
        self.macro_mark(f'{tag}({"ok" if back else "timeout"},'
                        f'{"anim" if gone_seen else "NOANIM"},x{n},'
                        f'{time.time() - start:.2f}s)')
        if tail > 0:
            self.macro_spam(tail, self.A_INTERVAL, tag=f'{tag}Tail')
        return back

    def wait_con_at_least(self, char, level, tag='con', cap=None, interval=None, poke=True,
                          on_poll=None):
        """边打边等协奏圈涨到 level 以上(0~1)。到上限也往下走, 不把轴卡死。

        跟 wait_con_for_intro 的区别: 那个是"等满才交棒"(门槛是 CON_ENOUGH=0.99,
        【那个值是"环还没闭合"的哨兵, 不是真满】—— 要真满就把 level 传 1.0), 这个是
        【等到某个门槛才做下一个动作】。

        【读协奏不便宜】(能量环连通域分析), 所以轮询间隔别调太小。
        【等的期间必须继续打】: 圈是靠打中涨的, 干站着等只会等到超时。
        """
        cap = self.CON_WAIT_TIME_OUT if cap is None else cap
        interval = self.CON_POLL_INTERVAL if interval is None else interval
        start = time.time()
        n = 0
        con = 0.0
        hit = False
        samples = []
        next_click = 0.0
        # 【读之前先把框架缓存打掉 + 刷一帧】(用户 2026-10-15 "有误判提前切人了"):
        # BaseChar.get_current_con() 开头 `if self.current_con == 1: return 1` —— 命中缓存
        # 就一帧屏都不读直接放行; 而 task.frame 是后台 ~0.4s 才刷一次的旧帧。
        # 两者都会把"协奏没满"读成满 -> 按变奏记账 -> 切进去的人拿不到入场。
        char.current_con = 0
        self.task.next_frame()
        while self.time_elapsed_accounting_for_freeze(start) < cap:
            try:
                char.current_con = 0
                con = float(char.get_current_con())
            except Exception:
                con = 0.0
            if len(samples) < self.CON_SAMPLE_MAX:
                samples.append(f'{time.time() - start:.2f}:{con:.2f}')
            if con >= level:
                # 【连读确认】: 刷一帧复读, 两次都满才算 —— 单帧被特效糊住(框里撞进同色
                # 像素, 框架的连通域判据会给 is_full)不算。
                self.task.next_frame()
                try:
                    char.current_con = 0
                    again = float(char.get_current_con())
                except Exception:
                    again = 0.0
                if len(samples) < self.CON_SAMPLE_MAX:
                    samples.append(f'{time.time() - start:.2f}:{again:.2f}(复核)')
                if again >= level:
                    hit = True
                    break
            now = time.time()
            if poke and now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            if on_poll is not None:
                on_poll()
            self.macro_wait(interval)
        self.macro_mark(f'{tag}({con:.2f},{"ok" if hit else "CAP"},A x{n},'
                        f'{time.time() - start:.2f}s)')
        if not hit:
            self.logger.info(f'{tag}: con only reached {con:.2f} (< {level:.2f}) in '
                             f'{cap:.1f}s — {" ".join(samples)}')
        return hit

    def wait_con_with_key(self, char, level, tag='con', cap=None, key=None,
                          key_interval=None, interval=None, poke=None):
        """边打边等协奏涨到 level: 点普攻, 同时(可选)按同一个技能键 —— 两个都涨协奏。

        跟 wait_con_at_least 的唯一差别就是多了那个技能键(莫特斐的 'Q^' 用: 平a + E 连点)。
        技能键在 CD 里按是空操作, 连点没有副作用; 每次按完照常记一次 record_resonance_use。
        到上限也往下走, 不把轴卡死。
        """
        cap = self.CON_WAIT_TIME_OUT if cap is None else cap
        interval = self.CON_POLL_INTERVAL if interval is None else interval
        key_interval = (self.Q_GATE_KEY_INTERVAL if key_interval is None else key_interval)
        poke = self.Q_GATE_POKE if poke is None else poke
        start = time.time()
        n = keys = 0
        con = 0.0
        hit = False
        samples = []
        next_click = 0.0
        next_key = 0.0
        # 【同 wait_con_at_least: 先打掉缓存 + 刷一帧】(用户 2026-10-15 "有误判提前切人了")
        char.current_con = 0
        self.task.next_frame()
        while self.time_elapsed_accounting_for_freeze(start) < cap:
            try:
                char.current_con = 0
                con = float(char.get_current_con())
            except Exception:
                con = 0.0
            if len(samples) < self.CON_SAMPLE_MAX:
                samples.append(f'{time.time() - start:.2f}:{con:.2f}')
            if con >= level:
                # 【连读确认】: 见 wait_con_at_least 里那段 —— 防单帧误判提前切人
                self.task.next_frame()
                try:
                    char.current_con = 0
                    again = float(char.get_current_con())
                except Exception:
                    again = 0.0
                if len(samples) < self.CON_SAMPLE_MAX:
                    samples.append(f'{time.time() - start:.2f}:{again:.2f}(复核)')
                if again >= level:
                    hit = True
                    break
            now = time.time()
            if poke and now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            if key is not None and now >= next_key:
                key()
                char.record_resonance_use()
                keys += 1
                next_key = now + key_interval
            self.macro_wait(interval)
        self.macro_mark(f'{tag}({con:.2f},{"ok" if hit else "CAP"},A x{n},E x{keys},'
                        f'{time.time() - start:.2f}s)')
        if not hit:
            self.logger.info(f'{tag}: con only reached {con:.2f} (< {level:.2f}) in '
                             f'{cap:.1f}s — {" ".join(samples)}')
        return hit

    def on_field_char(self, time_out=None):
        """现在场上是谁 —— 【只在拿不到入口角色时才用】, 因为它开局会说谎。

        in_team() 的判据是"哪个槽位的名字文本【找不到】, 谁就在场"。战斗刚开始时队伍
        HUD 还在渐入, 三个槽位的文本不是同时出现的 —— 这时它只找到一个文本, 但
        exist_count == 1 那个分支【照样返回 True 和一个 index】, 而那个 index 只是
        渲染顺序的产物。可信判据是 count >= 队伍人数。
        """
        time_out = self.FIELD_SETTLE_TIME_OUT if time_out is None else time_out
        expected = len([c for c in self.task.chars if c is not None])
        end = time.time() + time_out
        while True:
            self.task.next_frame()   # in_team() 读的是缓存帧, 不刷就是反复读同一张图
            in_team, index, count = self.task.in_team()
            if in_team and count >= expected:
                for char in self.task.chars:
                    if char is not None and char.index == index:
                        return char
                return None
            if time.time() >= end:
                self.logger.warning(f'team HUD never settled in {time_out:.1f}s '
                                    f'(in_team={in_team} index={index} count={count} '
                                    f'expected={expected}), cannot tell who is on field')
                return None
            self.macro_wait(0.03)

    def wait_hud_back(self, tag='anim', time_out=None, tail=0.0):
        """等演出结束(队伍 HUD 回来), 【期间一下都不点】。

        跟 poke_until_hud_back 的唯一差别就是不点普攻 —— 【角色在空中时必须用这个】:
        那时候的点击会变成下落攻击, 一下就把她砸回地面, 后面整段空中戏就没了。

        【"HUD 回来"要先确认它消失过】: 进来的这一刻画面可能还在渐变, 读一帧很可能
        读回 True, 那就是"演出刚开头就判成结束"。
        """
        time_out = self.LIB_ANIM_TIME_OUT if time_out is None else time_out
        start = time.time()
        gone_seen = False
        back = False
        while time.time() - start < time_out:
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone_seen = True
            elif gone_seen or time.time() - start >= self.HUD_NO_ANIM_GRACE:
                back = True
                break
            self.macro_wait(0.01)
        self.add_freeze_duration(start, time.time() - start)
        self.macro_mark(f'{tag}({"ok" if back else "timeout"},'
                        f'{"anim" if gone_seen else "NOANIM"},{time.time() - start:.2f}s)')
        self.macro_wait(tail)
        return back

    def send_echo_now(self, char, tag='Q', presses=2, window=0.0):
        """立刻放 Q。【三个角色统一走这里, 而且都放在离场前的最后一步】。

        【不读屏】: click_echo(time_out=0) 的第一件事是读屏 echo_available(),
        读到 False 就掉进慢路径 —— 那条路要 OCR 一次 echo 的 CD, 再轮询最多 1 秒。
        而 Q 的位置个个都在处决/大招刚结束那一带, 那几帧的读数正是最不可信的时候。
        发键不读屏: 落在 CD 上是空操作, 不花钱。
        """
        self.spam_key(char.send_echo_key, window, interval=0.0, tag=tag,
                      presses=presses, poke=False)
        char.record_echo_use()

    # ==================== 本条轴额外用到的原语 ====================

    def mark_busy(self, busy):
        """F 键监视线程靠它区分"战斗中手动处决"和"重开副本"。两个名字都置, 见文件顶部。"""
        try:
            self.task._ww_macro_busy = busy
            self.task._three_fire_macro_busy = busy
        except Exception:
            pass

    def wait_hud_up(self, cap=None, tag='HUD'):
        """等队伍 HUD 【现在】在场。按 R 之前用 —— HUD 本来就不在的时候 fire_lib 会当场判
        "演出开始了", 一发都没按出去就记成放了。跟 wait_hud_back(先消失再回来)是两回事。"""
        cap = self.HUD_UP_CAP if cap is None else cap
        start = time.time()
        while time.time() - start < cap:
            self.task.next_frame()
            if self.task.in_team()[0]:
                if time.time() - start > 0.05:
                    self.macro_mark(f'{tag}在场({time.time() - start:.2f}s)')
                return True
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}一直不在({cap:.1f}s)')
        return False

    def fire_r(self, char, tag, window):
        """先等 HUD 在场再 fire_lib。fire_lib 里的 self.sleep 会把 skip_combat_check 放回
        False, 这里重新置上(宏里后面还有好几格高频切人)。"""
        self.wait_hud_up(tag=f'{tag}前HUD')
        fired = self.fire_lib(char, tag=tag, window=window)
        self.task.skip_combat_check = True
        return fired

    def pass_intro(self, source, target, cap, tag, poke=False):
        """等 source 协奏真满, 然后切给 target(带变奏记账)。"""
        self.wait_con_at_least(source, self.CON_FULL_LEVEL, tag=tag, cap=cap, poke=poke)
        return self.quick_switch(target, read_con=True)

    def fire_r_tight(self, char, tag):
        """烟岚窗口里的大招: 【先直接连发】TIGHT_R_FIRST_WINDOW, 没进才边点边攒能量再补。

        跟作者的宏一样, Q 之后第一时间就按 R, 不先读能量、不先点 A: 能量满的话第一发就进;
        差的那一点要是 Q 打中才给的, 连发会在能量到账的那一刻进去, 也不用点 A。
        只有连发这一段都没进, 才是真差几下普攻 —— 那时再点 A 攒(TIGHT_LIB_FILL 封顶)。

        【本队的轴没有 'WIN' 标记, 所以这个方法目前走不到, 保留备用】
        """
        if self.fire_r(char, tag, self.TIGHT_R_FIRST_WINDOW):
            return True
        if self.fill_liberation(char, f'{char.name[:2]}能量', cap=self.TIGHT_LIB_FILL):
            return self.fire_r(char, f'{tag}补救', self.R_EXTRA_CAP)
        self.macro_mark(f'{tag}_能量不够(留给后面的格子)')
        return False

    def close_yanlan_window(self, tag, con_full):
        """变奏切秧秧那一下按出去了: 算烟岚窗口花掉的游戏时间, 打进日志。只记不改流程。

        起点和终点都是【切人键按下】的时刻(协奏闸在按键之前, 所以等协奏的时间算在里面)。
        游戏时间 = 墙钟扣掉窗口里大招演出的时停(wait_hud_back 记进 freeze 的那几段)。
        顺带报【翾舞1 那一刻场上是谁】—— 那决定前置挂在谁身上、后面谁能吃到烟岚。
        """
        self.tight = False
        wall = self.switch_key_at - self.win_t0
        game = (self.time_elapsed_accounting_for_freeze(self.win_t0)
                - (time.time() - self.switch_key_at))
        # 翾舞1(YANLAN_XUANWU)那一刻场上是谁: 窗口里最后一次切给谁, 且那次不晚于翾舞1
        holder = None
        for who, t in self.win_log[:-1]:
            if 0 <= t <= self.YANLAN_XUANWU:
                holder = who
        on_holder = holder is not None
        self.macro_mark(f'烟岚窗口({game:.2f}s,翾舞1时场上:{holder or "?"})')
        msg = (f'{tag}: 烟岚窗口 游戏时间 {game:.2f}s (墙钟 {wall:.2f}s; '
               f'翾舞1 约 {self.YANLAN_XUANWU:.2f}s, 那一刻场上 {holder or "读不到"}, '
               f'窗口上限 {self.YANLAN_WINDOW:.2f}s)')
        if not con_full:
            self.logger.warning(msg + ' — 协奏没打满, 这一下不是变奏, 烟岚拿不到')
        elif not on_holder:
            self.logger.warning(msg + ' — 翾舞1 那一刻读不到谁在场, 烟岚前置挂给谁不确定')
        elif game > self.YANLAN_WINDOW:
            self.logger.warning(msg + f' — 超了 {self.YANLAN_WINDOW:.1f}s, 看时间轴里哪一格晚了')
        else:
            self.logger.info(msg)

    # ==================== 各格 ====================

    def lib_ready_now(self, char, reads):
        for i in range(reads):
            self.task.next_frame()
            try:
                if self.task.in_team()[0] and char.liberation_available():
                    return True
            except Exception:
                pass
            if i + 1 < reads:
                self.macro_wait(0.03)
        return False

    def press_key_until_cd(self, send, available, cap, tag, ready_grace=0.15, poke=False):
        """一直按某个技能键到它进 CD。返回放出去了没有(本来就在 CD 上返回 False)。

        【先见过"亮"才认"暗"】: 刚切人那几帧技能栏还是上一个人的, 读到的是【上一个人】的 CD。
        实机两处都栽在这:
          - 一个角色刚放完 Q 切人, 新角色到场 0.21s 就"判到 Q 进 CD", 可她那时还在
            变奏入场的不响应输入里, 角根本没召出来;
          - 另一个刚放完 E 切人, 新角色到场 0.12s 就"判到 E 进 CD"(读的是前一个人的 E CD 数字)。
        所以要先读到过一次可用, 之后变成不可用才算放出去; ready_grace 秒都没见过可用, 才当它
        本来就在 CD 上、直接跳过。
        poke: 按键之间顺手点普攻(两条节奏各走各的, 不挤在同一帧)。
        """
        start = time.time()
        n = live = clicks = 0
        seen_ready = False
        next_click = 0.0
        while time.time() - start < cap:
            self.task.next_frame()
            hud = bool(self.task.in_team()[0])
            if hud:
                if available():
                    seen_ready = True
                elif seen_ready and live > 0:
                    self.macro_mark(f'{tag}_ok(x{n},A x{clicks},{time.time() - start:.2f}s)')
                    return True
                elif not seen_ready and time.time() - start >= ready_grace:
                    # 两种情况分不开: 本来就在 CD 上 / 第一发就被接受、技能栏换过来时已经在 CD 了
                    # (没有入场锁的角色切进来第一发 E 常常就是这样)。都不用再按
                    self.macro_mark(f'{tag}_没见过亮(x{n},{time.time() - start:.2f}s)')
                    return False
            send()
            n += 1
            if hud:
                live += 1
            step_end = time.time() + self.E_RESEND_STEP
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + self.A_INTERVAL
                self.macro_wait(min(0.02, step_end - now))
        self.macro_mark(f'{tag}_CD?(x{n},seen{int(seen_ready)},{cap:.1f}s)')
        self.logger.info(f'{tag}: never read as on-cooldown after {n} presses (seen ready={seen_ready})')
        return False

    def press_echo_until_cd(self, char, cap, tag, ready_grace=0.15):
        return self.press_key_until_cd(char.send_echo_key, char.echo_available, cap, tag,
                                       ready_grace=ready_grace)

    def press_res_until_cd(self, char, cap, tag, ready_grace=None, poke=False):
        """刚切进来的角色按 E 到进 CD(带"先见过亮"那道门)。"""
        ready_grace = self.SKILL_BAR_SETTLE if ready_grace is None else ready_grace
        return self.press_key_until_cd(char.send_resonance_key, char.resonance_available, cap, tag,
                                       ready_grace=ready_grace, poke=poke)

    def macro_enter(self, entry_char):
        mo = self.teammate('Mortefi')
        sui = self.teammate('Suisui')
        if mo is None or sui is None:
            return None, None, None
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        self.mark_busy(True)
        self.cur = entry_char or self.on_field_char() or self
        self.poking = False
        # 处决全程交给玩家手动按, 框架切人时那一发一律关掉(内置非治疗角色默认会按)
        self.check_f_on_switch = False
        mo.check_f_on_switch = False
        sui.check_f_on_switch = False
        self.macro_desync = 0
        self.macro_start()
        self.log_build_once()
        return mo, sui, previous

    def log_build_once(self):
        """【启动自检】(用户 2026-10-16): 把实际加载的构建号、判据开关、模板指纹打进日志 ——
        日志里没有这一行, 或者这一行的数字跟预期不符, 就是装的那份不对
        (旧文件混装 / ok-ww 用了旧的 __pycache__)。
        """
        if getattr(self, '_yy_build_logged', False):
            return
        self._yy_build_logged = True
        ver = '?'
        try:
            import json as _json
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'team.json'),
                      encoding='utf-8') as fp:
                ver = _json.load(fp).get('version', '?')
        except Exception:
            pass
        fp_a = hashlib.md5(self.YY_GLYPH_A_B64.encode('ascii')).hexdigest()[:8]
        fp_b = hashlib.md5(self.YY_GLYPH_B_B64.encode('ascii')).hexdigest()[:8]
        self.logger.info(
            f'秧莫穗自检: 代码构建={self.YY_BUILD} team.json版本={ver} | '
            f'形态判据={self.YY_GLYPH_GATE}(门槛{self.YY_GLYPH_MARGIN}, 连读{self.YY_GLYPH_CONFIRM}) '
            f'延长上限={self.YY_HOLD_EXTEND}s Q门垫={self.Q_GATE_SETTLE}s | '
            f'模板指纹 A={fp_a} B={fp_b}(期望 A=99244aba B=6a8fc383)')

    def macro_exit(self, previous):
        # 长按跨了好几个方法, 中途抛异常的话鼠标会一直按着。这里是唯一保证松手的地方
        self.release_attack()
        self.poking = False
        self.tight = False
        self.win_armed = False
        self.task.skip_combat_check = previous
        self.mark_busy(False)

    def press_e_then_switch(self, char, target, window, to_switch, interval=None, tag='E'):
        """发 E, 【从第一发 E 起算】过 to_switch 秒切给 target。补发窗口必须 <= to_switch。"""
        interval = self.KEY_INTERVAL if interval is None else interval
        e_at = time.time()
        self.spam_key(char.send_resonance_key, window, interval=interval, tag=tag, poke=False)
        char.record_resonance_use()
        left = to_switch - (time.time() - e_at)
        if left > 0:
            self.macro_wait(left)
        return self.quick_switch(target)

    # ==================== 宏回放 ====================

    def try_f_break(self, tag):
        """处决提示亮着就按 F, 按完等 HUD 回来。返回按了没有。

        【为什么不能直接 task.f_break()】: 它的门是 `can_break or check_f_break()`, 而
        check_f_break 里【屏幕中央那一路找图有 1 秒频率限制】; 宏跑的时候
        skip_combat_check=True, 战斗判定线程也不刷新 can_break —— 两条腿一起瘸, 症状是
        "处决从来不放"。所以这里自己补中央那一路, 命中就把 can_break 置上。
        【is_pick_f 那道门不能省】: F 同时是拾取/交互键。
        """
        if not self.F_BREAK:
            return False
        task = self.task
        ready = bool(getattr(task, 'can_break', False))
        if not ready:
            try:
                task.next_frame()
                ready = self.f_prompt()
            except Exception as e:
                self.logger.info(f'{tag}: f_break probe failed {e}')
                return False
        if not ready:
            return False
        # 【只按 F, 不走 task.f_break()】: 那个会连点左键、至少卡 0.5s, 见 YU_BREAK_ANIM
        start = time.time()
        presses = 0
        while presses < self.F_BREAK_PRESSES:
            task.send_key('f', down_time=0.05)
            presses += 1
            self.macro_wait(0.10)
            task.next_frame()
            try:
                if not self.f_prompt():
                    break
            except Exception:
                break
        task.can_break = False
        self.macro_wait(max(0.0, start + self.YU_BREAK_ANIM - time.time()))
        task.next_frame()
        if not task.in_team()[0]:
            # 演出还在(HUD 不在), 等它回来 —— 后面那几格都要读 HUD
            self.wait_hud_back(tag=f'{tag}处决anim', time_out=self.F_BREAK_ANIM)
        self.macro_mark(f'{tag}处决(F x{presses},{time.time() - start:.2f}s)')
        return True

    def f_prompt(self):
        """屏幕中间有处决提示(不是拾取/交互的 F)。"""
        task = self.task
        hit = task.find_one('f_break', box=task.box_of_screen(0.2, 0.2, 0.75, 0.8,
                                                              hcenter=True, vcenter=True),
                            target_height=720)
        return bool(hit) and not task.is_pick_f()

    def wait_enemy_back(self, cap=None):
        """等场上重新有敌人(转火/轮次切换结束)。到上限就走, 不把宏卡死。

        判据用框架自己的 has_target()(读目标名/血条框), 【读不到就当有敌人】(不拦)。
        为什么要刷帧: has_target 用的是 task.frame, 后台约 0.4s 才刷一次。
        """
        cap = self.MACRO_WAIT_ENEMY if cap is None else cap
        if cap <= 0:
            return True
        start = time.time()
        while True:
            try:
                self.task.next_frame()
                if self.task.has_target():
                    waited = time.time() - start
                    if waited > 0.05:
                        self.macro_mark(f'等敌人回来({waited:.2f})')
                        self.logger.info(f'等敌人回来: {waited:.2f}s(转火/轮次切换期间游戏不收输入)')
                        # 敌人刚出现时刷怪动作/横幅可能还没收完, 再垫一小段
                        self.macro_wait(self.MACRO_WAIT_ENEMY_SETTLE)
                    return True
            except Exception:
                return True          # 读不到(框架没有这个接口/读屏失败) -> 不拦
            if time.time() - start >= cap:
                self.macro_mark(f'等敌人超时({cap:.1f})')
                self.logger.warning(f'等敌人: {cap:.1f}s 场上还是没敌人 — 照开表(可能是在清场尾段)')
                return False
            self.macro_wait(self.MACRO_WAIT_ENEMY_POLL)

    def watch_hud_gone(self, window, tag, poke=False):
        """在 window 里盯着队伍 HUD 有没有消失过(= 全局时停/演出开始), 【用满 window】。

        不提前返回 —— 这一格的长度是宏表定的, 出手了就得原样走完, 提前走会把后面每一格都推歪。
        poke: HUD 还在(= 这一格的技能还没出手)时顺手点普攻。【真出手了一下都不会点】,
        因为出手那一刻 HUD 就没了; 没出手的话这段时间正好拿来攒回路。
        """
        end = time.time() + window
        gone = 0
        seen = False
        clicks = 0
        next_click = 0.0
        while time.time() < end:
            self.task.next_frame()
            if self.task.in_team()[0]:
                gone = 0
                if poke and not seen and time.time() >= next_click:
                    self.tap()
                    clicks += 1
                    next_click = time.time() + self.A_INTERVAL
            else:
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    seen = True
            left = end - time.time()
            if left <= 0:
                break
            self.macro_wait(min(0.02, left))
        self.macro_mark(f'{tag}({"出手" if seen else "没出"},A x{clicks})')
        return seen

    def macro_key(self, act, hold, gap):
        """把宏表里的一格发出去(不含切人)。技能键【发给当时在场的那个人】。

        走 char.send_*_key 而不是硬编码 'E'/'R'/'Q': 玩家改过键位也认。
        record_*_use 是框架自己的 CD 记账, 不记的话宏散掉之后内置逻辑会以为技能还能用。

        返回【这一格的 gap 是不是已经在这里面用掉了】—— 带保底的那几格要自己管时间。
        """
        # 【char 要在所有分支之前取】: 下面好几个分支都要用它
        char = self.cur if self.cur is not None else self
        # 上一格核对剑式超出的时间, 只给紧跟着的这一格(长按)扣, 见 after_form_check
        credit, self.hold_credit = self.hold_credit, 0.0
        if act == 'AX':
            # 长按之后就是羽强化A, 再也扣不动流响 —— 剩得多的话只能趁现在打,
            # 见 YY_DRAIN_ABOVE
            if self.SAFETY and self.YY_EX_GATE:
                self.drain_liuxiang(f'{char.name[:2]}流响')
            # 【AX 不补按】(用户 2026-10-15): AX 对应【羽重第一段】(启动轴 1.2s / 循环轴
            # 0.6s), 后面还有别的格子接着走 —— 这里只按标称, 补按交给 AY 那几格的光圈判据
            act = 'AZ'
        if act == 'AZ':
            # 重击(长按)。【切人之后紧跟着的长按要多等一下】, 见 HOLD_AFTER_SWITCH
            self.settle_before_hold(hold)
            self.tap(hold)
            self.macro_mark(f'{char.name[:2]}重击{hold * 1000:.0f}ms'
                            f'({"SI" if self.si_holding else "PM"})')
            return False
        if act == 'A':
            self.settle_before_hold(hold)
            self.tap(hold)
            # 【打一条 mark】: 参考代码这一格不打(它的时间轴里 A 是隐形的), 但这条轴的
            # 日志是排查主力 —— 少一格 mark 会让人以为那格没跑
            self.macro_mark(f'{char.name[:2]}A')
            return False
        early = True          # 'AY' 默认提前松手; 'AYC'(1苍) 在下面关掉
        if act == 'AYC' and self.skip_cang:
            # 变奏后流响没空, 这一轮不放苍(见 YY_SKIP_CANG): 不长按, 等变奏入场演完就接 Q
            self.skip_cang = False
            self.macro_mark(f'{char.name[:2]}跳过1苍')
            self.macro_wait(self.YY_SKIP_CANG_WAIT)
            return True
        if act == 'AYC':
            # 1苍: 重击早就出手了, 松手时刻只决定后面 Q/R 什么时候按, 见 YY_CANG_TRIM
            hold = max(0.0, hold - self.YY_CANG_TRIM)
            act = 'AY'
            # 【1苍 不提前松】(用户: "改AY, 其他不变"): 它后面紧跟的是 Q(声骸), 而
            # 秧秧的声骸输入缓存只有 0.1s —— 比派生帧(80F≈1.33s)早 0.1s 以上按的 Q 直接丢。
            # 提前松手正好会踩这个坑, 所以 AYC 保持原样(按满 trim 之后的时长)。
            early = False
        if act == 'AY' and credit > 0:
            # 上一格(E)核对剑式多用的时间从这下长按里扣: 重击是跟着 E 的动作出的,
            # 不跟按下时刻, 松手时刻照宏表不变
            hold = max(hold * 0.5, hold - credit)
        if act == 'AY':
            # 秧秧的长按(1苍/1羽/第2羽)。按满表里的时长, 期间读图标打日志;
            # 【重击出手(图标灭)就提前松手】(用户 2026-10-11 "仅做1"), 省掉溢出普攻
            self.settle_before_hold(hold)
            self.hold_traced(hold, f'{char.name[:2]}左键{hold:.2f}', early=early)
            return False
        if act == 'AYP':
            # 【预输入重击】: 不等到场, 按下沿就落在入场/切人的动作里 —— 靠游戏自己的
            # 输入缓存把它接上。用在"切回秧秧的同时就要按住重击"那一格(用户 2026-10-11:
            # "切回秧秧同时预输入重击打羽2")。
            # 【跟 'AY' 的唯一差别就是不调 settle_before_hold】: 那个会从确认到场算等
            # HOLD_AFTER_SWITCH(0.20), 正好把按下沿推出输入缓存的窗口。
            # 打不出来(入场把按下沿吃了)就把这一格换回 'AY'、并把前一格切人的 gap 加回 800。
            self.hold_traced(hold, f'{char.name[:2]}预输入左键{hold:.2f}')
            return False
        if act == 'RY':
            return self.cast_yy_lib(char, hold, gap)
        if act == 'RMO':
            return self.cast_mo_lib(char, hold, gap)
        if act == 'RSUI!':
            # 【穗穗大招, 不打闸不点普攻】(用户 2026-10-11: "2链的轴加入一个穗穗的大招,
            # 开完立马切人, 不要打平a"): 跳过 wait_forte3(回路闸) 和 fill_liberation(能量闸)
            # —— 那两个闸都是"点普攻攒资源"的, 这里不要。直接连发到出手 + 等演出结束,
            # 下一格就是切人(这一格自己管时间, gap 给 0)。
            tag = f'{char.name[:2]}R'
            if not self.SAFETY:
                char.send_liberation_key(down_time=hold)
                char.record_liberation_use()
                self.macro_mark(tag)
                return False
            if self.fire_r(char, tag, self.LIB_FIRE_WINDOW):
                self.wait_hud_back(tag=f'{tag}anim', time_out=self.LIB_ANIM_TIME_OUT)
                return True
            self.macro_mark(f'{tag}_没出手(不补演出gap)')
            return True
        if act == 'RSUI' or act == 'R3':
            # 'R3' 是参考代码的写法(穗穗大招: 先等三段回路满再放), 跟 'RSUI' 同一套
            return self.cast_sui_lib(char, hold, gap)
        if act == 'F?':
            return self.break_or_wait_tail()
        if act == 'F!':
            # 【等提示出现的处决】: 'F?' 只在 0.5 秒里探(YU_NO_BREAK_TAIL, 那是"没处决
            # 就等羽后摇"的数); 尾巴中段这一格(羽2 -> 换苍 -> 处决)是要真的按出处决的,
            # 而提示可能在换苍那一格才亮起来 —— 所以给它 F_BREAK_WAIT 的窗口。
            # 【有提示就立刻按】, 这段等待只在没提示时才花时间。
            return self.break_or_wait_tail(wait_for_prompt=self.F_BREAK_WAIT)
        if act == 'W':
            # 向前走一下(循环宏第一格)。WASD 是游戏默认键位, 框架没把它放进 key_config
            self.task.send_key('w', down_time=hold)
            self.macro_mark('走W')
            return False
        if act == 'SPACE':
            self.task.send_key(self.task.key_config.get('Jump Key'), down_time=hold)
            self.macro_mark('跳')
            return False
        if act == 'E+':
            # 强化E1: 在同样长的一格里连发, 盖过变奏入场的 QTE 锁。见 E_SPAM_INTERVAL。
            # 本队的轴没用到(保留备用: 调轴时要"入场锁里也要把 E 发出去"就用它)
            if not self.SAFETY:
                char.send_resonance_key(down_time=hold)
                char.record_resonance_use()
                self.macro_mark(f'{char.name[:2]}强化E1')
                return False
            self.spam_key(char.send_resonance_key, hold + gap, interval=self.E_SPAM_INTERVAL,
                          tag=f'{char.name[:2]}强化E1', poke=False)
            char.record_resonance_use()
            return True
        if act == 'E#':
            # 按到这个技能进 CD 为止。【先见过亮才认暗】(press_key_until_cd), 刚切进来那几帧
            # 技能栏还是上一个人的, 不带这道门会当场假成功
            if not self.SAFETY:
                char.send_resonance_key(down_time=hold)
                char.record_resonance_use()
                self.macro_mark(f'{char.name[:2]}E')
                return False
            entry = time.time()
            self.press_res_until_cd(char, self.E_CD_CAP, tag=f'{char.name[:2]}E',
                                    ready_grace=self.E_READY_GRACE)
            char.record_resonance_use()
            # 【判据成立也要把这一格的时间走完】: 提前走等于把后面每一格都往前挪,
            # 宏的节奏就不是宏表那个节奏了(切人确认也是这么处理的)
            left = (hold + gap) - (time.time() - entry)
            if left > 0:
                self.macro_wait(left)
            return True
        if act == 'E1':
            # 穗穗的强化E(醒春潮)。判据是 suisui_e1 这张图, 见 SUI_E1_GATE 那段注释
            if not self.SAFETY or not self.SUI_E1_GATE:
                char.send_resonance_key(down_time=hold)
                char.record_resonance_use()
                self.macro_mark(f'{char.name[:2]}E')
                return False
            entry = time.time()
            tag = char.name[:2]
            if self.fill_sui_e1(char, tag):
                self.cast_sui_e1(char, tag)
                char.record_resonance_use()
            elif self.SUI_E1_SKIP_IF_NOT_READY:
                # 【回路没满就不按】—— 按下去是普通E, 白吃一次 CD 还是进不了濯雨时
                self.macro_mark(f'{tag}强化E跳过(回路没满)')
            else:
                char.send_resonance_key(down_time=self.M_E_KEY_DOWN)
                char.record_resonance_use()
                self.macro_mark(f'{tag}E(普通, 回路没满)')
            # 【判据成立也要把这一格的时间走完】: 提前走等于把后面每一格都往前挪
            left = (hold + gap) - (time.time() - entry)
            if left > 0:
                self.macro_wait(left)
            return True
        if act in ('EY', 'EY0'):
            if not self.SAFETY or not self.YY_EX_GATE:
                char.send_resonance_key(down_time=hold)
                char.record_resonance_use()
                self.macro_mark(f'{char.name[:2]}E')
                return False
            # 【两个都期望苍剑式】(用户 2026-10-11: "'EY'就是用在启动轴, 这一下强化e
            # 是换苍, 没有强化e则平a"):
            #   · 'EY'  = 强化E换苍 + 【允许点普攻攒流响】(没亮就平a, 上限 YY_EX_FILL)
            #             + 【按完不等核对, 立即返回】—— 后面那格就是切人, 等核对会拖慢它
            #   · 'EY0' = 强化E换苍 + 只读不点(参考代码原样) + 按完核对剑式
            entry = time.time()
            tag = f'{char.name[:2]}强化E换苍'
            ready, clicks = self.wait_yy_ex(tag, fill=0.0 if act == 'EY0' else None)
            if act == 'EY0' and not ready and self.YY_SKIP_CANG:
                self.skip_cang = True
                self.macro_mark(f'{tag}流响没空,不按E,这一轮不放苍')
                self.logger.warning(f'{tag}: 变奏后流响没空(前面普攻没打中?) —— 普通E 在羽剑式'
                                    f'按不出来, 这一轮放弃 1苍, 直接 Q R, 保住后面两个羽; '
                                    f'见 YY_SKIP_CANG')
                self.after_form_check(entry, hold, gap)
                return True
            self.send_e_once(f'{tag}({"亮" if ready else "没亮"},A x{clicks},'
                             f'{time.time() - entry:.2f}s)', char)
            if act == 'EY':
                # 【按完立即返回, 不等核对】(用户 2026-10-11: "我需要在e后立马切人")。
                # 只读一帧把剑式记进日志(排查用), 不做 fix_yy_form 那套"反了补按" ——
                # 那套会读屏最多 YY_FORM_WINDOW(0.80s) 并可能补按一次 E, 后面那格切人
                # 就被拖住了。代价: 这一下 E 要是被吞(剑式没换过去), 这一轮不会自动纠正。
                self.task.next_frame()
                form, _margin = self.yy_form()
                self.macro_mark(f'{tag}按后剑式{form or "读不到"}(不等核对)')
                return True
            self.fix_yy_form(tag, '苍', char)
            if self.YY_EX_SNAPSHOT:
                self.yy_ex_snapshot('after')
            self.after_form_check(entry, hold, gap)
            return True
        if act in ('E苍', 'E羽'):
            entry = time.time()
            if self.already_form(act[1]):
                # 已经是这个剑式了(上一轮/这一轮前面错过一次), 再按反而翻走 —— 不按
                self.macro_mark(f'{char.name[:2]}E(已是{act[1]},不按)')
                self.after_form_check(entry, hold, gap)
                return True
            # 【这一下 E 是"普通E"还是"强化E"由流响空没空决定】(参考代码帧数据表:
            # 流响为 0 时 E 才是强化E/剑式流转, 不为 0 按出来的是普通E —— 只换剑式)。
            # 【而羽剑式下普通E 是灰的、按不出来】("羽剑式下普通 E(常态切换剑式)按不出来,
            # 帧数据表: 中断优先级只有 1")—— 所以尾巴之后那次"换苍"本来就必须靠强化E,
            # 也就是流响得先空。流响靠【普攻打中】扣, 尾巴那几下普攻就是干这个的。
            # 把读数打进日志, 出问题时一眼能看出是哪一种(诊断, 只读不改流程)。
            if self.YY_LX_TRACE:
                try:
                    lx = self.liuxiang_level()
                    if lx is not None:
                        self.macro_mark(
                            f'{char.name[:2]}流响{lx:.2f}'
                            f'{"→强化E" if lx <= self.YY_DRAIN_ABOVE else "→普通E"}')
                except Exception:
                    pass
            char.send_resonance_key(down_time=hold)
            char.record_resonance_use()
            self.macro_mark(f'{char.name[:2]}E')
            self.fix_yy_form(f'{char.name[:2]}E', act[1], char)
            self.after_form_check(entry, hold, gap)
            return True
        if act == 'E':
            char.send_resonance_key(down_time=hold)
            char.record_resonance_use()
        elif act == 'R':
            char.send_liberation_key(down_time=hold)
            char.record_liberation_use()
        elif act == 'Q^':
            # 【按 Q 之前先把协奏打满】(用户 2026-10-11): 下一格就是变奏切秧秧, 协奏不满
            # 就拿不到变奏入场 —— 先"平a + E 连点"把协奏推满(上限 Q_GATE_WAIT),
            # 满了再按 Q(声骸), 然后交给下一格切人。
            if self.SAFETY and self.Q_GATE:
                self.wait_con_with_key(char, self.CON_FULL_LEVEL,
                                       tag=f'{char.name[:2]}等协奏',
                                       cap=self.Q_GATE_WAIT,
                                       key=char.send_resonance_key)
                # 【满协奏后先垫 Q_GATE_SETTLE 再按 Q】(用户 2026-10-16)
                if self.Q_GATE_SETTLE > 0:
                    self.macro_wait(self.Q_GATE_SETTLE)
            char.send_echo_key(down_time=hold)
            char.record_echo_use()
        elif act == 'Q':
            char.send_echo_key(down_time=hold)
            char.record_echo_use()
        else:
            raise ValueError('unknown macro action ' + repr(act))
        self.macro_mark(f'{char.name[:2]}{act}')
        return False

    def macro_switch(self, target, hold, con_full, gap):
        """宏里的数字键。返回【这一格的 gap 是不是已经用掉了】。

        SAFETY 关掉 = 按一下就走, 人按宏就是这样, 也继承了宏的风险: 上一个动作还没演完时
        游戏会拒绝切人, 这一下就白给, 后面每一格都发在错的人身上。
        SAFETY 开着 = 【在这一格自己的 gap 里盯到场】: 正常 0.1 秒就到, 剩下的 gap 照等,
        时序一点不变; 没到就按 SWITCH_REPRESS 补按, 最多再多等 SWITCH_EXTRA。
        con_full 只喂给框架记账(has_intro / 变奏冻结时间), 不读屏 —— 读一次协奏要几十毫秒
        到近一秒, 塞进宏的间隙里就把时序推歪了。
        """
        if target is None:
            # 【切到不在本队的角色就给个警告】(用户 2026-10-16): 4r 轴里有 '>CHI'(切千咲),
            # 本队没有千咲 —— 这一格按空操作走, 时间照等, 但日志要看得见
            self.logger.warning('宏表里有切到不在本队的角色(比如 >CHI) — 这一格空操作')
            return False
        if target is self.cur:
            self.macro_mark(f'>{target.name[:3]}(already)')
            return False
        source = self.cur if self.cur is not None else self
        slot = target.index + 1
        entry = time.time()
        self.switch_key_at = entry
        self.task.send_key(slot, down_time=hold)
        if not self.SAFETY:
            self.handoff(source, target, con_full)
            self.switch_arrived_at = time.time()
            self.macro_mark(f'>{target.name[:3]}{"^" if con_full else ""}')
            return False
        soft = entry + hold + gap
        hard = soft + self.SWITCH_EXTRA
        last = time.time()
        hits = 0
        arrived = False
        trace = []
        while time.time() < hard:
            self.task.next_frame()
            in_team, index, _count = self.task.in_team()
            if len(trace) < 40:
                trace.append(f'{time.time() - entry:.2f}:{index if in_team else "x"}')
            hits = hits + 1 if (in_team and index == target.index) else 0
            if hits >= self.SWITCH_CONFIRM:
                arrived = True
                break
            if time.time() - last >= self.SWITCH_REPRESS:
                self.task.send_key(slot, down_time=hold)
                last = time.time()
            self.macro_wait(0.02)
        cost = time.time() - entry
        late = time.time() - soft
        self.switch_arrived_at = time.time()
        if cost > self.SWITCH_TRACE_SLOW:
            self.logger.info(f'slow switch -> {target.name} ({cost:.2f}s): {" ".join(trace)}')
        if arrived:
            self.handoff(source, target, con_full)
            self.macro_mark(f'>{target.name[:3]}{"^" if con_full else ""}'
                            f'({cost:.2f}{f",晚{late:.2f}" if late > 0.05 else ""})')
            if con_full and self.INTRO_GAP_FROM_ARRIVAL:
                # 变奏格的 gap 是入场动作锁, 从到场算(见 INTRO_GAP_FROM_ARRIVAL)
                by_arrival = self.switch_arrived_at + hold + gap - self.SWITCH_NORMAL_LATENCY
                if by_arrival > soft + 0.02:
                    self.macro_mark(f'入场锁从到场算(+{by_arrival - soft:.2f})')
                    soft = by_arrival
        else:
            # 【没切过去就照实记】: 读一次场上到底是谁, 后面几格至少发在对的人身上
            actual = self.on_field_char()
            self.macro_desync += 1
            if actual is not None and actual is not target:
                if actual is not source:
                    self.handoff(source, actual, False)
                self.cur = actual
                self.macro_mark(f'>{target.name[:3]}超时({cost:.2f},场上是{actual.name[:3]})')
            else:
                # 读不到(演出/时停里 HUD 整个不在)——只能先按目标记, 但照样算一次失步
                self.handoff(source, target, con_full)
                self.macro_mark(f'>{target.name[:3]}超时({cost:.2f},读不到场上是谁)')
            self.logger.warning(f'macro switch to {target.name} never confirmed in '
                                f'{cost:.2f}s — 游戏在拒绝切人(被打断/上一个动作没演完?)')
        left = soft - time.time()
        if left > 0:
            self.macro_wait(left)
        return True

    def run_macro(self, table, tag):
        """逐条回放一张宏表。中间【一次读屏都没有】, 时间到就走下一格。"""
        mo = self.teammate('Mortefi')
        sui = self.teammate('Suisui')
        if mo is None or sui is None:
            return False
        chars = {'YY': self, 'MO': mo, 'SUI': sui}
        planned = sum(h + g for _, h, g, _ in table) / 1000.0 * self.MACRO_SPEED
        # 【开表之前等敌人】(用户 2026-10-15): 转火/轮次切换那 1~2 秒游戏不收输入,
        # 开头的 W/E/A 是单发、丢了就没了 —— 等敌人回来再开, 见 MACRO_WAIT_ENEMY
        if self.SAFETY:
            self.wait_enemy_back()
            # 【开表前也清一遍状态】(用户 2026-10-16 "循环轴开始时是否会清空所有状态"):
            # 之前只有羽重松手那一下清 —— 现在启动轴/每一轮循环开表前都清一次, 跟松手
            # 那下同一套(协奏/技能可用/处决提示全打掉), 第一格读到的都是当场状态。
            self.flush_key_caches('宏前')
        start = time.time()
        marks = len(self.macro_marks)
        self.skip_cang = False
        self.tight = False
        self.win_armed = False
        finished = False
        try:
            finished = self.play_rows(table, tag, chars, marks)
        finally:
            if not finished:
                # 【任务被停/出错也要留时间轴】: 手动停任务是异常一路抛上来的, 不写的话
                # 这一轮跑到哪、哪一格出的问题就全没了
                self.logger.info(f'{tag}(没跑完): {self.macro_timeline(marks)}')
        if finished:
            self.logger.info(f'{tag}: {len(table)} keys in {time.time() - start:.2f}s '
                             f'(table says {planned:.2f}s) — {self.macro_timeline(marks)}')
        return finished

    def play_rows(self, table, tag, chars, marks):
        """run_macro 的主体: 逐格回放。返回是不是整张表跑完了(失步放弃返回 False)。"""
        con_peeked = False
        for i, (act, hold_ms, gap_ms, _note) in enumerate(table):
            hold = hold_ms / 1000.0 * self.MACRO_SPEED
            gap = gap_ms / 1000.0 * self.MACRO_SPEED
            nxt = table[i + 1][0] if i + 1 < len(table) else ''
            if act == 'WIN':
                # 只是标记, 不按键不占时间: 窗口起点是【下一个切人键按下】那一刻。
                # 【本队的轴没有这个标记 —— 这段整段是惰性的, 见 YANLAN_WINDOW 那段注释】
                self.tight = True
                self.win_armed = True
                continue
            if act.startswith('>'):
                con_full = act.endswith('^')
                target = chars.get(act[1:].rstrip('^'))
                if con_full and con_peeked:
                    self.macro_mark('协奏已满(提前读)')
                elif con_full and self.CON_GATE_BEFORE_INTRO and self.CON_GATE_WAIT > 0:
                    # 【变奏那一格之前先把协奏打满】, 见 CON_GATE_BEFORE_INTRO。
                    # 读到的是【现在场上那个人】的协奏圈 —— 变奏是他交出去的
                    holder = self.cur if self.cur is not None else self
                    # 【先把缓存打掉再读】: BaseChar.get_current_con() 开头是
                    # `if self.current_con == 1: return 1` —— 上一轮留下的 1 会让
                    # 整个闸门【一帧屏都不读就放行】, 等于没加。缓存只在"满协奏切出"
                    # 和重读队伍时才清, 中途切人失败那一类根本走不到那里。
                    # 清掉不影响记账: 下面拿到的 con_full 才是喂给 switch_out 的那个值
                    holder.current_con = 0
                    # 【读之前先刷一帧】: wait_con_at_least 内部不调 next_frame(),
                    # 读的是 task.frame 那张缓存帧 —— 上一格如果是纯 macro_wait, 读到的
                    # 就是几百毫秒前的画面。实机见过 `等协奏(1.00,ok,A x0,0.01s)`:
                    # 0.01 秒、一下没点就"满", 快得不像真读了一次协奏环
                    self.task.next_frame()
                    to_me = target is self
                    if holder is self:
                        # 【秧秧自己交棒的那一格: 只读一次, 不点也不等】
                        # 参考代码对循环开头那一格有明确记录: "千咲到这里只打过 A x1 + E + A x1,
                        # 协奏物理上攒不起来, 加了 '^' 实机是 `等协奏(0.22,CAP,A x26,3.58s)`
                        # —— 白等 3.58 秒、多点 26 下 A"。用户看到的"羽重打完后自动a完整一套"
                        # 就是这个: 协奏没满 -> 闸门一直点普攻攒(每 0.12 秒一下)。
                        # 【这里改成只读】: 协奏真满就照记变奏(穗穗拿到濯雨时); 不满就按平切
                        # 记账并报警告 —— 不再拿普攻去凑, 间隔也就固定了。
                        # 莫特斐/穗穗交棒的那几格【保持参考代码的攒法】: 那是他们自己的资源,
                        # 点普攻攒正是那几格要做的事。
                        con_full = self.peek_con_full(holder)
                    else:
                        con_full = self.wait_con_at_least(
                            holder, self.CON_FULL_LEVEL,
                            tag=f'{holder.name[:2]}等协奏{"→秧" if to_me else ""}',
                            cap=self.CON_GATE_WAIT_INTRO if to_me else self.CON_GATE_WAIT)
                    if not con_full:
                        # 【文案要跟着目标走】: 带 ^ 的格子后果不一样 ——
                        # 只有交给秧秧那次丢的是羽挟苍空
                        who = target.name if target is not None else '下一个人'
                        extra = ('(羽挟苍空没了, 末尾的 1苍 会打空)' if target is self else '')
                        self.logger.warning(
                            f'{tag}: {holder.name} 协奏没打满就到变奏格了 — 这一下按平切记账, '
                            f'{who} 拿不到变奏入场{extra}')
                if self.tight and act.endswith('^') and self.win_t0 > 0 and self.SAFETY:
                    # 翾舞1 之前持有者不能走(前置还没挂上), 见 YANLAN_MIN
                    early = self.YANLAN_MIN - self.time_elapsed_accounting_for_freeze(self.win_t0)
                    if early > 0:
                        self.macro_mark(f'等翾舞1({early:.2f})')
                        self.macro_wait(early)
                consumed = self.macro_switch(target, hold, con_full, gap)
                self.last_was_switch = True
                if self.win_armed:
                    self.win_armed = False
                    self.win_t0 = self.switch_key_at
                    self.win_log = []
                    self.macro_mark(f'烟岚窗口起(按键@{self.win_t0 - self.macro_t0:.2f})')
                elif self.tight:
                    self.win_log.append((act[1:].rstrip('^'), self.time_elapsed_accounting_for_freeze(
                        self.win_t0) - (time.time() - self.switch_key_at)))
                    if act.endswith('^'):
                        self.close_yanlan_window(tag, con_full)
            else:
                consumed = self.macro_key(act, hold, gap)
                self.last_was_switch = False
            con_peeked = False
            if not consumed:
                if (nxt.startswith('>') and nxt.endswith('^') and self.SAFETY
                        and self.CON_GATE_BEFORE_INTRO and self.CON_GATE_WAIT > 0
                        and gap >= self.CON_PEEK_LEAD + 0.05):
                    # 下一格是变奏: 趁这段空等提前读一次协奏, 见 CON_PEEK_LEAD
                    end = time.time() + gap
                    self.macro_wait(gap - self.CON_PEEK_LEAD)
                    con_peeked = self.peek_con_full(self.cur if self.cur is not None else self)
                    left = end - time.time()
                    if left > 0:
                        self.macro_wait(left)
                else:
                    self.macro_gap(gap)
            if self.macro_desync >= self.MACRO_ABORT_DESYNC:
                self.tight = False
                self.macro_mark(f'{tag}_放弃(失步x{self.macro_desync})')
                self.logger.warning(
                    f'{tag}: 切人累计 {self.macro_desync} 次没确认, 这一轮宏放弃 —— '
                    f'交回框架, 下一次从循环宏开头重来 (被打断了?)')
                return False
        return True

    def peek_con_full(self, holder):
        """读一次 holder 的协奏满没满(真满 1.0, 不是 0.99 那个哨兵值)。只读不点。

        先把 BaseChar 的缓存打掉、再刷一帧, 理由跟 play_rows 里协奏闸那段一样。
        """
        holder.current_con = 0
        self.task.next_frame()
        try:
            return float(holder.get_current_con()) >= self.CON_FULL_LEVEL
        except Exception:
            return False

    # ==================== 各格用到的读屏/按键小工具 ====================

    def yy_ex_ready(self):
        """秧秧的 E 现在是不是强化E(流响打空了)。读不到返回 None。判据见 YY_EX_GATE。"""
        return self.yy_ex_read()[0]

    def yy_ex_read(self):
        """同 yy_ex_ready, 顺带返回读数 (结果, 环, 环外, "^^")。环外/"^^" 没算到的是 -1。"""
        try:
            box = self.task.get_box_by_name('box_resonance')
            frame = self.task.frame
            cx, cy, bh = box.x + box.width / 2, box.y + box.height / 2, box.height
            fh, fw = frame.shape[:2]
            ang = [i * 2 * math.pi / 48 for i in range(48)]

            def cover(k):
                n = 0
                for a in ang:
                    x = int(round(cx + k * bh * math.cos(a)))
                    y = int(round(cy + k * bh * math.sin(a)))
                    if not (0 <= x < fw and 0 <= y < fh):
                        continue
                    b, g, r = (int(v) for v in frame[y, x][:3])
                    # 【放宽过一次】: 实机 2560x1440 上那圈暗红环按 r-g>=30/r>=b/r>=60 只覆盖
                    # 0.56(录屏里 0.77), 放宽到下面这组后 0.94; 录屏 18 个样本 + 236 帧
                    # 普通段仍零误判
                    if r - g >= 25 and r + 15 >= b and r >= 50:
                        n += 1
                return n / len(ang)

            ring = max(cover(k) for k in self.YY_EX_RING_K)
            if ring < self.YY_EX_RING_MIN:
                return False, ring, -1.0, -1.0
            out = max(cover(k) for k in self.YY_EX_OUT_K)
            if out <= self.YY_EX_OUT_MAX:
                return True, ring, out, -1.0
            # 背景整片染红: 看 "^^"(图案右下角那两道白色折角)
            x0, x1 = int(cx + 0.10 * bh), int(cx + 0.42 * bh)
            y0, y1 = int(cy + 0.12 * bh), int(cy + 0.48 * bh)
            patch = frame[y0:y1, x0:x1, :3]
            if patch.size == 0:
                return False, ring, out, -1.0
            chev = float((patch.min(axis=2) >= 190).mean())
            return (ring >= self.YY_EX_RING_MIN_FLOOD and chev >= self.YY_EX_CHEV_MIN), ring, out, chev
        except Exception as e:
            self.logger.info(f'yy_ex_ready probe failed ({e})')
            return None, -1.0, -1.0, -1.0

    def yy_ex_snapshot(self, kind):
        """把 E 图标(连外面那圈环)和流响条存成一张小 png, 排查用。开关 YY_EX_SNAPSHOT。"""
        if not self.YY_EX_SNAPSHOT:
            return
        try:
            frame = self.task.frame
            box = self.task.get_box_by_name('box_resonance')
            fh, fw = frame.shape[:2]
            cx, cy, h = int(box.x + box.width / 2), int(box.y + box.height / 2), int(box.height * 1.1)
            icon = frame[max(0, cy - h):cy + h, max(0, cx - h):cx + h, :3]
            bar = frame[int(fh * 0.875):int(fh * 0.93), int(fw * 0.41):int(fw * 0.58), :3]
            # 图标保持原尺寸(看得清那圈环), 流响条放大到同样高
            bar = cv2.resize(bar, (icon.shape[0] * bar.shape[1] // max(1, bar.shape[0]), icon.shape[0]))
            img = cv2.hconcat([icon, bar])
            folder = os.path.join('logs', 'yy_ex')
            os.makedirs(folder, exist_ok=True)
            name = f'{time.strftime("%H%M%S")}_{int(time.time() * 1000) % 1000:03d}_{kind}.png'
            ok, buf = cv2.imencode('.png', img)
            if ok:
                buf.tofile(os.path.join(folder, name))
                self.logger.info(f'yy_ex snapshot saved: {folder}/{name}')
        except Exception as e:
            self.logger.info(f'yy_ex snapshot failed ({e})')

    def yy_ex_after_check(self, tag):
        """按完 E 之后读一次图标并存图(排查用)。强化E 按出去了: 环灭、流响回满。只记录不补按。"""
        self.task.next_frame()
        ready, ring, out, chev = self.yy_ex_read()
        self.yy_ex_snapshot('after')
        if ready:
            self.macro_mark(f'{tag}按后环还亮')
            self.logger.warning(f'{tag}: 按完 E 0.2s 图标还是强化态(环{ring:.2f}/环外{out:.2f}) — '
                                f'这一下 E 多半没按出去, 剑式可能没切(后面苍/羽会错位)')
        else:
            self.macro_mark(f'{tag}按后环灭')

    def yy_form(self):
        """秧秧现在是哪个剑式: 读 E 图标中间的图案(见 YY_FORM_CHECK)。返回 (苍/羽/None, 分差)。"""
        try:
            if not self.task.in_team()[0]:
                return None, 0.0
            tv = getattr(self, '_yy_glyph_vecs', None)
            if tv is None:
                raw = base64.b64decode(''.join(self.YY_GLYPHS))
                arr = np.frombuffer(raw, np.uint8).reshape(8, 16, 16).astype(np.float32)
                tv = self._yy_glyph_vecs = [self.glyph_vec(a) for a in arr]
            box = self.task.get_box_by_name('box_resonance')
            frame = self.task.frame
            cx, cy = int(box.x + box.width / 2), int(box.y + box.height / 2)
            h = int(box.height * 1.1)
            icon = frame[max(0, cy - h):cy + h, max(0, cx - h):cx + h, :3]
            g = cv2.cvtColor(cv2.resize(icon, (96, 96), interpolation=cv2.INTER_AREA),
                             cv2.COLOR_BGR2GRAY).astype(np.float32)
            yy, xx = np.mgrid[:96, :96]
            g = g * (((xx - 48) ** 2 + (yy - 44) ** 2) <= 25 ** 2)
            v = self.glyph_vec(cv2.resize(g[18:70, 22:74], (16, 16), interpolation=cv2.INTER_AREA))
            score = [float(v @ t) for t in tv]
            cang, yu = max(score[:4]), max(score[4:])
            margin = abs(cang - yu)
            if max(cang, yu) < self.YY_FORM_MIN_SCORE or margin < self.YY_FORM_MARGIN:
                return None, margin
            return ('苍' if cang > yu else '羽'), margin
        except Exception as e:
            self.logger.info(f'yy_form probe failed ({e})')
            return None, 0.0

    @staticmethod
    def glyph_vec(a):
        v = a.astype(np.float32).flatten()
        v = v - v.mean()
        n = float(np.linalg.norm(v))
        return v / n if n > 0 else v

    def fix_yy_form(self, tag, target, char):
        """按完秧秧的 E 之后核对剑式, 不是 target 就补一次 E(见 YY_FORM_CHECK)。只在读得准时动手。"""
        if not (self.SAFETY and self.YY_FORM_CHECK):
            return
        pressed = time.time()
        fixes = wrong = 0
        seen = None
        while True:
            self.macro_wait(0.03)
            self.task.next_frame()
            form, margin = self.yy_form()
            now = time.time()
            if form == target:
                if fixes:
                    self.macro_mark(f'{tag}剑式补成{target}')
                return
            if form is not None:
                seen = form
                if now - pressed >= self.YY_FORM_WRONG_AFTER:
                    wrong += 1
            if wrong >= 2:
                if fixes >= self.YY_FORM_FIX:
                    self.macro_mark(f'{tag}剑式还是{form}(不再补)')
                    self.logger.warning(f'{tag}: 补了 E 剑式还是{form}(该是{target}) —— 不再按, '
                                        f'这一轮后面的苍/羽会错位')
                    return
                self.yy_ex_snapshot('form')
                self.macro_mark(f'{tag}剑式是{form}→补E')
                self.logger.warning(f'{tag}: 按完 E 剑式还是{form}(该是{target}, 分差{margin:.2f}) '
                                    f'—— 这一下 E 没生效, 补一次')
                char.send_resonance_key(down_time=self.M_E_KEY_DOWN)
                char.record_resonance_use()
                fixes += 1
                wrong = 0
                pressed = time.time()
                continue
            if now - pressed >= self.YY_FORM_WINDOW:
                if seen is None:
                    self.macro_mark(f'{tag}剑式读不到')
                return

    def already_form(self, target):
        """按秧秧的普通 E 之前: 连着两次(隔 >= 0.03s)都读到已经是 target 剑式才算。读不准就当不是。"""
        if not (self.SAFETY and self.YY_FORM_CHECK):
            return False
        first = None
        for _ in range(4):
            self.task.next_frame()
            form, _margin = self.yy_form()
            if form != target:
                return False
            if first is None:
                first = time.time()
            elif time.time() - first >= 0.03:
                return True
            self.macro_wait(0.02)
        return False

    def after_form_check(self, entry, hold, gap):
        """E 那一格收尾: 宏表的时间还没用完就等完; 核对剑式用超了, 超出的记给紧跟的长按去扣。"""
        left = (hold + gap) - (time.time() - entry)
        if left > 0:
            self.macro_wait(left)
        else:
            self.hold_credit = min(0.5, -left)

    def liuxiang_level(self):
        """秧秧流响条还剩多少(0~1)。读不到返回 None。

        条是一格格粉色竖条从左往右排, 没满的部分是灰点; 取【从最左边连着的粉色】能延伸到哪。
        流响空了整条换成蓝羽毛 -> 0。截图上量过 300 多张: 强化E 亮的时候 95/99 读 0,
        按完强化E 回满读 0.99~1.00, 进 'AX' 那一格读 0.11~0.29 跟肉眼一致。
        """
        try:
            frame = self.task.frame
            fh, fw = frame.shape[:2]
            x0, x1 = int(fw * self.LX_BAR_X[0]), int(fw * self.LX_BAR_X[1])
            y0, y1 = int(fh * self.LX_BAR_Y[0]), int(fh * self.LX_BAR_Y[1])
            hsv = cv2.cvtColor(frame[y0:y1, x0:x1, :3], cv2.COLOR_BGR2HSV)
            pink = ((hsv[..., 0] >= 140) & (hsv[..., 0] <= 168)
                    & (hsv[..., 1] >= 80) & (hsv[..., 2] >= 150))
            cols = [i for i, v in enumerate(pink.mean(axis=0)) if v >= 0.15]
            width = x1 - x0
            if not cols or cols[0] > width * 0.05:
                return 0.0
            gap = max(2, int(width * 0.03))   # 竖条之间的空隙
            right = cols[0]
            for c in cols[1:]:
                if c - right > gap:
                    break
                right = c
            return (right + 1) / width
        except Exception as e:
            self.logger.info(f'liuxiang_level probe failed ({e})')
            return None

    def drain_liuxiang(self, tag):
        """'AX' 那一格: 流响还剩超过 YY_DRAIN_ABOVE 才点普攻打, 打到这条线就停。

        剩得不多就一下不点, 直接去长按。先等技能栏换过来(YY_EX_SETTLE), 不然读到的是上一个人的条。
        读不到(HUD 被盖住)就当没事, 照表走。
        """
        start = time.time()
        self.macro_wait(max(0.0, self.YY_EX_SETTLE - (start - self.switch_arrived_at)))
        first = level = None
        clicks = high = 0
        next_click = first_click = 0.0
        while True:
            self.task.next_frame()
            level = self.liuxiang_level() if self.task.in_team()[0] else None
            if level is None:
                # HUD 一时被特效盖住: 给 0.1 秒再读, 还读不到就照表走
                if time.time() - start < self.YY_EX_SETTLE + 0.10:
                    self.macro_wait(0.02)
                    continue
                break
            if first is None:
                first = level
            if level <= self.YY_DRAIN_ABOVE:
                break
            if self.yy_ex_read()[0]:
                # E 图标已经是强化态 = 流响空了(条上残留的是特效/没刷新)
                level = 0.0
                break
            # 【连着两帧都高才动手】: 特效盖在条上时会整条读成满(录屏上见过 0.28 -> 1.00 -> 0.28),
            # 读错成高就是白打一串普攻、连带后面那格慢下来; 读错成低最多是这一轮照老样子不打
            high += 1
            if high < 2:
                self.macro_wait(0.02)
                continue
            if high == 2:
                self.yy_ex_snapshot('first')
            now = time.time()
            if now - start >= self.YY_DRAIN_CAP:
                self.yy_ex_snapshot('cap')
                break
            if clicks and now - first_click >= self.YY_DRAIN_NO_PROGRESS and level > first - 0.02:
                self.macro_mark(f'{tag}打不动')
                self.logger.info(f'{tag}: 点了 {now - first_click:.2f}s 流响 {first:.2f} -> {level:.2f} '
                                 f'没降, 多半打不到怪 —— 不点了')
                break
            if now >= next_click:
                if not clicks:
                    first_click = now
                self.click()
                clicks += 1
                next_click = now + self.YY_EX_FILL_INTERVAL
            self.macro_wait(0.02)
        if first is None:
            self.macro_mark(f'{tag}读不到(不打)')
        elif not clicks:
            seen = f'{first:.2f}' if level is None or level == first else f'{first:.2f}/{level:.2f}'
            self.macro_mark(f'{tag}{seen}(不打)')
        else:
            got = '' if level is None else f'{level:.2f}'
            self.macro_mark(f'{tag}{first:.2f}->{got}(A x{clicks},{time.time() - start:.2f}s)')

    def wait_yy_ex(self, tag, fill=None, mark_ok=False):
        """等秧秧的强化E 可用(= 流响打空): 先只读(刚切进来技能栏还没换过来), 没亮再边点普攻边读。

        fill: 点普攻的上限(秒), 默认 YY_EX_FILL; 0 = 只读不点(读 YY_EX_READ_ONLY 秒)。
        返回 (亮没亮, 点了几下)。读不到(None)按"亮"处理 —— 退回原来的照表走。
        """
        fill = self.YY_EX_FILL if fill is None else fill
        window = fill if fill > 0 else self.YY_EX_READ_ONLY
        start = time.time()
        settle = max(0.0, self.YY_EX_SETTLE - (start - self.switch_arrived_at))
        streak = clicks = 0
        next_click = 0.0
        trace = []
        last_trace = 0.0
        snapped = False
        while True:
            # 【先读再点】: 已经亮着的话一下都不点, 直接去按 E(原来先点一下再读, 白打一下普攻)
            self.task.next_frame()
            hud = self.task.in_team()[0]
            ready, ring, out, chev = self.yy_ex_read() if hud else (False, -1.0, -1.0, -1.0)
            if ready is None:
                return True, clicks
            if len(trace) < 40 and time.time() - last_trace >= 0.09:
                last_trace = time.time()
                trace.append(f'{last_trace - start:.2f}:{ring:.2f}/{out:.2f}/{chev:.2f}'
                             f'{"" if hud else "x"}')
            streak = streak + 1 if ready else 0
            if streak >= self.YY_EX_CONFIRM:
                if clicks:
                    self.macro_mark(f'{tag}打空流响({time.time() - start:.2f}s,A x{clicks})')
                    self.logger.info(f'{tag}: 环/环外/^^ trace — {" ".join(trace)}')
                else:
                    self.macro_mark(f'{tag}读数{ring:.2f}/{out:.2f}/{chev:.2f}')
                if mark_ok and not clicks:
                    self.macro_mark(f'{tag}(已空)')
                self.yy_ex_snapshot('ok')
                return True, clicks
            now = time.time()
            elapsed = now - start
            if not ready and not snapped and hud and elapsed >= settle:
                snapped = True
                self.yy_ex_snapshot('first')
            if elapsed >= settle + window:
                break
            if fill > 0 and elapsed >= settle and not ready and now >= next_click:
                self.click()
                clicks += 1
                next_click = now + self.YY_EX_FILL_INTERVAL
            self.macro_wait(0.02)
        self.yy_ex_snapshot('cap')
        self.macro_mark(f'{tag}没亮(CAP,A x{clicks})')
        if fill > 0:
            self.logger.info(f'{tag}: {fill:.1f}s 点了 {clicks} 下普攻流响还没打空(多半没打中) — '
                             f'照往下走, 这一轮多半少 1 点苍翎; 环/环外/^^ trace — {" ".join(trace)}')
        else:
            self.logger.info(f'{tag}: 流响没打空, 这时点普攻打出来的是羽强化A(不扣流响还会吃掉第二个羽), '
                             f'不点; 环/环外/^^ trace — {" ".join(trace)}')
        return False, clicks

    def send_e_once(self, tag, char=None):
        """发一次 E(按住 M_E_KEY_DOWN)。

        【秧秧的 E 绝对不能连发】: 剑式切换每按一次换一个形态, 连发两下等于换回去了。
        """
        char = self if char is None else char
        char.send_resonance_key(down_time=self.M_E_KEY_DOWN)
        char.record_resonance_use()
        self.macro_mark(tag)

    # ==================== 穗穗的闸 ====================

    def sui_e1_lit(self):
        """穗穗的强化E(醒春潮)就绪没有 —— 读的是 E 图标那张强化态模板。"""
        return bool(self.task.find_one(Labels.suisui_e1, threshold=self.SUI_E1_THRESHOLD))

    def fill_sui_e1(self, char, tag):
        """强化E 图标不亮(= 回路没满)就接着点普攻攒, 亮了立刻停手。返回亮了没有。"""
        if self.SUI_E1_FILL <= 0:
            self.task.next_frame()
            return self.sui_e1_lit()
        start = time.time()
        n = 0
        next_click = 0.0
        while time.time() - start < self.SUI_E1_FILL:
            self.task.next_frame()
            if self.sui_e1_lit():
                if n:
                    self.macro_mark(f'{tag}攒回路({time.time() - start:.2f}s,A x{n})')
                return True
            now = time.time()
            if now >= next_click:
                self.click()
                n += 1
                next_click = now + self.SUI_E1_FILL_INTERVAL
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}攒回路(CAP,A x{n})')
        self.logger.warning(f'{tag}: 回路 {self.SUI_E1_FILL:.1f}s 没攒满(点了 {n} 下 A) — '
                            f'强化E 这一轮开不出来')
        return False

    def cast_sui_e1(self, char, tag):
        """按到 suisui_e1 这张图消失 —— 消失才等于强化E(醒春潮)真的放出去了。

        【为什么要连按】: 这一格紧跟在切人后面, 入场动画会把单发吞掉(跟 fire_r 一个道理)。
        【连按在这里是安全的】: 图标一消失就停手, 多按的那几下落不到第二次 E 上。
        """
        start = time.time()
        n = 0
        while time.time() - start < self.SUI_E1_CAST_CAP:
            char.send_resonance_key(down_time=self.M_E_KEY_DOWN)
            n += 1
            self.macro_wait(self.SUI_E1_KEY_INTERVAL)
            self.task.next_frame()
            if not self.sui_e1_lit():
                self.macro_mark(f'{tag}强化E出手(x{n},{time.time() - start:.2f}s)')
                return True
        self.macro_mark(f'{tag}强化E没出手(x{n},CAP)')
        self.logger.warning(f'{tag}: 按了 {n} 下 suisui_e1 还亮着 — 这几下多半被吞了'
                            f'(入场动画/硬直?), 这一轮穗穗进不了濯雨时')
        return False

    def forte3_full(self):
        """穗穗的三段回路(芳菲信 600)满没满。

        【这几帧连着读完, 中间不做别的】—— 靠外层循环去凑命中次数会白白多等一轮。
        HUD 被演出盖住时读不到, 返回 False 落在"还没满"这一侧, 方向是安全的
        (顶多多点几下普攻, 不会误判成满就去放大招)。
        """
        for i in range(self.FORTE3_CONFIRM):
            if not self.task.find_one(Labels.suisui_forte3, threshold=self.FORTE3_THRESHOLD):
                return False
            if i + 1 < self.FORTE3_CONFIRM:
                self.task.next_frame()   # 换一帧再读, 否则两次读的是同一张图
        return True

    def wait_forte3(self, tag):
        """穗穗大招前的保底: 三段回路没满就接着点普攻, 满了立刻停手。返回满了没有。

        上限 FORTE3_WAIT 到了【照放不误】: 少一档伤害, 好过把整轮宏卡死在这一格。
        """
        if not self.FORTE3_GATE:
            return True
        start = time.time()
        n = 0
        next_click = 0.0
        while time.time() - start < self.FORTE3_WAIT:
            # 【先点再读】(用户: "穗穗最后回路没满要补的时候, 经常卡顿一下才A")。
            # forte3_full() 要连读 FORTE3_CONFIRM 帧, 一帧 next_frame 就几十毫秒 ——
            # 把读屏放在点击前面, 进这一格的第一下 A 就被硬生生压后, 手感上就是"卡一下"。
            # 判据晚一轮(0.02s)成立没有任何代价, 第一下 A 晚 60ms 是看得出来的
            now = time.time()
            if now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            if self.forte3_full():
                waited = time.time() - start
                self.macro_mark(f'{tag}满({waited:.2f}s,A x{n})')
                if n <= 1 and waited < self.FORTE3_SUSPECT:
                    # 【一下没点就"满"了, 十有八九是误判】。穗穗有两个形态两条【不同】的
                    # 资源条: 浣尘时显示【水云息】, 濯雨时才是【芳菲信】; 而 suisui_forte3
                    # 匹配的是芳菲信满档那张图 —— 她要是没进濯雨时(E 被吞, 醒春潮没放出来),
                    # 读的就是水云息那条条, 会误命中。
                    self.logger.info(
                        f'{tag}: {waited:.2f}s 一下没点就读到"回路满"(循环轮常见: 前面上场已经攒满); '
                        f'要是这一轮伤害不对, 再怀疑穗穗没进濯雨时、读到的是水云息那条')
                return True
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}没满(CAP,A x{n})')
        self.logger.warning(f'{tag}: 三段回路 {self.FORTE3_WAIT:.1f}s 没攒满(点了 {n} 下 A), '
                            f'照放 —— 表里给穗穗的 A 不够, 或者那几下被打断了')
        return False

    # ==================== 宏里几种专用的格子 ====================

    def settle_before_hold(self, hold):
        """切人之后紧跟着的长按, 先等入场演完再按下去(见 HOLD_AFTER_SWITCH)。

        【从确认到场那一刻算, 只补差额】: 切人格自己的 gap 已经等过的部分不再重复等。
        烟岚窗口里换成 TIGHT_HOLD_AFTER_SWITCH(默认 0)。
        """
        if not (self.SAFETY and self.last_was_switch and hold >= self.HOLD_SETTLE_MIN):
            return
        settle = self.TIGHT_HOLD_AFTER_SWITCH if self.tight else self.HOLD_AFTER_SWITCH
        left = settle - (time.time() - self.switch_arrived_at)
        if left > 0:
            self.macro_wait(left)
            self.macro_mark(f'长按前等入场({left:.2f})')

    def hold_traced(self, hold, tag, early=False):
        """按住左键 hold 秒, 【中途一下都不松】; 期间隔一会儿读一次重击就绪图标打日志。

        前台时走 SendInput(见 YY_TAIL_SENDINPUT), 时间轴里 SI = SendInput, PM = PostMessage。

        秧秧的重击要连续按住才派生, 松开重按会把蓄力打断, 所以这里【只读不动】——
        读屏不发输入, 不影响按住的状态。

        early=True 时多一件事(用户 2026-10-11 "仅做1"): 读到"灭"(重击已出手)并且
        连读 HOLD_EARLY_CONFIRM 次都灭 -> 提前松手, 把后面的溢出普攻省掉。
        约束见 HOLD_EARLY_* 那几个常量的注释(连读确认 / 至少按了多久 / 留多少余量)。
        """
        direct = self.attack_down(self.YY_TAIL_SENDINPUT and self.game_foreground())
        start = time.time()
        # 【硬上限 = 标称 + 延长】(用户 2026-10-16): 形态判据开启时, 标称时长只是"最短" ——
        # 剑锋还在就一直按, 见 YY_HOLD_EXTEND。松手仍由形态(变月牙剑)决定。
        hard = hold + (self.YY_HOLD_EXTEND if (early and self.YY_GLYPH_GATE) else 0.0)
        trace = []
        next_read = 0.0
        read_no = 0
        dark_hits = 0
        saw_lit = False
        saw_halo = False
        saw_a = False
        glyph_dead = 0
        early_at = 0.0
        glyph = [-9.0, -9.0]
        use_halo = self.halo_usable()
        # 【读屏的间隔】: 要提前松手就密一点(0.15s, 两帧确认共 0.3s); 只打日志就照旧 0.30s
        every = self.HOLD_READ_EVERY if (early and self.HOLD_EARLY_RELEASE) else self.M_YU_TRACE_EVERY
        try:
            while True:
                left = hard - (time.time() - start)
                if left <= 0:
                    break
                # 快到点了就别再读屏: 一次读屏几十毫秒, 会把松手推迟
                pending = getattr(self, 'yy_ex_verify_pending', None)
                if pending and time.time() - start >= 0.20 and left > 0.10:
                    self.yy_ex_verify_pending = None
                    self.yy_ex_after_check(pending)
                if self.M_YU_TRACE and left > 0.10 and time.time() - start >= next_read:
                    next_read = (time.time() - start) + every
                    read_no += 1
                    self.task.next_frame()
                    ratio = -1.0
                    halo = -1.0
                    glyph = [-9.0, -9.0]      # 每次读都重置, trace 里只显示当场算出来的
                    try:
                        if use_halo:
                            # 光圈(蓄力/派生)判据, 见 HALO_* 那一段
                            halo = self.halo_read()
                            if halo >= self.HALO_MIN:
                                saw_halo = True
                        if not self.task.in_team()[0]:
                            lit = 0
                        elif self.YY_CANG_ICON:
                            # 【读普攻按钮上的苍重/羽重图标】(用户 2026-10-15):
                            # 位置/判据见 yy_cang_icon_read 和 YY_CANG_ICON_* 那一段
                            ratio = self.yy_cang_icon_read()
                            lit = 1 if ratio >= self.YY_CANG_ICON_MIN else 0
                        else:
                            lit = 1 if self.is_mouse_forte_full() else 0
                        # 【形态在这里就读掉】(用户 2026-10-16): 之前放在下面 done 段里,
                        # 结果 trace 打印时 glyph 还是重置值 -> 日志里永远看不到"形"。
                        if self.YY_GLYPH_GATE:
                            glyph[0], glyph[1] = self.yy_glyph_read()
                    except Exception:
                        lit = -1
                    if read_no % 2 == 1:      # 日志保持 0.30s 一条, 不刷屏
                        trace.append(f'{time.time() - start:.2f}:{lit}'
                                     + (f'/{ratio:.2f}' if ratio >= 0 else '')
                                     + (f'|圈{halo:.2f}' if halo >= 0 else '')
                                     + (f'|形{glyph[0]:.2f}/{glyph[1]:.2f}'
                                        if glyph[1] > -9.0 else ''))
                    if lit == 1:
                        saw_lit = True
                    # 【提前松手】: 灭 = 重击已出手(苍翎被清空), 再按着的都是溢出普攻。
                    # 【必须见过"亮→灭"的跳变】: 本格一次都没读到亮(图标被特效盖住、
                    # 或者进这一格时苍翎本来就是 0)就不许松 —— 那种情况下"灭"不是出手信号,
                    # 松了就是把正在蓄的重击打断(参考代码实机 12 轮栽 10 轮的那个坑)。
                    # 【出手判据】: 0链账号用光圈(白图标在蓄力里会闪灭, 不能当判据);
                    # 其它情况沿用白图标。见 HALO_* 那一段。
                    # 【出手判据只有一个: 形态从"剑锋"变成"月牙剑"】(用户 2026-10-16):
                    # 光圈/白图标只进日志不参与判定 —— 视频实测: 蓄力段全程 A剑锋,
                    # 打完才是 B月牙(9.8~10.1s), 中间那些 0.1~0.3s 的假 B 闪靠
                    # "必须先见过剑锋 + 连读 2 次 + 白图标亮"滤掉。见 YY_GLYPH_* 那一段。
                    if self.YY_GLYPH_GATE:
                        ga, gb = glyph[0], glyph[1]
                        done = False
                        if ga <= -9.0:
                            # 【形态读不到就别硬撑】(用户 2026-10-16): 读屏坏了的话
                            # 一直延长会白按到硬上限 —— 连读 3 次读不到就按标称收手
                            glyph_dead += 1
                            if glyph_dead >= 3 and time.time() - start >= hold:
                                break
                        else:
                            glyph_dead = 0
                            if ga - gb >= self.YY_GLYPH_MARGIN:
                                saw_a = True
                            # 【不再要求"白图标亮"】(用户 2026-10-16): 实机白图标在蓄力里
                            # 就闪灭, 这道门会把真正的月牙剑也挡掉; 假闪由门槛+连读挡
                            elif saw_a and gb - ga >= self.YY_GLYPH_MARGIN:
                                done = True
                    else:
                        done = (lit == 0)
                    need = self.YY_GLYPH_CONFIRM if self.YY_GLYPH_GATE else self.HOLD_EARLY_CONFIRM
                    if (early and self.HOLD_EARLY_RELEASE and saw_lit and done
                            and time.time() - start >= self.HOLD_EARLY_AFTER
                            and left > self.HOLD_EARLY_MIN_LEFT):
                        dark_hits += 1
                        if dark_hits >= need:
                            early_at = time.time() - start
                            break
                    else:
                        dark_hits = 0
                self.macro_wait(min(0.05, max(0.0, hold - (time.time() - start))))
        finally:
            self.release_attack()
        if early_at <= 0 and early and self.YY_GLYPH_GATE:
            self.logger.info(f'{tag}: 没提前松手(按到 {time.time() - start:.2f}s) — 形态最后 '
                             f'A={glyph[0]:.2f} B={glyph[1]:.2f} 见过剑锋={saw_a} '
                             f'见过亮={saw_lit} 形态读不到={glyph_dead}次')
        if early_at > 0:
            # 【清空按键/技能缓存】(用户 2026-10-15): 见 flush_key_caches
            self.flush_key_caches('')
            self.macro_mark(f'{tag}重击已出手, 提前松手({early_at:.2f}s)')
            why = '变月牙剑' if self.YY_GLYPH_GATE else '图标灭'
            self.logger.info(f'{tag}: 重击已出手({why}) — 提前松手 '
                             f'{early_at:.2f}s(标称 {hold:.2f}s), 省掉溢出普攻')
        self.macro_mark(f'{tag}({time.time() - start:.2f}s,{"SI" if direct else "PM"})')
        if trace:
            self.logger.info(f'{tag}: forte icon trace — {" ".join(trace)}')

    def cast_yy_lib(self, char, hold, gap):
        """秧秧的大招('RY'): 连发到出手 -> 等演出结束 -> 落地 -> 等收招 M_R_TO_E。

        后面紧跟的 E 是单发(剑式切换不能连发), 被收招吞了, 后面那一路长按打出来的就是
        苍剑式普攻 —— 所以按"HUD 回来 + M_R_TO_E"走, 不按表里的盲等。
        返回【gap 是不是已经在这里用掉了】(跟 macro_key 一致)。
        """
        tag = f'{char.name[:2]}R'
        if not self.SAFETY:
            char.send_liberation_key(down_time=hold)
            char.record_liberation_use()
            self.macro_mark(tag)
            return False
        spent = 0.0
        if self.fire_r(char, tag, self.M_R_WINDOW):
            self.wait_hud_back(tag=f'{tag}anim', time_out=self.LIB_ANIM_TIME_OUT)
            t0 = time.time()
            self.check_echo_used(char)
            spent = time.time() - t0      # 读声骸那一下算在收招的等待里, 不往后推 E
        else:
            self.logger.info(f'{tag}: 秧秧大招没出手(能量没满?), 照走 —— 少 1 点苍翎, '
                             f'1羽 可能打不出来')
        try:
            airborne = bool(self.flying()) if self.M_WAIT_DOWN_BEFORE_E else False
        except Exception as e:
            # flying() 是框架的读屏(控物图标), 只在场上有控物时才真的去读 ——
            # 读不到不该把整条宏带崩, 当"不在空中"处理(最坏就是 E 早按一点)
            self.logger.info(f'{tag}: flying probe failed ({e})')
            airborne = False
        if airborne:
            self.logger.info(f'{tag}: 大招收尾人还在空中, 先等落地再按 E')
            self.macro_mark(f'{tag}等落地')
            self.wait_down()
        self.macro_wait(max(0.0, self.M_R_TO_E - spent))
        return True

    def cast_mo_lib(self, char, hold, gap):
        """莫特斐的大招('RMO'): 攒能量 -> 连发到出手 -> 等演出结束 -> 接 E。

        跟参考代码 'R!' 那一格逐条相同, 只差收招: 【莫特斐 R 之后接 E 不用等】
        (用户 2026-10-10, 见 MO_R_TO_E)。参考那边秧秧的 R 演完要等 M_R_TO_E 是因为
        后面那个 E 是单发的剑式切换; 莫特斐的 E 没有奇偶问题, 不需要那段。
        """
        tag = f'{char.name[:2]}R'
        if not self.SAFETY:
            char.send_liberation_key(down_time=hold)
            char.record_liberation_use()
            self.macro_mark(tag)
            return False
        if self.tight:
            # 烟岚窗口里: 先直接连发, 没进才攒能量, 见 fire_r_tight(本队轴里走不到)
            fired = self.fire_r_tight(char, tag)
            if fired:
                self.wait_hud_back(tag=f'{tag}anim', time_out=self.LIB_ANIM_TIME_OUT)
            else:
                self.macro_mark(f'{tag}_没出手(不补演出gap)')
            return True
        # 【能量不够就先点普攻攒】。大招是能量门控不是 CD 门控 —— 图标不亮时按多少下
        # 都不出手, 而攒的正是这一格要用的资源, 安全(见 LIB_FILL)
        filled = self.fill_liberation(char, f'{char.name[:2]}能量')
        # 【连发到 HUD 消失, 不是"发一次然后盯着"】: 表里 Q 那格 gap 可能是 0,
        # R 紧跟着 Q 按下去会落在声骸动作里被游戏丢掉 —— 演出期间的按键是被丢弃的、
        # 不排队, 盖住整段只能靠连发。
        fired = self.fire_r(char, tag, self.LIB_FIRE_WINDOW)
        if not fired and filled:
            # 【只有"能量闸说满了却没出手"才值得补救】—— 那种是按键被吞(收招/入场锁),
            # 多按几下能救回来。
            # 【能量闸自己就说没满的, 补救是白烧】: 它刚盯着 liberation_available()
            # 点了几秒图标都没亮 = 能量真的不够, 这时大招按 100 下也不出手
            self.logger.info(f'{char.name}: 大招连发 {self.LIB_FIRE_WINDOW:.1f}s 没出手 — 再补救')
            fired = self.fire_r(char, f'{tag}补救', self.R_EXTRA_CAP)
        elif not fired:
            self.macro_mark(f'{tag}_能量不够(跳过补救)')
            self.logger.info(f'{char.name}: 能量闸就没攒满, 大招这一格直接放弃 — '
                             f'补救那 {self.R_EXTRA_CAP:.1f}s 按不出来, 留给后面的格子')
        if fired:
            self.wait_hud_back(tag=f'{tag}anim', time_out=self.LIB_ANIM_TIME_OUT)
            # 【演出结束就走, 不补足 gap】: 表里这一格的 gap 写的就是演出时长,
            # 而 wait_hud_back 是等 HUD 真的回来 —— 它比 gap 准。补足那点差是纯站着
            if self.MO_R_TO_E > 0:
                self.macro_wait(self.MO_R_TO_E)
            return True
        # 【没出手就不补 gap】: 没有演出要等, 补足它只是让莫特斐多站一会儿,
        # 后面每一格跟着往后推
        self.macro_mark(f'{tag}_没出手(不补演出gap)')
        return True

    def cast_sui_lib(self, char, hold, gap):
        """穗穗的大招('RSUI'): 先等三段回路满 -> 攒能量 -> 连发到出手 -> 等演出结束。

        跟参考代码 'R3' 那一格逐条相同。
        """
        tag = f'{char.name[:2]}R'
        if not self.SAFETY:
            char.send_liberation_key(down_time=hold)
            char.record_liberation_use()
            self.macro_mark(tag)
            return False
        if self.tight:
            # 烟岚窗口里: 先直接连发, 没进才攒能量, 见 fire_r_tight(本队轴里走不到)
            fired = self.fire_r_tight(char, tag)
            if fired:
                self.wait_hud_back(tag=f'{tag}anim', time_out=self.LIB_ANIM_TIME_OUT)
            else:
                self.macro_mark(f'{tag}_没出手(不补演出gap)')
            return True
        # 【穗穗专用的回路闸】: 三段回路没满就先接着点普攻, 满了立刻往下走(见 FORTE3_GATE)
        self.wait_forte3(f'{char.name[:2]}回路')
        # 【能量不够就先点普攻攒】。放在回路闸后面: 那一段本来就在点 A, 能量顺带也涨了,
        # 先让它跑完再读, 免得白等一轮
        filled = self.fill_liberation(char, f'{char.name[:2]}能量')
        fired = self.fire_r(char, tag, self.LIB_FIRE_WINDOW)
        if not fired and filled:
            self.logger.info(f'{char.name}: 大招连发 {self.LIB_FIRE_WINDOW:.1f}s 没出手 — 再补救')
            fired = self.fire_r(char, f'{tag}补救', self.R_EXTRA_CAP)
        elif not fired:
            self.macro_mark(f'{tag}_能量不够(跳过补救)')
            self.logger.info(f'{char.name}: 能量闸就没攒满, 大招这一格直接放弃 — '
                             f'补救那 {self.R_EXTRA_CAP:.1f}s 按不出来, 留给后面的格子')
        if fired:
            self.wait_hud_back(tag=f'{tag}anim', time_out=self.LIB_ANIM_TIME_OUT)
            return True
        self.macro_mark(f'{tag}_没出手(不补演出gap)')
        return True

    def check_echo_used(self, char):
        """R 演完读一次声骸: R 前那下 Q 真放出去了, 这时应该还在 CD 里(CD 20s)。
        只记录不补按, 见 YY_CANG_TRIM。"""
        try:
            self.task.next_frame()
            if not self.task.in_team()[0]:
                return
            if char.echo_available():
                self.macro_mark('Q没出')
                self.logger.warning(f'{char.name}: 大招演完声骸不在 CD —— R 前那下 Q 没放出来'
                                    f'(按早了被丢 / 被 R 顶掉?), 常出现就把 YY_CANG_TRIM 往回调')
            else:
                self.macro_mark('Q在CD')
        except Exception as e:
            self.logger.info(f'echo check failed ({e})')

    def settle_after_break(self):
        """处决完等秧秧收招(见 YU_AFTER_BREAK_SETTLE), 不点不按 —— 下一条宏第一格就是 W/E。"""
        if self.YU_AFTER_BREAK_SETTLE > 0:
            self.macro_wait(self.YU_AFTER_BREAK_SETTLE)
            self.macro_mark(f'处决后等收招({self.YU_AFTER_BREAK_SETTLE:.2f})')

    def break_or_wait_tail(self, wait_for_prompt=None):
        """宏末尾/尾巴中段的处决格。返回 True(时间自己管)。

        有处决提示就按 —— 处决取消羽的后摇, try_f_break 等 HUD 回来才返回, 再等
        YU_AFTER_BREAK_SETTLE 收招。没有就等让后摇演完, 期间一直探, 提示晚几帧才亮也照按。

        wait_for_prompt: 等提示出现的窗口(秒)。
          · None('F?', 两条宏的最后一格) = YU_NO_BREAK_TAIL(0.5s) —— 那一格的本意是
            "没处决就等羽的后摇", 处决是顺手探的;
          · 给了值('F!', 尾巴中段那一格) = 那个窗口 —— 那一格是要真按出处决的,
            提示可能在前面那格(换苍)才亮, 所以给它更长的窗口。
        """
        if self.try_f_break('收尾'):
            self.settle_after_break()
            return True
        cap = self.YU_NO_BREAK_TAIL if wait_for_prompt is None else wait_for_prompt
        end = time.time() + cap
        while True:
            left = end - time.time()
            if left <= 0:
                break
            self.macro_wait(min(self.YU_BREAK_POLL, left))
            if time.time() < end and self.try_f_break('收尾(后摇里)'):
                self.settle_after_break()
                return True
        self.macro_mark(f'没处决等后摇({cap:.2f})')
        return True

    def fill_liberation(self, char, tag, cap=None):
        """大招图标不亮(能量没满)就接着点普攻攒, 亮了立刻停手。返回攒够没有。

        【大招是能量门控不是 CD 门控】—— 判据是 liberation_available()(读图标),
        不是 has_cd('liberation')(那读的是 CD 数字, 大招没有数字)。
        上限到了照放不误: fire_r 连发两轮都不出手最多是这一轮少一个大招, 不该把宏卡死。
        """
        cap = self.LIB_FILL if cap is None else cap
        if cap <= 0:
            return True
        start = time.time()
        n = 0
        next_click = 0.0
        while time.time() - start < cap:
            # 【先点再读】, 理由见 wait_forte3 里那段
            now = time.time()
            if now >= next_click:
                self.click()
                n += 1
                next_click = now + self.LIB_FILL_INTERVAL
            self.task.next_frame()
            try:
                if self.task.in_team()[0] and char.liberation_available():
                    if n:
                        self.macro_mark(f'{tag}({time.time() - start:.2f}s,A x{n})')
                    return True
            except Exception:
                pass
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}(CAP,A x{n})')
        self.logger.info(f'{tag}: 大招能量 {cap:.1f}s 没攒满(点了 {n} 下 A) — 照按')
        return False

    # ==================== 两条轴 ====================

    def chain_ring_read(self):
        """读【普攻图标外那圈紫环】的覆盖率, 返回 (环覆盖率, 环外覆盖率)。

        位置全靠框架的框推出来: 普攻 = E(box_resonance) 左边 YY_CHAIN_RING_STEP 格,
        步长 = (box_liberation.x - box_resonance.x) / 2; 半径按 E 框高的倍数采样。
        判据(用户两张截图): 2 链及以上有紫环(覆盖率高)、0 链没有(≈0);
        【还要看环外】—— 背景整片发紫时环里环外一起高, 那种不算。
        读不到返回 (-1.0, -1.0)。
        """
        if not self.YY_CHAIN_RING:
            return -1.0, -1.0
        try:
            res = self.task.get_box_by_name('box_resonance')
            lib = self.task.get_box_by_name('box_liberation')
            frame = self.task.frame
            step = ((lib.x + lib.width / 2) - (res.x + res.width / 2)) / 2.0
            cx = res.x + res.width / 2 - step * self.YY_CHAIN_RING_STEP
            cy = res.y + res.height / 2
            bh = float(res.height)
            fh, fw = frame.shape[:2]
            ang = [i * 2 * math.pi / 48 for i in range(48)]

            def cover(k):
                hit = 0
                for a in ang:
                    x = int(round(cx + k * bh * math.cos(a)))
                    y = int(round(cy + k * bh * math.sin(a)))
                    if not (0 <= x < fw and 0 <= y < fh):
                        continue
                    b, g, r = (int(v) for v in frame[y, x][:3])
                    # 紫/洋红环: 红高、蓝也高、绿低(用户截图上量的那组阈值)
                    if r > 150 and b > 130 and g < 110 and r - g > 60 and b - g > 40:
                        hit += 1
                return hit / len(ang)

            ring = max(cover(k) for k in self.YY_CHAIN_RING_K)
            out = max(cover(k) for k in self.YY_CHAIN_RING_OUT_K)
            return ring, out
        except Exception as e:
            self.logger.info(f'chain ring probe failed ({e})')
            return -1.0, -1.0

    def halo_read(self):
        """读普攻按钮那圈品红光圈(重击蓄力/派生)的覆盖率(0~1), 读不到返回 -1。

        位置跟链数检测同一套几何; 半径见 HALO_K(视频剖面 0.60~0.72 是峰)。
        判据见 HALO_MIN: 视频实测 蓄力中 0.33~0.79 / 打完 0.00。
        """
        try:
            res = self.task.get_box_by_name('box_resonance')
            lib = self.task.get_box_by_name('box_liberation')
            frame = self.task.frame
            step = ((lib.x + lib.width / 2) - (res.x + res.width / 2)) / 2.0
            cx = res.x + res.width / 2 - step * 2
            cy = res.y + res.height / 2
            bh = float(res.height)
            fh, fw = frame.shape[:2]
            ang = [i * 2 * math.pi / 48 for i in range(48)]

            def cover(k):
                hit = 0
                for a in ang:
                    x = int(round(cx + k * bh * math.cos(a)))
                    y = int(round(cy + k * bh * math.sin(a)))
                    if not (0 <= x < fw and 0 <= y < fh):
                        continue
                    b, g, r = (int(v) for v in frame[y, x][:3])
                    if r > 150 and b > 130 and g < 110 and r - g > 60 and b - g > 40:
                        hit += 1
                return hit / len(ang)

            return max(cover(k) for k in self.HALO_K)
        except Exception as e:
            self.logger.info(f'halo probe failed ({e})')
            return -1.0

    def _glyph_tpl(self):
        """解码内嵌的两个图标模板(只做一次)。返回 (A剑锋, B月牙) 两个 64x64 float 数组。"""
        tpl = getattr(self, '_yy_glyph_tpl_cache', None)
        if tpl is None:
            out = []
            for b64 in (self.YY_GLYPH_A_B64, self.YY_GLYPH_B_B64):
                q = cv2.imdecode(np.frombuffer(base64.b64decode(b64), np.uint8),
                                 cv2.IMREAD_GRAYSCALE)
                out.append((q.astype(np.float32) - 128.0) / 40.0)
            tpl = tuple(out)
            self._yy_glyph_tpl_cache = tpl
        return tpl

    def yy_glyph_read(self):
        """读普攻按钮上的图标形态, 返回 (A剑锋分, B月牙剑分); 读不到返回 (-9, -9)。

        取按钮中心 YY_GLYPH_R×E框高 半径的一块, 缩到 64x64 做零均值/单位方差,
        跟两个内嵌模板求相关。判据见 YY_GLYPH_*: B-A >= MARGIN = 已经是月牙剑。
        """
        if not self.YY_GLYPH_GATE:
            return -9.0, -9.0
        try:
            res = self.task.get_box_by_name('box_resonance')
            lib = self.task.get_box_by_name('box_liberation')
            frame = self.task.frame
            step = ((lib.x + lib.width / 2) - (res.x + res.width / 2)) / 2.0
            cx = res.x + res.width / 2 - step * 2
            cy = res.y + res.height / 2
            r = int(self.YY_GLYPH_R * float(res.height))
            fh, fw = frame.shape[:2]
            x0, y0 = int(cx) - r, int(cy) - r
            if r <= 2 or x0 < 0 or y0 < 0 or x0 + 2 * r > fw or y0 + 2 * r > fh:
                return -9.0, -9.0
            patch = frame[y0:y0 + 2 * r, x0:x0 + 2 * r]
            g = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY).astype(np.float32)
            g = cv2.resize(g, (64, 64), interpolation=cv2.INTER_AREA)
            g -= g.mean()
            sd = float(g.std())
            if sd <= 1e-3:
                return -9.0, -9.0
            g /= sd
            ta, tb = self._glyph_tpl()
            return float((g * ta).mean()), float((g * tb).mean())
        except Exception as e:
            self.logger.info(f'glyph probe failed ({e})')
            return -9.0, -9.0

    def flush_key_caches(self, tag=''):
        """【清空按键/技能的状态缓存】(用户 2026-10-15): 提前松手之后立刻清一遍 ——
        框架和角色身上缓存的"技能可用 / 协奏满 / 能处决"全部打掉, 让后面每一格读到的
        都是当场的新状态(不然刚打完羽重那一瞬间的旧缓存会让下一格按空或误判)。
        AY 那格返回 False, 表会接着走【这一格自己的 gap】, 时序不变。
        """
        chars = [self]
        for name in ('Mortefi', 'Suisui'):
            try:
                chars.append(self.teammate(name))
            except Exception:
                pass
        for ch in chars:
            if ch is None:
                continue
            for attr, val in (('current_con', 0), ('_liberation_available', False),
                              ('_echo_available', False), ('can_break', False)):
                try:
                    setattr(ch, attr, val)
                except Exception:
                    pass
        try:
            self.task.can_break = False
        except Exception:
            pass
        self.yy_ex_verify_pending = None
        if tag:
            self.macro_mark(f'{tag}清缓存')

    def halo_usable(self):
        """这套光圈判据现在能不能用(见 HALO_ONLY_0CHAIN)。"""
        return bool(self.HALO_RELEASE) and not (self.HALO_ONLY_0CHAIN
                                               and getattr(self, 'yy_s2', False))

    def yy_cang_icon_read(self):
        """读【普攻按钮】上苍重/羽重图标的白色占比(0~1), 读不到返回 -1。

        位置跟 chain_ring_read 同一套几何: 中心 = 2*E框中心 - R框中心(= E 左边 2 步),
        半径 = YY_CANG_ICON_K × E 框高。【全是相对量, 换分辨率不用改】。
        判据见 YY_CANG_ICON_MIN: 亮着的白图标 ~0.18, 灰的普攻图标/暗态 ~0.00。
        """
        if not self.YY_CANG_ICON:
            return -1.0
        try:
            res = self.task.get_box_by_name('box_resonance')
            lib = self.task.get_box_by_name('box_liberation')
            frame = self.task.frame
            step = ((lib.x + lib.width / 2) - (res.x + res.width / 2)) / 2.0
            cx = res.x + res.width / 2 - step * 2
            cy = res.y + res.height / 2
            r = self.YY_CANG_ICON_K * float(res.height)
            fh, fw = frame.shape[:2]
            th = self.YY_CANG_ICON_WHITE
            n = hit = 0
            ri = int(r)
            for dy in range(-ri, ri + 1, 2):
                for dx in range(-ri, ri + 1, 2):
                    if dx * dx + dy * dy > r * r:
                        continue
                    x, y = int(cx) + dx, int(cy) + dy
                    if not (0 <= x < fw and 0 <= y < fh):
                        continue
                    b, g, rr = (int(v) for v in frame[y, x][:3])
                    n += 1
                    if rr > th and g > th and b > th:
                        hit += 1
            return hit / n if n else -1.0
        except Exception as e:
            self.logger.info(f'cang icon probe failed ({e})')
            return -1.0

    def read_forte_signals(self):
        """读血条右边那一小块的四个数, 返回 (图标模板, E模板, 白色占比, 框架判定的"满")。

        【判定只看第三个(白色占比)】—— "亮"= 图标填满/变白, 不是"图标在不在"(它一直在)。
        前两个只进日志备查。读不到的给 -1。
        """
        conf = -1.0
        try:
            hit = self.task.find_mouse_forte()
            conf = float(getattr(hit, 'confidence', 1.0)) if hit else 0.0
        except Exception:
            pass
        econf = -1.0
        try:
            hit = self.task.find_e_forte()
            econf = float(getattr(hit, 'confidence', 1.0)) if hit else 0.0
        except Exception:
            pass
        # 【自己量白色占比】: 跟框架 is_forte_full() 用的同一个框和同一套颜色 ——
        # 它那个方法内部也算这个数, 只是顺手写进 box.confidence; 这里算一遍拿返回值,
        # 顺带也在日志里能看到具体是多少。
        white = -1.0
        try:
            box = self.task.box_of_screen_scaled(3840, 2160, 2251, 1993, 2311, 2016,
                                                 name='forte_full', hcenter=True)
            white = float(self.task.calculate_color_percentage(forte_white_color, box))
        except Exception:
            pass
        full = False
        try:
            full = bool(self.is_forte_full())
        except Exception:
            pass
        return conf, econf, white, full

    def detect_yy_chains(self):
        """开局读一次苍重击图标, 决定用 2 链轴还是 0 链轴。返回 True = 2 链。

        【只在开局读】(用户: "开局是否苍重击图标亮起"): 战斗中这个图标是动态的(重击出手
        清空苍翎就灭、湮象风华换了图案也读成灭), 所以判据只取第一次出手之前的那一次读数。
        读不到(HUD 没稳定)就按 0 链走 —— 0 链轴在秧秧或穗穗开局下都能跑
        (第一格"直接切莫特斐"两边都对得上)。

        【判定】: 血条右边那一小块的【白色占比 >= YY_CHAIN_WHITE(0.08)】才算"亮"
        (图标填满/变白 —— 不是"图标在不在", 那个 0 链也一直"在", 见 YY_CHAIN_WHITE 注释),
        连读 YY_CHAIN_CONFIRM(3) 帧都亮才算 2 链。YY_FORCE_CHAIN 不为 None 时直接用它。
        每一帧的三个读数都会打进日志 —— 认错了就看日志里那几行。
        """
        if self.YY_FORCE_CHAIN is not None:
            s2 = self.YY_FORCE_CHAIN >= 2
            self.logger.info('秧莫穗: 链数判定被 YY_FORCE_CHAIN=%s 强制为 %s 链轴'
                             % (self.YY_FORCE_CHAIN, '2' if s2 else '0'))
            return s2
        if not self.YY_CHAIN_CHECK:
            return False
        hits = 0
        for i in range(self.YY_CHAIN_CONFIRM):
            self.task.next_frame()
            try:
                ring, ring_out = self.chain_ring_read()
                has_ring = (ring >= self.YY_CHAIN_RING_MIN
                            and ring_out <= self.YY_CHAIN_RING_OUT_MAX)
                lit = bool(self.task.in_team()[0]) and (
                    has_ring if ring >= 0 else False)
                conf, econf, white, full = self.read_forte_signals()
            except Exception:
                ring, ring_out, conf, econf, white, full, lit = (
                    -1.0, -1.0, -1.0, -1.0, -1.0, False, False)
            self.logger.info('秧莫穗: 链数判据 #%d 普攻紫环=%.3f(环外 %.3f, 门槛 %.2f/%.2f) '
                             '-> %s [备查: 白色占比=%.3f(门槛 %.2f) 框架判定=%s '
                             '图标模板=%.3f(>=%.2f算在) E模板=%.3f]'
                             % (i + 1, ring, ring_out, self.YY_CHAIN_RING_MIN,
                                self.YY_CHAIN_RING_OUT_MAX, '有(2链)' if lit else '没有(0链)',
                                white, self.YY_CHAIN_WHITE, full,
                                conf, self.YY_CHAIN_CONF, econf))
            if lit:
                hits += 1
                if hits >= self.YY_CHAIN_CONFIRM:
                    return True
            else:
                hits = 0
            if i + 1 < self.YY_CHAIN_CONFIRM:
                self.macro_wait(self.YY_CHAIN_GAP)
        return False

    def opener_table(self):
        """启动轴用哪张表。4r 单轴版: 只有一张, 不分 0/2 链。"""
        return self.OPENER_MACRO

    def loop_table(self):
        """循环轴用哪张表(4r 单轴版: 只有一张)。"""
        return self.LOOP_MACRO

    def perform_opener(self, entry_char=None):
        """启动轴 = 启动宏一张表跑完(含末尾的 1苍/1羽 和处决)。
        返回时秧秧在场, 下一次 do_perform 还是她, 接循环宏。"""
        mo, sui, previous = self.macro_enter(entry_char)
        if mo is None:
            return False
        self.logger.info(f'yangmosui opener entry: {self.cur.name}')
        try:
            self.loop_count = 0
            # 【4r 轴: 强制秧秧开局】(用户 2026-10-16): 不管谁在场(穗穗/莫特斐)都先切回
            # 秧秧, 0 链 2 链都一样 —— 4r 的启动轴第一格就是秧秧的 Q, 必须她起跑。
            if self.cur is not self:
                self.quick_switch(self)
            # 【开局规则】(用户 2026-10-11): "开局只限制非莫特斐开局; 穗穗开局则不再切秧秧,
            # 直接切莫特斐, 打0链的轴; 秧秧开局则是按图标选择0链还是2链的轴":
            #   · 莫特斐开局 -> 唯一要纠正的, 上面已经切回秧秧, 于是按秧秧开局处理
            #   · 穗穗开局   -> 不切秧秧(她那格"直接切莫特斐"从她身上起跑), 直接 0 链, 不读图标
            #   · 秧秧开局   -> 读一次苍重击图标: 亮(2链及以上)走 S2, 不亮走 0 链
            #     (S2 启动轴第一格是秧a1, 假设场上就是秧秧; 读不到也按 0 链走)
            # 【4r 单轴版】(用户 2026-10-16): 只有一套轴 —— 不读苍重击图标, 不分 0/2 链
            self.yy_s2 = False
            self.logger.info(f'秧莫穗: 入口 {self.cur.name}, 4r 单轴(不读链数图标, 0链2链同一套)')
            self.run_macro(self.opener_table(), '启动宏')
        finally:
            self.macro_exit(previous)
        return True

    def perform_loop(self, entry_char=None):
        """循环轴的一步 = 循环宏一张表跑完。返回时秧秧在场(跟启动轴同一个位置)。"""
        mo, sui, previous = self.macro_enter(entry_char)
        if mo is None:
            return False
        try:
            # 循环宏前三格(W/E/A)在秧秧身上; 宏散掉之后框架可能把别人放上来了, 先切回自己
            if self.cur is not self:
                self.quick_switch(self)
            self.loop_count += 1
            n = self.loop_count
            self.run_macro(self.loop_table(), f'循环宏#{n}')
            self.logger.info(
                f'loop step #{n} {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        finally:
            self.macro_exit(previous)
        return True

    # ==================== 框架接口 ====================

    def run_opener_from(self, entry_char):
        """跑启动轴并落防重入标记。启动宏第一格是"从秧秧身上直接切莫特斐",
        入口就是秧秧自己(用户 2026-10-11 改成秧秧开局)。

        标记要在跑之前落: 中途抛异常(脱战/任务被停)也不能让启动轴重跑。
        """
        self.opener_armed = False
        self.last_opener = time.time()
        return self.perform_opener(entry_char)

    def do_perform(self):
        """本队里秧秧驱动两条轴。两条都在末尾处决(或等完后摇)后返回, 下一次框架调的还是她。"""
        if not self.is_in_yangmosui:
            return super().do_perform()
        blocked = self.opener_blocked_by()
        if blocked is None:
            # 走到这儿说明启动轴待跑但场上是秧秧(穗穗没被框架放上来) ——
            # perform_opener 里会先切回穗穗再开表
            if self.run_opener_from(self):
                return
            self.logger.warning('yangmosui opener aborted, falling back to the native rotation')
            return super().do_perform()
        self.logger.info(f'yangmosui: opener not pending ({blocked}), running the loop')
        if self.perform_loop(self):
            return
        return super().do_perform()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """宏散掉之后, 框架选人时秧秧优先 —— 她一上场轴就接上了。

        【启动轴待跑时给 MUST】(用户 2026-10-11 改成秧秧开局): 她现在是入场角色,
        启动宏第一格"直接切莫特斐"就是从她身上起跑, 场上必须先是她。
        (参考代码那边入场角色是穗穗, 所以它给的是穗穗 MUST、秧秧 NO —— 位置对调了。)
        其余时候给 HIGH。
        """
        if self.is_in_yangmosui:
            if self.opener_pending():
                return SwitchPriority.MUST
            return SwitchPriority.HIGH
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        self.release_attack()
        self.poking = False
        return super().on_combat_end(chars)
