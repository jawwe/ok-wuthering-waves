# -*- coding: utf-8 -*-
"""秧莫穗 — 莫特斐（速切副输出 / 宏驱动入口）

本队的整套固定轴在 YangYangSp.py 里，宏跑起来时莫特斐由宏按数字键切进切出
（一轮上场 7 次），这里一个动作都不用写。

碰到 do_perform 只有两种情况：
  · 启动轴待跑（战斗刚开始、框架先轮到了他）：把自己当入口交给秧秧的宏 ——
    perform_opener 会先切回秧秧(他是唯一需要通过换人来纠正的入口), 再按图标选轴;
  · 宏散了（切人失败/脱战重进）：打一轮原版，打完框架会把场子交给秧秧，宏接上。

【开局规则】(用户 2026-10-11): 莫特斐开局是唯一要纠正的(换回秧秧);
穗穗开局不切秧秧(她直接切莫特斐走 0 链); 秧秧开局按苍重击图标选 0 链还是 2 链。
待跑时给 NO —— 别让框架在切人时把他先放上场。

写法逐条对照 ok-ww 工坊「Chisa_Suisui_Yangyang_Xuanling」（作者 楽山，v2.0.0）里的
Chisa.py —— 那边千咲（本队里被莫特斐顶掉的那个位置）同样是 NO + 让场。
"""

from src.char.BaseChar import SwitchPriority
from src.char.Mortefi import Mortefi as NativeMortefi


class Mortefi(NativeMortefi):
    """秧莫穗里的莫特斐。非本队时整套走原版。"""

    @property
    def is_in_yangmosui(self) -> bool:
        members = 0
        for char in self.task.chars:
            if char and char.name in {'Suisui', 'YangYangSp'}:
                members += 1
        return members == 2

    def macro(self):
        """持宏的秧秧。【按能力找】: 没启用自定义时返回 None, 老老实实走原版。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'perform_opener') and hasattr(char, 'macro_switch'):
                return char
        return None

    def do_perform(self):
        if not self.is_in_yangmosui:
            return super().do_perform()
        macro = self.macro()
        if macro is None:
            self.logger.warning('yangmosui: YangYangSp custom code is off, '
                                'falling back to the native rotation')
            return super().do_perform()
        if macro.opener_pending():
            # 【莫特斐开局是唯一要纠正的】(用户 2026-10-11: "开局只限制非莫特斐开局"):
            # 把自己当 entry_char 交进去, perform_opener 里会先切回秧秧, 再按图标选 0链/2链。
            # 【不走 switch_next_char()】: 那个会带一串"切人期间的左键"(框架原版轮转的行为),
            # 而且顺序由框架的优先级决定 —— 这里全部交给我们自己的宏来管。
            self.logger.info('mortefi: opener pending -> running it from here (entry = mortefi)')
            if macro.run_opener_from(self):
                return
            self.logger.warning('yangmosui opener aborted, falling back to the native rotation')
        else:
            self.logger.info('mortefi do_perform in yangmosui (macro fell apart) -> native rotation')
        return super().do_perform()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时返回 NO —— 入场角色是秧秧, 他抢上场会把整张表错开一格。

        【要写在 super() 之前】: 原版在有变奏时会返回 MUST。
        """
        if self.is_in_yangmosui:
            macro = self.macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)
