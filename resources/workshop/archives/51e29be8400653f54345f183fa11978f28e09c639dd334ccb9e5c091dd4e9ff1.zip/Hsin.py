import inspect
import time

from src.char.BaseChar import BaseChar, SwitchPriority


class Hsin(BaseChar):
    """固定轴 1 号位：执行启动收尾段和循环段。"""

    AXIS_SLOT = 1
    AXIS_PHASE_SLOTS = (3, 2, 1, 2, 1)

    NORMAL_INTERVAL = 0.12  # 普攻输入后的基础间隔，单位为秒。
    NORMAL_ATTACK_FINISH_WAIT = 0.75  # 普攻动作收尾等待，单位为秒。
    NORMAL_INTERVAL2 = 0.12  # 普攻输入后的基础间隔，单位为秒。
    NORMAL_ATTACK_FINISH_WAIT2 = 0.45  # 普攻动作收尾等待，单位为秒。
    NORMAL_INTERVAL3 = 0.12  # 普攻输入后的基础间隔，单位为秒。
    NORMAL_ATTACK_FINISH_WAIT3 = 0.25  # 普攻动作收尾等待，单位为秒。    
    KEY_DOWN = 0.02  # E/Q/R 单键按下时长，单位为秒。
    KEY_INTERVAL = 0.10  # 连续技能键之间的间隔，单位为秒。
    KEY_BIANZOU1 = 1.0 # 锁变心1
    KEY_BIANZOU2 = 1.5 # 锁变心2
    KEY_E = 1.5 # E前等待
    KEY_RLATER = 4.0 # R后等待
    KEY_ELATER = 0.0 # E后等待
    HEAVY_TO_R_WAIT = 0.5  # 启动第一段重击后、按 R 前的可调等待。
    HEAVY_TO_R_WAIT2 = 2.0 # 循环第一段重击后、按 R 前的可调等待。
    HEAVY_TO_R_WAI2 = 2.25  # 第二段重击后、按 R 前的可调等待。
    STARTUP_FINISH_WAIT = 2.5  # 启动轴切入后等待自动强 E 动作结束的宏等待。
    LOOP_FINISH_WAIT = 1.0  # 循环轴切入后等待自动强 E 动作结束的宏等待。
    DODGE_HOLD = 0.12  # 闪避时按住右键的时长，单位为秒。
    XN1_HEAVY_HOLD = 1.8  # 第一段重击长按时长，沿用 Hsin.py 的应世相重击时长。
    XN2_HEAVY_HOLD = 0.45  # 收尾重击长按时长，沿用 Hsin.py 的临寰宇实测时长。
    SWITCH_TIMEOUT = 2.5  # 等待目标槽位出现在 HUD 的最长时间。
    AXIS_TARGET_REACQUIRE_TIMEOUT = 8.0  # 全屏大招期间目标 UI 不可见时的重锁上限。
    KEYS = {'E': 'e', 'Q': 'q', 'R': 'r'}  # 轴使用的物理键名；重击通过长按普攻执行。

    def __init__(self, *args, **kwargs):
        """初始化心的轴动作状态。"""
        super().__init__(*args, **kwargs)
        self._axis_reset_log_count = 0

    def _prepare_axis(self):
        """读取全队共享阶段；未初始化时从 3 号位启动段开始。"""
        self._extend_target_reacquire_timeout()
        if not getattr(self.task, '_catpaw_axis_initialized', False):
            self.task._catpaw_axis_phase = 0
            self.task._catpaw_axis_action_index = 0
            self.task._catpaw_axis_initialized = True
            self.logger.info('CatPaw 全队轴初始化：从维（3 号位）启动段开始。')
        return self.task._catpaw_axis_phase

    def _extend_target_reacquire_timeout(self):
        """大招遮挡目标 UI 时延长重锁窗口，不重放当前轴动作。"""
        if getattr(self.task, '_catpaw_target_reacquire_timeout_active', False):
            return
        original = getattr(self.task, 'target_enemy_time_out', None)
        if original is None:
            return
        adjusted = max(original, self.AXIS_TARGET_REACQUIRE_TIMEOUT)
        self.task._catpaw_original_target_reacquire_timeout = original
        self.task.target_enemy_time_out = adjusted
        self.task._catpaw_target_reacquire_timeout_active = True
        if adjusted != original:
            self.logger.info(f'CatPaw 全屏动画目标重锁上限：{original} 秒 -> {adjusted} 秒。')

    def reset_state(self):
        """框架结束战斗或重识别队伍时，重置全队共享轴状态。"""
        state_changed = (
            getattr(self.task, '_catpaw_axis_phase', 0) != 0
            or getattr(self.task, '_catpaw_axis_action_index', 0) != 0
        )
        super().reset_state()
        if getattr(self.task, '_catpaw_target_reacquire_timeout_active', False):
            self.task.target_enemy_time_out = self.task._catpaw_original_target_reacquire_timeout
            self.task._catpaw_original_target_reacquire_timeout = None
            self.task._catpaw_target_reacquire_timeout_active = False
        self.task._catpaw_axis_phase = 0
        self.task._catpaw_axis_action_index = 0
        self.task._catpaw_axis_initialized = False
        log_count = getattr(self, '_axis_reset_log_count', 0)
        if state_changed and log_count < 3:
            self.logger.info('CatPaw 全队轴状态已重置：下次进战从维（3 号位）启动段开始。')
            self._axis_reset_log_count = log_count + 1

    def _normal_attack_with_wait(self):
        """执行一次普攻，并等待输入间隔和动作收尾。"""
        result = self.normal_attack()
        self.sleep(self.NORMAL_INTERVAL)
        self.sleep(self.NORMAL_ATTACK_FINISH_WAIT, False)
        return result is not False

    def _normal_attack_with_wait2(self):
        """执行一次普攻，并等待输入间隔和动作收尾。"""
        result = self.normal_attack()
        self.sleep(self.NORMAL_INTERVAL2)
        self.sleep(self.NORMAL_ATTACK_FINISH_WAIT2, False)
        return result is not False    

    def _normal_attack_with_wait3(self):
        """执行一次普攻，并等待输入间隔和动作收尾。"""
        result = self.normal_attack()
        self.sleep(self.NORMAL_INTERVAL3)
        self.sleep(self.NORMAL_ATTACK_FINISH_WAIT3, False)
        return result is not False    

    def _normal_chain(self, count):
        """连续执行指定次数的带等待普攻。"""
        for _ in range(count):
            if self._normal_attack_with_wait() is False:
                return False
        return True

    def _tap(self, key):
        """按下一个轴配置中的技能键，并等待后续技能输入间隔。"""
        result = self.task.send_key(self.KEYS[key], down_time=self.KEY_DOWN)
        self.sleep(self.KEY_INTERVAL, False)
        return result is not False

    def _hold_heavy_attack(self, duration):
        """长按普攻执行重击，并在结束或异常时释放鼠标左键。"""
        down_result = None
        up_result = None
        try:
            down_result = self.task.mouse_down()
            self.sleep(duration, False)
        finally:
            up_result = self.task.mouse_up()
        self.sleep(self.KEY_INTERVAL, False)
        return down_result is not False and up_result is not False

    def _try_finisher(self):
        """尝试处决；处决不可用或输入异常时仍继续后续轴操作。"""
        try:
            self.f_break()
        except Exception as error:
            self.logger.warning(f'CatPaw 心轴处决尝试失败并跳过：{error}')
        return True

    def _wait_intro_if_needed(self):
        """仅在持有入场技状态时等待，并保持动作计划的固定长度。"""
        if not self.has_intro:
            return True
        return self.wait_intro(1.2, click=False)

    def _run_axis_action(self, label, action):
        """只执行一次轴操作；失败时记录并交由计划推进游标。"""
        try:
            if action() is not False:
                return True
            error = '操作返回失败'
        except Exception as caught:
            error = str(caught)
        self.logger.warning(f'CatPaw 心轴操作失败：{label}，不重试，原因={error}。')
        return False

    def _run_axis_plan(self, actions, next_slot):
        """失败动作不重放；确认末尾切人后推进全队阶段。"""
        self._prepare_axis()
        actions.append((f'切换到 {next_slot} 号位', lambda: self._switch_to_slot(next_slot)))
        while self.task._catpaw_axis_action_index < len(actions):
            action_index = self.task._catpaw_axis_action_index
            label, action = actions[action_index]
            if not self._run_axis_action(label, action):
                if action_index < len(actions) - 1:
                    self.task._catpaw_axis_action_index += 1
                return False
            self.task._catpaw_axis_action_index += 1
        self.task._catpaw_axis_action_index = 0
        self.task._catpaw_axis_phase += 1
        return True

    def _route_axis_phase(self, phase):
        """只切到当前全队阶段的执行槽位，不执行其他角色的阶段。"""
        slot = self.AXIS_PHASE_SLOTS[phase % len(self.AXIS_PHASE_SLOTS)]
        if slot == self.AXIS_SLOT:
            return True
        self._switch_to_slot(slot)
        return False

    def _dodge_right(self):
        """按住鼠标右键执行闪避，并在结束或异常时释放按键。"""
        down = getattr(self.task, 'mouse_right_down', None)
        up = getattr(self.task, 'mouse_right_up', None)
        down_kwargs = {}
        up_kwargs = {}
        if not callable(down) or not callable(up):
            down = getattr(self.task, 'mouse_down', None)
            up = getattr(self.task, 'mouse_up', None)
            if not callable(down) or not callable(up):
                self.logger.warning('CatPaw 心轴无法执行闪避：运行时没有右键按下/释放接口。')
                return False
            down_params = inspect.signature(down).parameters
            up_params = inspect.signature(up).parameters
            down_name = next((name for name in ('button', 'mouse_button', 'key') if name in down_params), None)
            up_name = next((name for name in ('button', 'mouse_button', 'key') if name in up_params), None)
            if down_name is None or up_name is None:
                self.logger.warning('CatPaw 心轴无法执行闪避：鼠标接口没有按钮参数。')
                return False
            down_kwargs[down_name] = 'right'
            up_kwargs[up_name] = 'right'
        down_result = None
        up_result = None
        try:
            down_result = down(**down_kwargs)
            self.sleep(self.DODGE_HOLD, False)
        finally:
            up_result = up(**up_kwargs)
        self.sleep(self.KEY_INTERVAL, False)
        return down_result is not False and up_result is not False

    def _switch_to_slot(self, slot):
        """按槽位键切人，轮询 HUD 确认后同步当前角色和切入时间。"""
        target_index = slot - 1
        self.has_intro = False
        self.has_sub_dps_intro = False
        self._liberation_available = self.liberation_available()
        self.use_tool_box()

        started = time.monotonic()
        while time.monotonic() - started < self.SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == target_index:
                now = time.time()
                self.last_switch_time = now
                for char in getattr(self.task, 'chars', []):
                    if char:
                        char.is_current_char = char.index == target_index
                        if char.index == target_index:
                            char.last_switch_in_time = now
                return True
            self.task.send_key(str(slot))
            self.task.next_frame()
            self.sleep(0.1, False)
        self.logger.warning(f'CatPaw 心轴切换到 {slot} 号位超时；阶段计数保持不变。')
        return False

    def _perform_segment(self, step):
        """构造当前轴段的逐操作计划，并在成功切人后推进阶段。"""
        actions = [('入场等待', self._wait_intro_if_needed)]
        if step == 2:
            self.logger.info('CatPaw 启动段 3/5：心 A-A-重击-等待-R-2A-E，之后普通切锁。')
            next_slot = 2
            actions.extend((
                ('段落开始等待', lambda: self.sleep(self.KEY_BIANZOU1, False)),
                ('普攻 1/2', self._normal_attack_with_wait),
                ('普攻 2/2', self._normal_attack_with_wait),
                ('重击', lambda: self._hold_heavy_attack(self.XN1_HEAVY_HOLD)),
                ('重击后等待', lambda: self.sleep(self.HEAVY_TO_R_WAIT, False)),
                ('R', lambda: self._tap('R')),
                ('R收尾', lambda: self.sleep(self.KEY_RLATER, False)),
                ('普攻 3/4', self._normal_attack_with_wait3),
                ('普攻 4/4', self._normal_attack_with_wait3),
                ('E', lambda: self._tap('E')),
                ('E收尾', lambda: self.sleep(self.KEY_ELATER, False)),
            ))
        elif step == 4:
            self.logger.info('CatPaw 启动段 5/5：等待自动强E，再 Q-3A-处决尝试-闪避-2A-重击-R，普通切维进入循环。')
            next_slot = 3
            actions.extend((
                ('自动强 E 收尾等待', lambda: self.sleep(self.STARTUP_FINISH_WAIT, False)),
                ('Q', lambda: self._tap('Q')),
                ('普攻 1/3', self._normal_attack_with_wait2),
                ('普攻 2/3', self._normal_attack_with_wait2),
                ('普攻 3/3', self._normal_attack_with_wait2),
                ('闪避', self._dodge_right),
                ('普攻 1/3', self._normal_attack_with_wait2),
                ('普攻 2/3', self._normal_attack_with_wait2),
                ('普攻 3/3', self._normal_attack_with_wait2),
                ('收尾重击', lambda: self._hold_heavy_attack(self.XN2_HEAVY_HOLD)),
                ('重击后等待', lambda: self.sleep(self.HEAVY_TO_R_WAI2, False)),
                ('R', lambda: self._tap('R')),
            ))
        elif step >= 5 and (step - 7) % 5 == 0:
            self.logger.info('CatPaw 循环段 3/5：心 A-A-重击-等待-R-2A-E，之后普通切锁。')
            next_slot = 2
            actions.extend((
                ('普攻 1/2', self._normal_attack_with_wait),
                ('普攻 2/2', self._normal_attack_with_wait),
                ('重击', lambda: self._hold_heavy_attack(self.XN1_HEAVY_HOLD)),
                ('重击后等待', lambda: self.sleep(self.HEAVY_TO_R_WAIT2, False)),
                ('R', lambda: self._tap('R')),
                ('R收尾', lambda: self.sleep(self.KEY_RLATER, False)),
                ('普攻 3/4', self._normal_attack_with_wait),
                ('普攻 4/4', self._normal_attack_with_wait),
                ('E', lambda: self._tap('E')),
                ('E收尾', lambda: self.sleep(self.KEY_ELATER, False)),
            ))
        else:
            self.logger.info('CatPaw 循环段 5/5：等待自动强E，再 Q-3A-处决尝试-闪避-2A-重击-R，普通切维开始下一圈。')
            next_slot = 3
            actions.extend((
                ('自动强 E 收尾等待', lambda: self.sleep(self.STARTUP_FINISH_WAIT, False)),
                ('Q', lambda: self._tap('Q')),
                ('普攻 1/3', self._normal_attack_with_wait2),
                ('普攻 2/3', self._normal_attack_with_wait2),
                ('普攻 3/3', self._normal_attack_with_wait2),
                ('闪避', self._dodge_right),
                ('普攻 1/3', self._normal_attack_with_wait2),
                ('普攻 2/3', self._normal_attack_with_wait2),
                ('普攻 3/3', self._normal_attack_with_wait2),
                ('收尾重击', lambda: self._hold_heavy_attack(self.XN2_HEAVY_HOLD)),
                ('重击后等待', lambda: self.sleep(self.HEAVY_TO_R_WAI2, False)),
                ('R', lambda: self._tap('R')),
            ))
        return self._run_axis_plan(actions, next_slot)

    def do_perform(self):
        """按全队阶段执行心的段落，错位时只切至阶段执行槽位。"""
        phase = self._prepare_axis()
        if self._route_axis_phase(phase):
            self._perform_segment(phase)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """使用基类规则返回调度器所需的切人优先级。"""
        return super().get_switch_priority(current_char, has_intro, target_low_con)
